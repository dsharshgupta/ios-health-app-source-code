import SwiftUI

struct ContentView: View {
    @EnvironmentObject var store: DataStore
    @State private var selectedTab = 0

    var body: some View {
        TabView(selection: $selectedTab) {
            HomeView()
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Home")
                }
                .tag(0)

            DietView()
                .tabItem {
                    Image(systemName: "fork.knife")
                    Text("Diet")
                }
                .tag(1)

            ExerciseView()
                .tabItem {
                    Image(systemName: "figure.run")
                    Text("Exercise")
                }
                .tag(2)

            WaterView()
                .tabItem {
                    Image(systemName: "drop.fill")
                    Text("Water")
                }
                .tag(3)

            WeightView()
                .tabItem {
                    Image(systemName: "scalemass.fill")
                    Text("Weight")
                }
                .tag(4)

            HealthMetricsView()
                .tabItem {
                    Image(systemName: "waveform.path.ecg.rectangle")
                    Text("Metrics")
                }
                .tag(5)

            ReportsView()
                .tabItem {
                    Image(systemName: "chart.bar.fill")
                    Text("Reports")
                }
                .tag(6)

            ProfileView()
                .tabItem {
                    Image(systemName: "person.fill")
                    Text("Profile")
                }
                .tag(7)
        }
        .tint(AppColors.accent)
    }
}
