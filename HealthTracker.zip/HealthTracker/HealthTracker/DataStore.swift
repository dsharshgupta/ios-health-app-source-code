import Foundation
import SwiftUI
import Combine
import UserNotifications

@MainActor
class DataStore: ObservableObject {
    @Published var meals: [Meal] = []
    @Published var weightLogs: [WeightLog] = []
    @Published var supplements: [Supplement] = ScheduleItem.dailySupplements
    @Published var apiKey: String = ""
    @Published var isAnalyzing = false
    @Published var waterLog: WaterLog = WaterLog(date: "", glasses: 0)
    @Published var exerciseLogs: [ExerciseLog] = []
    @Published var favorites: [FoodFavorite] = []
    @Published var healthKitData: HealthKitData = HealthKitData()
    @Published var isSyncingHealthData = false
    @Published var healthSyncMessage = ""

    // MARK: - Health Agent
    @Published var agentInsight: String = ""
    @Published var isAgentThinking = false
    @Published var agentLastUpdated: Date? = nil
    @Published var conversationHistory: [ConversationMessage] = []
    private let healthAgent = HealthAgent.shared

    // MARK: - New Features
    @Published var currentFasting: FastingSession = FastingSession()
    @Published var fastingLogs: [FastingLog] = []
    @Published var moodEntries: [MoodEntry] = []
    @Published var challenges: [Challenge] = []
    @Published var streaks: [Streak] = []
    @Published var weeklyDigests: [WeeklyDigest] = []
    @Published var editableLabValues: [EditableLabValue] = []
    @Published var customSupplements: [CustomSupplement] = []
    @Published var waterHistory: [WaterLog] = []
    @Published var sleepLogs: [SleepLog] = []
    @Published var proactiveWarnings: [String] = []
    @Published var todayChallenge: Challenge? = nil
    @Published var agentGoalSuggestion: String? = nil
    @Published var isGeneratingDigest = false
    @Published var isGeneratingChallenge = false
    @Published var isSuggestingMeal = false
    @Published var mealSuggestion: String? = nil

    private let mealsKey = "harsh_meals"
    private let weightsKey = "harsh_weights"
    private let suppsKey = "harsh_supps_date"
    private let apiKeyKey = "harsh_anthropic_key"
    private let waterKey = "harsh_water"
    private let exerciseKey = "harsh_exercise"
    private let favoritesKey = "harsh_favorites"
    private let healthKitKey = "harsh_healthkit"
    private let conversationKey = "harsh_conversation"
    private let fastingKey = "harsh_fasting"
    private let fastingLogsKey = "harsh_fasting_logs"
    private let moodKey = "harsh_mood"
    private let challengesKey = "harsh_challenges"
    private let streaksKey = "harsh_streaks"
    private let digestsKey = "harsh_digests"
    private let labValuesKey = "harsh_lab_values"
    private let customSuppsKey = "harsh_custom_supps"
    private let waterHistoryKey = "harsh_water_history"
    private let sleepLogsKey = "harsh_sleep_logs"
    private let healthKitManager = HealthKitManager()
    private var autoSyncTimer: Timer?
    nonisolated(unsafe) private var lastBackgroundSync: Date = .distantPast

    init() {
        waterLog = WaterLog(date: todayString(), glasses: 0)
        loadData()
    }

    // MARK: - Auto-Sync

    /// Call once on app launch to start background observers and periodic refresh.
    func startAutoSync() {
        // Start HealthKit observer queries — fires when Watch writes new data
        healthKitManager.startBackgroundObservers { [weak self] in
            guard let self = self else { return }
            // Debounce: skip if we synced less than 30 seconds ago
            let now = Date()
            guard now.timeIntervalSince(self.lastBackgroundSync) > 30 else { return }
            self.lastBackgroundSync = now

            Task { @MainActor in
                await self.syncAppleWatchData()
            }
        }

        // Also set a periodic timer to refresh every 5 minutes while the app is open
        autoSyncTimer?.invalidate()
        autoSyncTimer = Timer.scheduledTimer(withTimeInterval: 300, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            Task { @MainActor in
                await self.refreshConnectedHealthData()
            }
        }
    }

    func stopAutoSync() {
        healthKitManager.stopBackgroundObservers()
        autoSyncTimer?.invalidate()
        autoSyncTimer = nil
    }

    // MARK: - Persistence
    func loadData() {
        if let data = UserDefaults.standard.data(forKey: mealsKey),
           let decoded = try? JSONDecoder().decode([Meal].self, from: data) {
            meals = decoded
        }
        if let data = UserDefaults.standard.data(forKey: weightsKey),
           let decoded = try? JSONDecoder().decode([WeightLog].self, from: data) {
            weightLogs = decoded
        }
        if let data = UserDefaults.standard.data(forKey: exerciseKey),
           let decoded = try? JSONDecoder().decode([ExerciseLog].self, from: data) {
            exerciseLogs = decoded
        }
        if let data = UserDefaults.standard.data(forKey: favoritesKey),
           let decoded = try? JSONDecoder().decode([FoodFavorite].self, from: data) {
            favorites = decoded
        }
        if let data = UserDefaults.standard.data(forKey: healthKitKey),
           let decoded = try? JSONDecoder().decode(HealthKitData.self, from: data) {
            healthKitData = decoded
        }
        apiKey = UserDefaults.standard.string(forKey: apiKeyKey) ?? ""

        // Load supplement checks (reset daily)
        let savedDate = UserDefaults.standard.string(forKey: suppsKey) ?? ""
        if savedDate == todayString() {
            let checks = UserDefaults.standard.dictionary(forKey: "harsh_supp_checks") as? [String: Bool] ?? [:]
            for i in supplements.indices {
                supplements[i].isDone = checks["\(supplements[i].id)"] ?? false
            }
        }

        // Load water log (reset daily, archive yesterday)
        if let data = UserDefaults.standard.data(forKey: waterKey),
           let decoded = try? JSONDecoder().decode(WaterLog.self, from: data),
           decoded.date == todayString() {
            waterLog = decoded
        } else {
            // Archive yesterday's water before resetting
            if let data = UserDefaults.standard.data(forKey: waterKey),
               let yesterday = try? JSONDecoder().decode(WaterLog.self, from: data),
               yesterday.glasses > 0 {
                archiveWaterLog(yesterday)
            }
            waterLog = WaterLog(date: todayString(), glasses: 0)
        }

        // Load new feature data
        if let data = UserDefaults.standard.data(forKey: conversationKey),
           let decoded = try? JSONDecoder().decode([ConversationMessage].self, from: data) {
            conversationHistory = decoded
        }
        if let data = UserDefaults.standard.data(forKey: fastingKey),
           let decoded = try? JSONDecoder().decode(FastingSession.self, from: data) {
            currentFasting = decoded
        }
        if let data = UserDefaults.standard.data(forKey: fastingLogsKey),
           let decoded = try? JSONDecoder().decode([FastingLog].self, from: data) {
            fastingLogs = decoded
        }
        if let data = UserDefaults.standard.data(forKey: moodKey),
           let decoded = try? JSONDecoder().decode([MoodEntry].self, from: data) {
            moodEntries = decoded
        }
        if let data = UserDefaults.standard.data(forKey: challengesKey),
           let decoded = try? JSONDecoder().decode([Challenge].self, from: data) {
            challenges = decoded
        }
        if let data = UserDefaults.standard.data(forKey: streaksKey),
           let decoded = try? JSONDecoder().decode([Streak].self, from: data) {
            streaks = decoded
        }
        if let data = UserDefaults.standard.data(forKey: digestsKey),
           let decoded = try? JSONDecoder().decode([WeeklyDigest].self, from: data) {
            weeklyDigests = decoded
        }
        if let data = UserDefaults.standard.data(forKey: labValuesKey),
           let decoded = try? JSONDecoder().decode([EditableLabValue].self, from: data) {
            editableLabValues = decoded
        }
        if let data = UserDefaults.standard.data(forKey: customSuppsKey),
           let decoded = try? JSONDecoder().decode([CustomSupplement].self, from: data) {
            customSupplements = decoded
        }
        if let data = UserDefaults.standard.data(forKey: waterHistoryKey),
           let decoded = try? JSONDecoder().decode([WaterLog].self, from: data) {
            waterHistory = decoded
        }
        if let data = UserDefaults.standard.data(forKey: sleepLogsKey),
           let decoded = try? JSONDecoder().decode([SleepLog].self, from: data) {
            sleepLogs = decoded
        }

        // Seed editable lab values from hardcoded if first launch
        if editableLabValues.isEmpty {
            editableLabValues = labValues.map { EditableLabValue(from: $0) }
            saveLabValues()
        }

        // Seed custom supplements from hardcoded if first launch
        if customSupplements.isEmpty {
            customSupplements = ScheduleItem.dailySupplements.map { CustomSupplement(from: $0) }
            saveCustomSupplements()
        }

        // Initialize streaks if empty
        if streaks.isEmpty {
            streaks = StreakType.allCases.map { Streak(type: $0) }
            saveStreaks()
        }
    }

    func saveMeals() {
        if let data = try? JSONEncoder().encode(meals) {
            UserDefaults.standard.set(data, forKey: mealsKey)
        }
    }

    func saveWeights() {
        if let data = try? JSONEncoder().encode(weightLogs) {
            UserDefaults.standard.set(data, forKey: weightsKey)
        }
    }

    func saveSupplements() {
        UserDefaults.standard.set(todayString(), forKey: suppsKey)
        var checks: [String: Bool] = [:]
        for s in supplements { checks["\(s.id)"] = s.isDone }
        UserDefaults.standard.set(checks, forKey: "harsh_supp_checks")
    }

    func saveApiKey() {
        UserDefaults.standard.set(apiKey, forKey: apiKeyKey)
    }

    func saveWater() {
        waterLog = WaterLog(date: todayString(), glasses: waterLog.glasses)
        if let data = try? JSONEncoder().encode(waterLog) {
            UserDefaults.standard.set(data, forKey: waterKey)
        }
    }

    func saveExercise() {
        if let data = try? JSONEncoder().encode(exerciseLogs) {
            UserDefaults.standard.set(data, forKey: exerciseKey)
        }
    }

    func saveFavorites() {
        if let data = try? JSONEncoder().encode(favorites) {
            UserDefaults.standard.set(data, forKey: favoritesKey)
        }
    }

    func saveHealthKitData() {
        if let data = try? JSONEncoder().encode(healthKitData) {
            UserDefaults.standard.set(data, forKey: healthKitKey)
        }
    }

    func saveConversation() {
        // Cap at 50 messages
        let toSave = Array(conversationHistory.suffix(50))
        if let data = try? JSONEncoder().encode(toSave) {
            UserDefaults.standard.set(data, forKey: conversationKey)
        }
    }

    func saveFasting() {
        if let data = try? JSONEncoder().encode(currentFasting) {
            UserDefaults.standard.set(data, forKey: fastingKey)
        }
    }

    func saveFastingLogs() {
        if let data = try? JSONEncoder().encode(fastingLogs) {
            UserDefaults.standard.set(data, forKey: fastingLogsKey)
        }
    }

    func saveMoodEntries() {
        if let data = try? JSONEncoder().encode(moodEntries) {
            UserDefaults.standard.set(data, forKey: moodKey)
        }
    }

    func saveChallenges() {
        if let data = try? JSONEncoder().encode(challenges) {
            UserDefaults.standard.set(data, forKey: challengesKey)
        }
    }

    func saveStreaks() {
        if let data = try? JSONEncoder().encode(streaks) {
            UserDefaults.standard.set(data, forKey: streaksKey)
        }
    }

    func saveDigests() {
        if let data = try? JSONEncoder().encode(weeklyDigests) {
            UserDefaults.standard.set(data, forKey: digestsKey)
        }
    }

    func saveLabValues() {
        if let data = try? JSONEncoder().encode(editableLabValues) {
            UserDefaults.standard.set(data, forKey: labValuesKey)
        }
    }

    func saveCustomSupplements() {
        if let data = try? JSONEncoder().encode(customSupplements) {
            UserDefaults.standard.set(data, forKey: customSuppsKey)
        }
    }

    func saveWaterHistory() {
        if let data = try? JSONEncoder().encode(waterHistory) {
            UserDefaults.standard.set(data, forKey: waterHistoryKey)
        }
    }

    func saveSleepLogs() {
        if let data = try? JSONEncoder().encode(sleepLogs) {
            UserDefaults.standard.set(data, forKey: sleepLogsKey)
        }
    }

    private func archiveWaterLog(_ log: WaterLog) {
        if !waterHistory.contains(where: { $0.date == log.date }) {
            waterHistory.append(log)
            // Keep last 90 days
            if waterHistory.count > 90 {
                waterHistory = Array(waterHistory.suffix(90))
            }
            saveWaterHistory()
        }
    }

    // MARK: - Today's Data
    var todayMeals: [Meal] {
        meals.filter { $0.date == todayString() }
    }

    var totalCalories: Int { todayMeals.reduce(0) { $0 + $1.calories } }
    var totalProtein: Int { todayMeals.reduce(0) { $0 + $1.protein } }
    var totalCarbs: Int { todayMeals.reduce(0) { $0 + $1.carbs } }
    var totalFat: Int { todayMeals.reduce(0) { $0 + $1.fat } }
    var remainingCalories: Int { Profile.dailyCalories - totalCalories }

    var currentWeight: Double {
        sortedWeightLogs.last?.kg ?? Profile.startWeight
    }

    var weightLost: Double {
        Profile.startWeight - currentWeight
    }

    var sortedWeightLogs: [WeightLog] {
        weightLogs.sorted { lhs, rhs in
            if lhs.date == rhs.date {
                return lhs.id < rhs.id
            }
            return lhs.date < rhs.date
        }
    }

    var todayWeightLog: WeightLog? {
        sortedWeightLogs.last(where: { $0.date == todayString() })
    }

    var averageWeightLast7: Double {
        let recent = sortedWeightLogs.suffix(7)
        guard !recent.isEmpty else { return currentWeight }
        let total = recent.reduce(0.0) { $0 + $1.kg }
        return total / Double(recent.count)
    }

    var weightChangeLast7: Double {
        let recent = sortedWeightLogs.suffix(7)
        guard let first = recent.first, let last = recent.last else { return 0 }
        return last.kg - first.kg
    }

    var doneCount: Int {
        supplements.filter(\.isDone).count
    }

    // MARK: - Water
    var waterGlasses: Int { waterLog.glasses }
    var waterLiters: Double { waterLog.liters }
    var waterProgress: Double { min(waterLog.liters / Profile.waterTarget, 1.0) }

    func addWaterGlass() {
        waterLog = WaterLog(date: todayString(), glasses: waterLog.glasses + 1)
        saveWater()
    }

    func removeWaterGlass() {
        guard waterLog.glasses > 0 else { return }
        waterLog = WaterLog(date: todayString(), glasses: waterLog.glasses - 1)
        saveWater()
    }

    // MARK: - Exercise
    var todayExercise: [ExerciseLog] {
        exerciseLogs.filter { $0.date == todayString() }
    }

    var todayExerciseMinutes: Int {
        let loggedMinutes = todayExercise.reduce(0) { $0 + $1.durationMinutes }
        // Estimate minutes from Watch steps if no workouts logged (1000 steps ≈ 10 min of activity)
        if healthKitData.isAuthorized && loggedMinutes == 0 && healthKitData.steps > 0 {
            let estimatedMinutes = healthKitData.steps / 100
            return max(loggedMinutes, estimatedMinutes)
        }
        return loggedMinutes
    }

    var todayExerciseCalories: Int {
        let loggedCalories = todayExercise.reduce(0) { $0 + $1.caloriesBurned }
        // Use the higher of Watch active calories vs logged exercise calories
        if healthKitData.isAuthorized && healthKitData.activeCalories > 0 {
            return max(loggedCalories, Int(healthKitData.activeCalories.rounded()))
        }
        return loggedCalories
    }

    var weekExerciseMinutes: Int {
        let days = last7Days()
        return exerciseLogs.filter { days.contains($0.date) }.reduce(0) { $0 + $1.durationMinutes }
    }

    var weekExerciseCalories: Int {
        let days = last7Days()
        return exerciseLogs.filter { days.contains($0.date) }.reduce(0) { $0 + $1.caloriesBurned }
    }

    var exerciseStreak: Int {
        var streak = 0
        var date = Date()
        while true {
            let dateStr = dateString(for: date)
            if exerciseLogs.contains(where: { $0.date == dateStr }) {
                streak += 1
                date = Calendar.current.date(byAdding: .day, value: -1, to: date)!
            } else {
                break
            }
        }
        return streak
    }

    var dailyScore: DailyScore {
        let calorieVariance = abs(Profile.dailyCalories - totalCalories)
        let calorieScore: Int
        switch calorieVariance {
        case ..<150: calorieScore = 25
        case ..<300: calorieScore = 20
        case ..<500: calorieScore = 14
        default: calorieScore = totalCalories == 0 ? 0 : 8
        }

        let proteinScore = min(Int((Double(totalProtein) / Double(Profile.proteinTarget)) * 25), 25)
        let exerciseScore = min(Int((Double(todayExerciseMinutes) / 30.0) * 20), 20)
        let waterScore = min(Int(waterProgress * 15), 15)
        let supplementScore = min(Int((supplementComplianceToday() / 100.0) * 15), 15)

        return DailyScore(
            calorieScore: calorieScore,
            proteinScore: proteinScore,
            exerciseScore: exerciseScore,
            waterScore: waterScore,
            supplementScore: supplementScore
        )
    }

    var dailyFocusTitle: String {
        if healthKitData.isAuthorized && healthKitData.sleepHours > 0 && healthKitData.sleepHours < Profile.sleepTarget {
            return "Recovery first"
        }
        if totalProtein < Profile.proteinTarget {
            return "Protein push"
        }
        if waterLiters < Profile.waterTarget * 0.6 {
            return "Hydration catch-up"
        }
        if todayExerciseMinutes < 30 {
            return "Movement block"
        }
        return "Keep momentum"
    }

    var dailyFocusMessage: String {
        if healthKitData.isAuthorized && healthKitData.sleepHours > 0 && healthKitData.sleepHours < Profile.sleepTarget {
            let deficit = max(Profile.sleepTarget - healthKitData.sleepHours, 0)
            return "Watch data shows \(String(format: "%.1f", healthKitData.sleepHours))h sleep. Keep training moderate and try to recover \(String(format: "%.1f", deficit))h more tonight."
        }
        if totalProtein < Profile.proteinTarget {
            let remaining = max(Profile.proteinTarget - totalProtein, 0)
            return "You still need about \(remaining)g protein today. Eggs, whey, paneer, or curd will fit Harsh's cut well."
        }
        if waterLiters < Profile.waterTarget * 0.6 {
            let glassesLeft = max(Int(ceil((Profile.waterTarget - waterLiters) / 0.25)), 0)
            return "Hydration is trailing. Knock out \(glassesLeft) more glasses before dinner to avoid a late-night chug."
        }
        if todayExerciseMinutes < 30 {
            return "A short walk or 20-minute lift will keep the fat-loss plan on track without blowing up recovery."
        }
        return "Today is shaping up well. Stay steady on dinner portions and finish the supplement checklist."
    }

    var watchRecoveryColor: Color {
        guard healthKitData.isAuthorized else { return AppColors.subtleText }
        if healthKitData.sleepHours >= Profile.sleepTarget && healthKitData.restingHeartRate > 0 && healthKitData.restingHeartRate <= 65 {
            return AppColors.green
        }
        if healthKitData.sleepHours >= 6 {
            return AppColors.orange
        }
        return AppColors.red
    }

    // MARK: - Expert Health KPIs

    /// Dynamic BMI from current weight
    var currentBMI: Double {
        currentWeight / ((Profile.heightCm / 100) * (Profile.heightCm / 100))
    }

    var bmiCategory: String {
        switch currentBMI {
        case ..<18.5: return "Underweight"
        case 18.5..<25: return "Normal"
        case 25..<30: return "Overweight"
        default: return "Obese"
        }
    }

    var bmiColor: Color {
        switch currentBMI {
        case ..<18.5: return AppColors.orange
        case 18.5..<25: return AppColors.green
        case 25..<30: return AppColors.orange
        default: return AppColors.red
        }
    }

    /// Basal Metabolic Rate (Mifflin-St Jeor for males)
    var bmr: Double {
        10 * currentWeight + 6.25 * Profile.heightCm - 5 * Double(Profile.age) + 5
    }

    /// Total Daily Energy Expenditure (BMR × activity multiplier)
    var tdee: Double {
        // Moderate activity factor = 1.55 (workouts 3-5 days/week)
        let activityFactor: Double
        let weekMin = weekExerciseMinutes
        switch weekMin {
        case ..<60: activityFactor = 1.2       // Sedentary
        case 60..<150: activityFactor = 1.375  // Lightly active
        case 150..<300: activityFactor = 1.55  // Moderately active
        case 300..<420: activityFactor = 1.725 // Very active
        default: activityFactor = 1.9          // Extremely active
        }
        return bmr * activityFactor
    }

    /// Estimated body fat % (US Navy method simplified for males, using BMI-based estimate)
    var estimatedBodyFat: Double {
        // Deurenberg formula: BF% = 1.20 × BMI + 0.23 × Age − 16.2 (male)
        max(1.20 * currentBMI + 0.23 * Double(Profile.age) - 16.2, 3)
    }

    var bodyFatCategory: String {
        switch estimatedBodyFat {
        case ..<6: return "Essential"
        case 6..<14: return "Athletic"
        case 14..<18: return "Fit"
        case 18..<25: return "Average"
        default: return "Above Average"
        }
    }

    /// Lean body mass
    var leanBodyMass: Double {
        currentWeight * (1 - estimatedBodyFat / 100)
    }

    /// Daily caloric deficit/surplus
    var caloricBalance: Int {
        totalCalories - Int(tdee.rounded())
    }

    /// Net calories (eaten minus exercise burned)
    var netCalories: Int {
        totalCalories - todayExerciseCalories
    }

    /// Protein per kg of bodyweight
    var proteinPerKg: Double {
        Double(totalProtein) / currentWeight
    }

    /// Macro ratio percentages
    var macroRatioProtein: Double {
        let totalMacroCalories = Double(totalProtein * 4 + totalCarbs * 4 + totalFat * 9)
        guard totalMacroCalories > 0 else { return 0 }
        return Double(totalProtein * 4) / totalMacroCalories * 100
    }

    var macroRatioCarbs: Double {
        let totalMacroCalories = Double(totalProtein * 4 + totalCarbs * 4 + totalFat * 9)
        guard totalMacroCalories > 0 else { return 0 }
        return Double(totalCarbs * 4) / totalMacroCalories * 100
    }

    var macroRatioFat: Double {
        let totalMacroCalories = Double(totalProtein * 4 + totalCarbs * 4 + totalFat * 9)
        guard totalMacroCalories > 0 else { return 0 }
        return Double(totalFat * 9) / totalMacroCalories * 100
    }

    /// Weekly weight velocity (kg per week)
    var weeklyWeightVelocity: Double {
        let sorted = sortedWeightLogs
        guard sorted.count >= 2 else { return 0 }
        let recent = Array(sorted.suffix(14)) // Last 2 weeks for smoothing
        guard recent.count >= 2 else { return 0 }
        let f = DateFormatter(); f.dateFormat = "yyyy-MM-dd"
        guard let firstDate = f.date(from: recent.first!.date),
              let lastDate = f.date(from: recent.last!.date) else { return 0 }
        let weeks = max(lastDate.timeIntervalSince(firstDate) / (7 * 86400), 0.14) // min 1 day
        return (recent.last!.kg - recent.first!.kg) / weeks
    }

    /// Estimated days to reach target weight
    var daysToGoal: Int? {
        let remaining = currentWeight - Profile.targetWeight
        guard remaining > 0 else { return 0 }
        // Use weekly velocity if losing, else use default 0.5 kg/week
        let weeklyLoss: Double
        if weeklyWeightVelocity < -0.05 {
            weeklyLoss = abs(weeklyWeightVelocity)
        } else {
            weeklyLoss = 0.5 // Default estimate
        }
        guard weeklyLoss > 0 else { return nil }
        return Int(ceil(remaining / weeklyLoss * 7))
    }

    /// Estimated goal date
    var estimatedGoalDate: String? {
        guard let days = daysToGoal, days > 0 else {
            if let days = daysToGoal, days == 0 { return "Goal reached!" }
            return nil
        }
        let date = Calendar.current.date(byAdding: .day, value: days, to: Date())!
        let f = DateFormatter(); f.dateFormat = "MMM yyyy"
        return f.string(from: date)
    }

    /// Recovery score (0-100) based on sleep + HRV + resting HR
    var recoveryScore: Int {
        guard healthKitData.isAuthorized else { return 0 }
        var score = 0.0

        // Sleep component (0-40)
        if healthKitData.sleepHours > 0 {
            let sleepRatio = min(healthKitData.sleepHours / Profile.sleepTarget, 1.2)
            score += sleepRatio * 40
        }

        // HRV component (0-30) — higher is better, typical range 20-80ms
        if healthKitData.hrv > 0 {
            let hrvScore = min(healthKitData.hrv / 60.0, 1.0) // 60ms = excellent
            score += hrvScore * 30
        }

        // Resting HR component (0-30) — lower is better
        if healthKitData.restingHeartRate > 0 {
            let hrScore: Double
            switch healthKitData.restingHeartRate {
            case ..<55: hrScore = 1.0
            case 55..<65: hrScore = 0.8
            case 65..<75: hrScore = 0.6
            case 75..<85: hrScore = 0.4
            default: hrScore = 0.2
            }
            score += hrScore * 30
        }

        return min(Int(score.rounded()), 100)
    }

    var recoveryLabel: String {
        switch recoveryScore {
        case 80...100: return "Optimal"
        case 60..<80: return "Good"
        case 40..<60: return "Moderate"
        case 20..<40: return "Low"
        default: return "Poor"
        }
    }

    var recoveryColor: Color {
        switch recoveryScore {
        case 80...100: return AppColors.green
        case 60..<80: return AppColors.blue
        case 40..<60: return AppColors.orange
        default: return AppColors.red
        }
    }

    /// Cardiovascular fitness indicator (simplified VO2max estimate)
    /// Uses resting HR-based Uth–Sørensen–Overgaard–Pedersen formula
    var estimatedVO2Max: Double? {
        guard healthKitData.isAuthorized, healthKitData.restingHeartRate > 0 else { return nil }
        // VO2max ≈ 15.3 × (HRmax / HRrest)
        let hrMax = 220.0 - Double(Profile.age)
        return 15.3 * (hrMax / healthKitData.restingHeartRate)
    }

    var vo2MaxCategory: String {
        guard let vo2 = estimatedVO2Max else { return "N/A" }
        // Male 25 y/o categories
        switch vo2 {
        case ..<35: return "Poor"
        case 35..<40: return "Below Avg"
        case 40..<44: return "Average"
        case 44..<49: return "Good"
        case 49..<55: return "Excellent"
        default: return "Superior"
        }
    }

    /// Hydration efficiency (actual vs target)
    var hydrationEfficiency: Double {
        min(waterLiters / Profile.waterTarget * 100, 100)
    }

    /// Fiber intake today
    var totalFiber: Int {
        todayMeals.reduce(0) { $0 + $1.fiber }
    }

    /// Calorie-to-protein ratio (lower = more protein-dense diet)
    var calorieProteinRatio: Double {
        guard totalProtein > 0 else { return 0 }
        return Double(totalCalories) / Double(totalProtein)
    }

    /// Steps per km (walking efficiency)
    var stepsPerKm: Double? {
        guard healthKitData.isAuthorized, healthKitData.distanceKm > 0.1 else { return nil }
        return Double(healthKitData.steps) / healthKitData.distanceKm
    }

    /// Overall wellness score (0-100) — composite of all metrics
    var wellnessScore: Int {
        var score = 0.0
        var maxScore = 0.0

        // Nutrition (35 points)
        maxScore += 35
        let calVariance = abs(Double(totalCalories - Profile.dailyCalories)) / Double(Profile.dailyCalories)
        score += max(1 - calVariance, 0) * 15 // Calorie adherence
        score += min(Double(totalProtein) / Double(Profile.proteinTarget), 1) * 12 // Protein
        score += min(waterLiters / Profile.waterTarget, 1) * 8 // Water

        // Activity (25 points)
        maxScore += 25
        score += min(Double(todayExerciseMinutes) / 30.0, 1) * 15 // Exercise
        if healthKitData.isAuthorized && healthKitData.steps > 0 {
            score += min(Double(healthKitData.steps) / 10000.0, 1) * 10 // Steps
        } else {
            maxScore -= 10
        }

        // Recovery (25 points)
        if healthKitData.isAuthorized {
            maxScore += 25
            score += Double(recoveryScore) / 100.0 * 25
        }

        // Compliance (15 points)
        maxScore += 15
        score += supplementComplianceToday() / 100.0 * 15

        guard maxScore > 0 else { return 0 }
        return min(Int((score / maxScore * 100).rounded()), 100)
    }

    var wellnessLabel: String {
        switch wellnessScore {
        case 90...100: return "Elite"
        case 75..<90: return "Excellent"
        case 60..<75: return "Good"
        case 45..<60: return "Fair"
        default: return "Needs Work"
        }
    }

    var wellnessColor: Color {
        switch wellnessScore {
        case 75...100: return AppColors.green
        case 60..<75: return AppColors.blue
        case 45..<60: return AppColors.orange
        default: return AppColors.red
        }
    }

    func addExercise(_ log: ExerciseLog) {
        exerciseLogs.append(log)
        saveExercise()
    }

    func removeExercise(_ id: String) {
        exerciseLogs.removeAll { $0.id == id }
        saveExercise()
    }

    // MARK: - Favorites
    func addToFavorites(_ meal: Meal) {
        if let idx = favorites.firstIndex(where: { $0.rawInput.lowercased() == meal.rawInput.lowercased() }) {
            favorites[idx].useCount += 1
        } else {
            favorites.append(FoodFavorite(from: meal))
        }
        saveFavorites()
    }

    func removeFavorite(_ id: String) {
        favorites.removeAll { $0.id == id }
        saveFavorites()
    }

    func addMealFromFavorite(_ fav: FoodFavorite) {
        let meal = Meal(
            date: todayString(),
            name: fav.name,
            calories: fav.calories,
            protein: fav.protein,
            carbs: fav.carbs,
            fat: fav.fat,
            fiber: fav.fiber,
            serving: fav.serving,
            rawInput: fav.rawInput
        )
        addMeal(meal)
        if let idx = favorites.firstIndex(where: { $0.id == fav.id }) {
            favorites[idx].useCount += 1
            saveFavorites()
        }
    }

    // MARK: - Reports
    func mealsForDate(_ dateStr: String) -> [Meal] {
        meals.filter { $0.date == dateStr }
    }

    func caloriesForDate(_ dateStr: String) -> Int {
        mealsForDate(dateStr).reduce(0) { $0 + $1.calories }
    }

    func proteinForDate(_ dateStr: String) -> Int {
        mealsForDate(dateStr).reduce(0) { $0 + $1.protein }
    }

    func exerciseMinutesForDate(_ dateStr: String) -> Int {
        exerciseLogs.filter { $0.date == dateStr }.reduce(0) { $0 + $1.durationMinutes }
    }

    func exerciseCaloriesForDate(_ dateStr: String) -> Int {
        exerciseLogs.filter { $0.date == dateStr }.reduce(0) { $0 + $1.caloriesBurned }
    }

    func avgCaloriesLast7() -> Int {
        let days = last7Days()
        let total = days.reduce(0) { $0 + caloriesForDate($1) }
        let activeDays = days.filter { caloriesForDate($0) > 0 }.count
        return activeDays > 0 ? total / activeDays : 0
    }

    func avgProteinLast7() -> Int {
        let days = last7Days()
        let total = days.reduce(0) { $0 + proteinForDate($1) }
        let activeDays = days.filter { proteinForDate($0) > 0 }.count
        return activeDays > 0 ? total / activeDays : 0
    }

    func proteinComplianceLast7() -> Double {
        let days = last7Days()
        let compliant = days.filter { proteinForDate($0) >= Profile.proteinTarget }.count
        let active = days.filter { caloriesForDate($0) > 0 }.count
        return active > 0 ? Double(compliant) / Double(active) * 100 : 0
    }

    func supplementComplianceToday() -> Double {
        let total = supplements.count
        return total > 0 ? Double(doneCount) / Double(total) * 100 : 0
    }

    // MARK: - Actions
    func toggleSupplement(_ id: Int) {
        if let idx = supplements.firstIndex(where: { $0.id == id }) {
            supplements[idx].isDone.toggle()
            saveSupplements()
        }
    }

    func addMeal(_ meal: Meal) {
        meals.append(meal)
        saveMeals()
    }

    func removeMeal(_ id: String) {
        meals.removeAll { $0.id == id }
        saveMeals()
    }

    func addWeight(_ kg: Double, on date: String = todayString()) {
        if let idx = weightLogs.lastIndex(where: { $0.date == date }) {
            weightLogs[idx].kg = kg
        } else {
            let log = WeightLog(date: date, kg: kg)
            weightLogs.append(log)
        }
        weightLogs = sortedWeightLogs
        saveWeights()
    }

    func updateWeight(id: String, kg: Double, date: String) {
        guard let idx = weightLogs.firstIndex(where: { $0.id == id }) else { return }
        weightLogs[idx].kg = kg
        weightLogs[idx].date = date
        weightLogs = sortedWeightLogs
        saveWeights()
    }

    func removeWeight(_ id: String) {
        weightLogs.removeAll { $0.id == id }
        saveWeights()
    }

    func importWatchWorkouts(_ workouts: [WatchWorkout]) -> Int {
        var imported = 0

        for workout in workouts where !exerciseLogs.contains(where: { $0.sourceIdentifier == workout.sourceIdentifier }) {
            exerciseLogs.append(
                ExerciseLog(
                    date: workout.date,
                    type: workout.type,
                    durationMinutes: workout.durationMinutes,
                    caloriesBurned: workout.caloriesBurned,
                    inputMethod: .appleWatch,
                    sourceIdentifier: workout.sourceIdentifier
                )
            )
            imported += 1
        }

        if imported > 0 {
            saveExercise()
        }

        return imported
    }

    func syncAppleWatchData(includeWorkouts: Bool = true) async {
        guard healthKitManager.isAvailable else {
            healthSyncMessage = "Apple Watch sync works only on an iPhone with Health access."
            healthKitData.isAuthorized = false
            saveHealthKitData()
            return
        }

        isSyncingHealthData = true
        healthSyncMessage = ""

        let authorized = await healthKitManager.requestAuthorization()
        guard authorized else {
            healthKitData.isAuthorized = false
            isSyncingHealthData = false
            healthSyncMessage = "Health access wasn't granted, so watch vitals couldn't sync."
            saveHealthKitData()
            return
        }

        healthKitData = await healthKitManager.fetchTodayHealthData()
        let importedWorkouts = includeWorkouts ? importWatchWorkouts(await healthKitManager.fetchTodayWorkouts()) : 0
        saveHealthKitData()
        // Force UI refresh for computed properties that depend on healthKitData
        objectWillChange.send()

        if includeWorkouts {
            healthSyncMessage = importedWorkouts > 0
                ? "Synced vitals and imported \(importedWorkouts) Apple Watch workout\(importedWorkouts == 1 ? "" : "s")."
                : "Synced vitals. No new Apple Watch workouts to import."
        } else {
            healthSyncMessage = "Synced the latest Apple Watch vitals."
        }

        isSyncingHealthData = false
    }

    func refreshConnectedHealthData() async {
        guard healthKitData.isAuthorized else { return }
        await syncAppleWatchData(includeWorkouts: false)
    }

    // MARK: - Weight Prediction
    func predictWeights(months: Int = 6) -> [WeightPrediction] {
        let cw = currentWeight

        if weightLogs.count < 2 {
            return (1...months).map { i in
                let date = Calendar.current.date(byAdding: .month, value: i, to: Date())!
                let f = DateFormatter(); f.dateFormat = "MMM"
                let predicted = max(cw - Double(i) * 1.8, Profile.targetWeight)
                return WeightPrediction(month: f.string(from: date), kg: (predicted * 10).rounded() / 10)
            }
        }

        let sorted = weightLogs.sorted { $0.date < $1.date }
        let f = DateFormatter(); f.dateFormat = "yyyy-MM-dd"
        guard let startDate = f.date(from: sorted[0].date) else { return [] }

        let xs = sorted.map { f.date(from: $0.date)!.timeIntervalSince(startDate) / 86400 }
        let ys = sorted.map(\.kg)
        let n = Double(xs.count)
        let sx = xs.reduce(0, +), sy = ys.reduce(0, +)
        let sxy = zip(xs, ys).reduce(0.0) { $0 + $1.0 * $1.1 }
        let sx2 = xs.reduce(0.0) { $0 + $1 * $1 }
        let slope = (n * sxy - sx * sy) / (n * sx2 - sx * sx)
        let intercept = (sy - slope * sx) / n
        let lastDay = xs.last ?? 0

        let mf = DateFormatter(); mf.dateFormat = "MMM"
        return (1...months).map { i in
            let futureDay = lastDay + Double(i * 30)
            let date = Calendar.current.date(byAdding: .month, value: i, to: Date())!
            let predicted = max(intercept + slope * futureDay, Profile.targetWeight)
            return WeightPrediction(month: mf.string(from: date), kg: (predicted * 10).rounded() / 10)
        }
    }

    // MARK: - Fasting
    func startFast(targetHours: Double = 16) {
        currentFasting = FastingSession(startTime: Date(), targetHours: targetHours)
        saveFasting()
    }

    func endFast() {
        guard currentFasting.isActive else { return }
        currentFasting.endTime = Date()
        let log = FastingLog(from: currentFasting)
        fastingLogs.append(log)
        saveFastingLogs()
        currentFasting = FastingSession()
        saveFasting()
    }

    func cancelFast() {
        currentFasting = FastingSession()
        saveFasting()
    }

    var fastingStreak: Int {
        let sorted = fastingLogs.sorted { $0.endTime > $1.endTime }
        var streak = 0
        var date = Date()
        for _ in 0..<365 {
            let dateStr = dateString(for: date)
            if sorted.contains(where: { dateString(for: $0.endTime) == dateStr && $0.completed }) {
                streak += 1
            } else if dateStr != todayString() {
                break
            }
            date = Calendar.current.date(byAdding: .day, value: -1, to: date)!
        }
        return streak
    }

    // MARK: - Mood
    var todayMood: MoodEntry? {
        moodEntries.first { $0.date == todayString() }
    }

    func logMood(mood: Int, energy: Int, notes: String = "") {
        // Replace if already logged today
        moodEntries.removeAll { $0.date == todayString() }
        moodEntries.append(MoodEntry(date: todayString(), mood: mood, energy: energy, notes: notes))
        saveMoodEntries()
    }

    func moodTrendLast7() -> (avgMood: Double, avgEnergy: Double) {
        let days = last7Days()
        let recent = moodEntries.filter { days.contains($0.date) }
        guard !recent.isEmpty else { return (0, 0) }
        let avgMood = Double(recent.reduce(0) { $0 + $1.mood }) / Double(recent.count)
        let avgEnergy = Double(recent.reduce(0) { $0 + $1.energy }) / Double(recent.count)
        return (avgMood, avgEnergy)
    }

    // MARK: - Streaks
    func updateStreaks() {
        let today = todayString()
        let yesterday = dateString(for: Calendar.current.date(byAdding: .day, value: -1, to: Date())!)

        for i in streaks.indices {
            let met: Bool
            switch streaks[i].type {
            case .exercise:
                met = !todayExercise.isEmpty
            case .water:
                met = waterLiters >= Profile.waterTarget
            case .protein:
                met = totalProtein >= Profile.proteinTarget
            case .logging:
                met = !todayMeals.isEmpty
            case .fasting:
                met = fastingLogs.contains { dateString(for: $0.endTime) == today && $0.completed }
            }

            if met && streaks[i].lastDate != today {
                if streaks[i].lastDate == yesterday {
                    streaks[i].currentCount += 1
                } else {
                    streaks[i].currentCount = 1
                }
                streaks[i].lastDate = today
                streaks[i].longestCount = max(streaks[i].longestCount, streaks[i].currentCount)
            }
        }
        saveStreaks()
    }

    // MARK: - Historical Data Helpers
    func waterForDate(_ dateStr: String) -> Double {
        if dateStr == todayString() { return waterLiters }
        return waterHistory.first { $0.date == dateStr }?.liters ?? 0
    }

    func caloriesForDateRange(_ days: [String]) -> [(String, Int)] {
        days.map { ($0, caloriesForDate($0)) }
    }

    func proteinForDateRange(_ days: [String]) -> [(String, Int)] {
        days.map { ($0, proteinForDate($0)) }
    }

    func exerciseForDateRange(_ days: [String]) -> [(String, Int)] {
        days.map { ($0, exerciseMinutesForDate($0)) }
    }

    func moodForDateRange(_ days: [String]) -> [MoodEntry] {
        moodEntries.filter { days.contains($0.date) }
    }

    func sleepForDateRange(_ days: [String]) -> [SleepLog] {
        sleepLogs.filter { days.contains($0.date) }
    }

    // MARK: - Proactive Warnings
    func checkProactiveWarnings() {
        var warnings: [String] = []
        let hour = Calendar.current.component(.hour, from: Date())

        // Late day, low calories
        if hour >= 18 && totalCalories < 800 && totalCalories > 0 {
            warnings.append("Only \(totalCalories) cal by evening. Plan a protein-rich dinner to hit your target.")
        }

        // Late day, very low protein
        if hour >= 20 && totalProtein < 60 {
            warnings.append("Protein is critically low at \(totalProtein)g. Consider whey or paneer before bed.")
        }

        // Afternoon, low water
        if hour >= 15 && waterLiters < 1.5 {
            let glassesNeeded = Int(ceil((Profile.waterTarget - waterLiters) / 0.25))
            warnings.append("Hydration behind — \(glassesNeeded) more glasses needed before end of day.")
        }

        // Exercise streak at risk
        if hour >= 19 && todayExercise.isEmpty && exerciseStreak > 2 {
            warnings.append("Your \(exerciseStreak)-day exercise streak is at risk! A quick walk counts.")
        }

        // Fasting nearing completion
        if currentFasting.isActive && !currentFasting.isComplete {
            let remaining = currentFasting.targetHours - currentFasting.elapsedHours
            if remaining > 0 && remaining < 1 {
                warnings.append("Fast ends in \(Int(remaining * 60)) minutes! Almost there.")
            }
        }

        // Calorie overshoot
        if totalCalories > Profile.dailyCalories + 200 {
            let over = totalCalories - Profile.dailyCalories
            warnings.append("You're \(over) cal over target. Light dinner or extra walk recommended.")
        }

        proactiveWarnings = warnings
    }

    // MARK: - Sleep Tracking
    func archiveSleepFromHealthKit() {
        guard healthKitData.isAuthorized && healthKitData.sleepHours > 0 else { return }
        let today = todayString()
        guard !sleepLogs.contains(where: { $0.date == today && $0.source == "apple_watch" }) else { return }

        // Estimate bedtime/wake from sleep hours
        let wakeTime = Date()
        let bedtime = wakeTime.addingTimeInterval(-healthKitData.sleepHours * 3600)
        let log = SleepLog(date: today, bedtime: bedtime, wakeTime: wakeTime, source: "apple_watch")
        sleepLogs.append(log)
        saveSleepLogs()
    }

    func sleepTrendLast7() -> (avgHours: Double, consistency: Double) {
        let days = last7Days()
        let logs = sleepLogs.filter { days.contains($0.date) }
        guard !logs.isEmpty else { return (0, 0) }
        let avgHours = logs.reduce(0.0) { $0 + $1.hours } / Double(logs.count)

        // Consistency: how close each night is to the average (0-100)
        let variance = logs.reduce(0.0) { $0 + abs($1.hours - avgHours) } / Double(logs.count)
        let consistency = max(0, 100 - variance * 20) // 0.5h variance = 90%, 2.5h = 50%
        return (avgHours, consistency)
    }

    // MARK: - Trend Summary for Agent
    func buildTrendSummary() -> String {
        let days = last7Days()
        let calData = caloriesForDateRange(days).filter { $0.1 > 0 }
        let proData = proteinForDateRange(days).filter { $0.1 > 0 }
        let exData = exerciseForDateRange(days)

        let avgCal = calData.isEmpty ? 0 : calData.reduce(0) { $0 + $1.1 } / calData.count
        let avgPro = proData.isEmpty ? 0 : proData.reduce(0) { $0 + $1.1 } / proData.count
        let proteinDaysOnTarget = proData.filter { $0.1 >= Profile.proteinTarget }.count
        let exerciseDaysActive = exData.filter { $0.1 > 0 }.count
        let totalExMin = exData.reduce(0) { $0 + $1.1 }

        let (sleepAvg, sleepConsistency) = sleepTrendLast7()
        let moodTrend = moodTrendLast7()

        var trend = "7-DAY TRENDS:\n"
        trend += "- Avg calories: \(avgCal)/1750 (\(calData.count) days tracked)\n"
        trend += "- Avg protein: \(avgPro)/120g (\(proteinDaysOnTarget)/\(proData.count) days on target)\n"
        trend += "- Exercise: \(totalExMin) min across \(exerciseDaysActive) days (target: 150 min/week)\n"
        trend += "- Weight trend: \(String(format: "%.1f", weeklyWeightVelocity)) kg/week\n"

        if sleepAvg > 0 {
            trend += "- Sleep: avg \(String(format: "%.1f", sleepAvg))h, consistency \(Int(sleepConsistency))%\n"
        }
        if moodTrend.avgMood > 0 {
            trend += "- Mood: \(String(format: "%.1f", moodTrend.avgMood))/5, Energy: \(String(format: "%.1f", moodTrend.avgEnergy))/5\n"
        }
        if currentFasting.isActive {
            trend += "- Currently fasting: \(String(format: "%.1f", currentFasting.elapsedHours))/\(Int(currentFasting.targetHours))h\n"
        }

        return trend
    }

    // MARK: - Anthropic AI (Haiku 4.5)
    func analyzeFood(_ text: String) async -> GeminiFood? {
        guard !apiKey.isEmpty else { return nil }

        let maxRetries = 2
        for attempt in 0..<maxRetries {
            if attempt > 0 {
                try? await Task.sleep(nanoseconds: UInt64(attempt) * 1_500_000_000) // 1.5s backoff
            }

            let url = URL(string: "https://api.anthropic.com/v1/messages")!
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.setValue(apiKey, forHTTPHeaderField: "x-api-key")
            request.setValue("2023-06-01", forHTTPHeaderField: "anthropic-version")
            request.timeoutInterval = 30

            let prompt = """
            You are an Indian food nutrition expert. Analyze this food and return ONLY valid JSON (no markdown, no backticks): {"name":"cleaned food name","calories":number,"protein":number,"carbs":number,"fat":number,"fiber":number,"serving":"estimated serving"}. Be accurate for Indian portions and cooking styles (ghee, oil, masala). If multiple items, sum totals. Food: "\(text)"
            """

            let body: [String: Any] = [
                "model": "claude-haiku-4-5-20251001",
                "max_tokens": 300,
                "temperature": 0.1,
                "messages": [
                    ["role": "user", "content": prompt]
                ]
            ]

            request.httpBody = try? JSONSerialization.data(withJSONObject: body)

            do {
                let (data, response) = try await URLSession.shared.data(for: request)

                guard let httpResponse = response as? HTTPURLResponse else { continue }

                // Retry on rate limit (429) or server errors (500+)
                if httpResponse.statusCode == 429 || httpResponse.statusCode >= 500 {
                    continue
                }

                guard httpResponse.statusCode == 200 else { return nil }

                if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                   let content = json["content"] as? [[String: Any]],
                   let textContent = content.first?["text"] as? String {
                    let clean = textContent.replacingOccurrences(of: "```json", with: "")
                        .replacingOccurrences(of: "```", with: "")
                        .trimmingCharacters(in: .whitespacesAndNewlines)
                    if let foodData = clean.data(using: .utf8) {
                        return try? JSONDecoder().decode(GeminiFood.self, from: foodData)
                    }
                }
            } catch {
                continue
            }
        }
        return nil
    }

    // MARK: - Health Agent

    /// Get current time-of-day label
    private var currentTimeOfDay: String {
        let hour = Calendar.current.component(.hour, from: Date())
        switch hour {
        case 5..<12: return "morning"
        case 12..<17: return "afternoon"
        case 17..<21: return "evening"
        default: return "night"
        }
    }

    /// Fetch a fresh AI health insight based on today's data + trends
    func refreshAgentInsight() async {
        guard !apiKey.isEmpty else {
            agentInsight = "Set your Anthropic API key in Diet tab to enable your AI health coach."
            return
        }

        isAgentThinking = true

        let trendSummary = buildTrendSummary()

        let insight = await healthAgent.generateTrendAwareInsight(
            calories: totalCalories,
            protein: totalProtein,
            carbs: totalCarbs,
            fat: totalFat,
            waterLiters: waterLiters,
            exerciseMinutes: todayExerciseMinutes,
            exerciseCalories: todayExerciseCalories,
            currentWeight: currentWeight,
            sleepHours: healthKitData.sleepHours,
            steps: healthKitData.steps,
            supplementsDone: doneCount,
            supplementsTotal: supplements.count,
            heartRate: healthKitData.heartRate,
            activeCalories: healthKitData.activeCalories,
            timeOfDay: currentTimeOfDay,
            trendSummary: trendSummary,
            apiKey: apiKey
        )

        isAgentThinking = false

        if let insight = insight {
            agentInsight = insight
            agentLastUpdated = Date()
        }

        // Check proactive warnings
        checkProactiveWarnings()

        // Update streaks
        updateStreaks()

        // Archive sleep from HealthKit
        archiveSleepFromHealthKit()

        // Check if weekly digest needed (Monday)
        let weekday = Calendar.current.component(.weekday, from: Date())
        if weekday == 2 { // Monday
            let thisWeek = dateString(for: Calendar.current.date(byAdding: .day, value: -1, to: Date())!)
            if !weeklyDigests.contains(where: { $0.weekStartDate == thisWeek }) {
                await refreshWeeklyDigest()
            }
        }
    }

    /// Ask the AI agent a health question with conversation memory
    func askAgent(_ question: String) async -> String? {
        guard !apiKey.isEmpty else { return nil }

        // Add user message to history
        conversationHistory.append(ConversationMessage(role: "user", content: question))

        let todayData = """
        Today: \(totalCalories)/1750 cal, \(totalProtein)/120g protein, \(String(format: "%.1f", waterLiters))/3.5L water, \(todayExerciseMinutes) min exercise, weight \(String(format: "%.1f", currentWeight))kg
        """

        let response = await healthAgent.askQuestionWithContext(
            question,
            conversationHistory: Array(conversationHistory.suffix(20)),
            currentDayData: todayData,
            apiKey: apiKey
        )

        if let response = response {
            conversationHistory.append(ConversationMessage(role: "assistant", content: response))
            saveConversation()
            return response
        }

        // Remove the user message if we got no response
        conversationHistory.removeLast()
        return nil
    }

    func clearConversation() {
        conversationHistory.removeAll()
        saveConversation()
    }

    // MARK: - Weekly Digest
    func refreshWeeklyDigest() async {
        guard !apiKey.isEmpty else { return }
        isGeneratingDigest = true

        let trendSummary = buildTrendSummary()
        let digest = await healthAgent.generateWeeklyDigest(trendSummary: trendSummary, apiKey: apiKey)

        if let digest = digest {
            weeklyDigests.append(digest)
            saveDigests()
        }

        isGeneratingDigest = false
    }

    // MARK: - Goal Adjustment
    func checkGoalAdjustments() async {
        guard !apiKey.isEmpty else { return }

        let suggestion = await healthAgent.suggestGoalAdjustments(
            weightTrend: weeklyWeightVelocity,
            avgCalories: avgCaloriesLast7(),
            avgProtein: avgProteinLast7(),
            exerciseMinutes: weekExerciseMinutes,
            apiKey: apiKey
        )

        agentGoalSuggestion = suggestion
    }

    // MARK: - Meal Suggestions
    func suggestMeal() async {
        guard !apiKey.isEmpty else { return }
        isSuggestingMeal = true

        let remaining = Profile.dailyCalories - totalCalories
        let remainingProtein = max(Profile.proteinTarget - totalProtein, 0)
        let remainingCarbs = max(Profile.carbTarget - totalCarbs, 0)
        let remainingFat = max(Profile.fatTarget - totalFat, 0)

        mealSuggestion = await healthAgent.suggestMeals(
            remainingCalories: remaining,
            remainingProtein: remainingProtein,
            remainingCarbs: remainingCarbs,
            remainingFat: remainingFat,
            timeOfDay: currentTimeOfDay,
            apiKey: apiKey
        )

        isSuggestingMeal = false
    }

    // MARK: - Daily Challenge
    func generateDailyChallenge() async {
        guard !apiKey.isEmpty else { return }
        // Don't regenerate if already have one for today
        if let existing = todayChallenge, existing.startDate == todayString() { return }

        isGeneratingChallenge = true

        let challengeText = await healthAgent.generateChallenge(
            avgCalories: avgCaloriesLast7(),
            avgProtein: avgProteinLast7(),
            exerciseMinutes: weekExerciseMinutes,
            waterAvg: waterForDate(todayString()),
            apiKey: apiKey
        )

        if let text = challengeText {
            // Parse the challenge text into a Challenge object
            let challenge = Challenge(
                title: text,
                description: "",
                type: .logging,
                targetValue: 1,
                startDate: todayString(),
                endDate: todayString()
            )
            todayChallenge = challenge
            challenges.append(challenge)
            saveChallenges()
        }

        isGeneratingChallenge = false
    }

    // MARK: - Notifications (Fixed + AI Smart Notifications)

    func scheduleAllNotifications() {
        let center = UNUserNotificationCenter.current()
        center.removeAllPendingNotificationRequests()

        // --- Fixed daily reminders ---
        let items: [(String, Int, Int, String)] = [
            ("Time for black coffee!", 9, 0, "coffee"),
            ("Gym time! Let's burn some fat.", 9, 30, "gym"),
            ("Post-workout protein shake time!", 10, 30, "protein"),
            ("Take your Nurokind-OD B12 with breakfast", 11, 0, "b12"),
            ("Fish Oil with lunch", 14, 0, "fish1"),
            ("Fish Oil with dinner", 20, 30, "fish2"),
            ("Don't forget to log your water intake!", 15, 0, "water"),
        ]

        for (msg, hour, minute, id) in items {
            let content = UNMutableNotificationContent()
            content.title = "Health Tracker"
            content.body = msg
            content.sound = .default

            var dateComponents = DateComponents()
            dateComponents.hour = hour
            dateComponents.minute = minute

            let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: true)
            let request = UNNotificationRequest(identifier: id, content: content, trigger: trigger)
            center.add(request) { _ in }
        }

        // Sunday D3 reminder
        let d3Content = UNMutableNotificationContent()
        d3Content.title = "Vitamin D3 Day!"
        d3Content.body = "Take your Uprise-D3 60K capsule with lunch today"
        d3Content.sound = .default

        var sundayComponents = DateComponents()
        sundayComponents.weekday = 1
        sundayComponents.hour = 13
        sundayComponents.minute = 0

        let d3Trigger = UNCalendarNotificationTrigger(dateMatching: sundayComponents, repeats: true)
        center.add(UNNotificationRequest(identifier: "d3_sunday", content: d3Content, trigger: d3Trigger)) { _ in }

        // --- AI Smart Notifications (4x per day) ---
        // These use fallback messages; the app will try to replace them with AI-generated
        // messages when it gets a chance to run in the foreground
        scheduleAINotifications()
    }

    /// Schedule AI-powered smart notifications at 4 time slots
    func scheduleAINotifications() {
        let center = UNUserNotificationCenter.current()

        let fallbacks: [NotificationTimeSlot: String] = [
            .morningBriefing: "Good morning Harsh! Time to crush it at the gym. Remember: every rep gets you closer to 73 kg.",
            .postLunchCheck: "Afternoon check: How's your protein looking? You need 120g today — don't skip it.",
            .eveningSummary: "Evening wrap: Plan a protein-rich dinner. Keep it under your calorie budget and you'll sleep like a champ.",
            .bedtimeWrapup: "Day's done! Rest up — your muscles need 7.5 hours of sleep to recover and grow."
        ]

        for slot in NotificationTimeSlot.allCases {
            let content = UNMutableNotificationContent()
            content.title = slot.title
            content.body = fallbacks[slot] ?? "Time for a health check-in!"
            content.sound = .default

            var dateComponents = DateComponents()
            dateComponents.hour = slot.hour
            dateComponents.minute = slot.minute

            let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: true)
            let request = UNNotificationRequest(identifier: slot.rawValue, content: content, trigger: trigger)
            center.add(request) { _ in }
        }
    }

    /// Try to update AI notifications with personalized content (call when app is active)
    func updateAINotificationsWithContext() async {
        guard !apiKey.isEmpty else { return }

        let center = UNUserNotificationCenter.current()

        for slot in NotificationTimeSlot.allCases {
            // Only update future notifications
            let now = Calendar.current.component(.hour, from: Date()) * 60 + Calendar.current.component(.minute, from: Date())
            let slotTime = slot.hour * 60 + slot.minute
            guard slotTime > now else { continue }

            if let message = await healthAgent.generateNotificationMessage(
                timeSlot: slot,
                calories: totalCalories,
                protein: totalProtein,
                waterLiters: waterLiters,
                exerciseMinutes: todayExerciseMinutes,
                supplementsDone: doneCount,
                supplementsTotal: supplements.count,
                currentWeight: currentWeight,
                sleepHours: healthKitData.sleepHours,
                apiKey: apiKey
            ) {
                let content = UNMutableNotificationContent()
                content.title = slot.title
                content.body = message
                content.sound = .default

                var dateComponents = DateComponents()
                dateComponents.hour = slot.hour
                dateComponents.minute = slot.minute

                let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
                let request = UNNotificationRequest(identifier: "\(slot.rawValue)_smart", content: content, trigger: trigger)

                // Remove old fallback for this slot and add smart one
                center.removePendingNotificationRequests(withIdentifiers: [slot.rawValue])
                center.add(request) { _ in }
            }
        }
    }
}
