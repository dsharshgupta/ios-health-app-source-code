import SwiftUI

struct MoodCheckInView: View {
    @EnvironmentObject var store: DataStore
    @Environment(\.dismiss) private var dismiss
    @State private var selectedMood: Int = 3
    @State private var selectedEnergy: Int = 3
    @State private var notes: String = ""

    private let moods = [
        (1, "😞", "Awful"),
        (2, "😐", "Meh"),
        (3, "🙂", "Okay"),
        (4, "😊", "Good"),
        (5, "🤩", "Great")
    ]

    private let energyLevels = [
        (1, "🪫", "Drained"),
        (2, "😴", "Low"),
        (3, "⚡", "Normal"),
        (4, "🔋", "High"),
        (5, "⚡⚡", "Pumped")
    ]

    var body: some View {
        NavigationStack {
            ZStack {
                AppColors.background.ignoresSafeArea()

                ScrollView {
                    VStack(spacing: 28) {
                        // MARK: - Mood Selection
                        VStack(spacing: 14) {
                            Text("HOW ARE YOU FEELING?")
                                .font(.system(size: 11, weight: .bold, design: .rounded))
                                .tracking(2)
                                .foregroundColor(.gray)

                            HStack(spacing: 12) {
                                ForEach(moods, id: \.0) { level, emoji, label in
                                    Button {
                                        withAnimation(.spring(response: 0.3)) {
                                            selectedMood = level
                                        }
                                    } label: {
                                        VStack(spacing: 6) {
                                            Text(emoji)
                                                .font(.system(size: selectedMood == level ? 40 : 30))
                                                .scaleEffect(selectedMood == level ? 1.1 : 1)

                                            Text(label)
                                                .font(.system(size: 10, weight: .semibold))
                                                .foregroundColor(selectedMood == level ? .white : .gray)
                                        }
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 12)
                                        .background(
                                            RoundedRectangle(cornerRadius: 14)
                                                .fill(selectedMood == level ? moodColor(level).opacity(0.2) : Color.clear)
                                                .overlay(
                                                    RoundedRectangle(cornerRadius: 14)
                                                        .stroke(selectedMood == level ? moodColor(level) : Color.clear, lineWidth: 1)
                                                )
                                        )
                                    }
                                }
                            }
                        }
                        .padding()
                        .glassCard()

                        // MARK: - Energy Selection
                        VStack(spacing: 14) {
                            Text("ENERGY LEVEL")
                                .font(.system(size: 11, weight: .bold, design: .rounded))
                                .tracking(2)
                                .foregroundColor(.gray)

                            HStack(spacing: 12) {
                                ForEach(energyLevels, id: \.0) { level, emoji, label in
                                    Button {
                                        withAnimation(.spring(response: 0.3)) {
                                            selectedEnergy = level
                                        }
                                    } label: {
                                        VStack(spacing: 6) {
                                            Text(emoji)
                                                .font(.system(size: selectedEnergy == level ? 40 : 30))
                                                .scaleEffect(selectedEnergy == level ? 1.1 : 1)

                                            Text(label)
                                                .font(.system(size: 10, weight: .semibold))
                                                .foregroundColor(selectedEnergy == level ? .white : .gray)
                                        }
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 12)
                                        .background(
                                            RoundedRectangle(cornerRadius: 14)
                                                .fill(selectedEnergy == level ? AppColors.orange.opacity(0.2) : Color.clear)
                                                .overlay(
                                                    RoundedRectangle(cornerRadius: 14)
                                                        .stroke(selectedEnergy == level ? AppColors.orange : Color.clear, lineWidth: 1)
                                                )
                                        )
                                    }
                                }
                            }
                        }
                        .padding()
                        .glassCard()

                        // MARK: - Notes
                        VStack(alignment: .leading, spacing: 10) {
                            Text("NOTES (OPTIONAL)")
                                .font(.system(size: 11, weight: .bold, design: .rounded))
                                .tracking(2)
                                .foregroundColor(.gray)

                            TextField("How's your day going?", text: $notes)
                                .font(.system(size: 15))
                                .padding(12)
                                .background(Color.white.opacity(0.06))
                                .clipShape(RoundedRectangle(cornerRadius: 12))
                                .foregroundColor(.white)
                        }
                        .padding()
                        .glassCard()

                        // MARK: - Save Button
                        Button {
                            store.logMood(mood: selectedMood, energy: selectedEnergy, notes: notes)
                            dismiss()
                        } label: {
                            HStack {
                                Image(systemName: "checkmark.circle.fill")
                                Text("Log Check-In")
                                    .fontWeight(.bold)
                            }
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(
                                LinearGradient(colors: [AppColors.accent, AppColors.green], startPoint: .leading, endPoint: .trailing)
                            )
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                        }
                    }
                    .padding()
                }
            }
            .navigationTitle("Check-In")
            .navigationBarTitleDisplayMode(.inline)
            .preferredColorScheme(.dark)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
            }
        }
    }

    private func moodColor(_ level: Int) -> Color {
        switch level {
        case 1: return AppColors.red
        case 2: return AppColors.orange
        case 3: return AppColors.blue
        case 4: return AppColors.green
        case 5: return AppColors.accent
        default: return AppColors.blue
        }
    }
}
