import SwiftUI

struct ExerciseView: View {
    @EnvironmentObject var store: DataStore
    @State private var showAddSheet = false

    var body: some View {
        NavigationStack {
            ZStack {
                AnimatedMeshBackground()

                ScrollView {
                    VStack(spacing: 20) {
                        // Week Overview
                        weekOverviewCard
                            .padding(.top, 8)

                        // Today's Stats
                        todayStatsCard

                        // Apple Watch Sync
                        watchSyncCard

                        // Quick Add Button
                        Button(action: { showAddSheet = true }) {
                            HStack(spacing: 10) {
                                Image(systemName: "plus.circle.fill")
                                    .font(.title3)
                                Text("Log Workout")
                                    .font(.headline)
                            }
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity)
                            .frame(height: 52)
                            .background(
                                LinearGradient(
                                    colors: [AppColors.accent, AppColors.green],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                        }

                        // Today's Workouts
                        if !store.todayExercise.isEmpty {
                            todayWorkoutsSection
                        }

                        // Week Activity Grid
                        weekActivityGrid

                        // Streak Card
                        if store.exerciseStreak > 0 {
                            streakCard
                        }
                    }
                    .padding()
                }
            }
            .navigationTitle("Exercise")
            .navigationBarTitleDisplayMode(.large)
            .sheet(isPresented: $showAddSheet) {
                AddExerciseSheet()
                    .environmentObject(store)
            }
        }
    }

    // MARK: - Week Overview Card
    private var weekOverviewCard: some View {
        VStack(spacing: 16) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("THIS WEEK")
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundColor(AppColors.subtleText)
                        .tracking(1)
                    Text("\(store.weekExerciseMinutes) min")
                        .font(.system(size: 32, weight: .bold, design: .rounded))
                }
                Spacer()
                ZStack {
                    Circle()
                        .stroke(Color.white.opacity(0.06), lineWidth: 8)
                        .frame(width: 72, height: 72)
                    Circle()
                        .trim(from: 0, to: min(Double(store.weekExerciseMinutes) / Double(Profile.exerciseWeeklyTarget), 1))
                        .stroke(
                            AngularGradient(
                                colors: [AppColors.green, AppColors.accent],
                                center: .center
                            ),
                            style: StrokeStyle(lineWidth: 8, lineCap: .round)
                        )
                        .frame(width: 72, height: 72)
                        .rotationEffect(.degrees(-90))
                        .animation(.spring(response: 0.8), value: store.weekExerciseMinutes)

                    Text("\(Int(min(Double(store.weekExerciseMinutes) / Double(Profile.exerciseWeeklyTarget) * 100, 100)))%")
                        .font(.system(size: 13, weight: .bold, design: .rounded))
                        .foregroundColor(AppColors.accent)
                }
            }

            // Progress bar
            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Text("Goal: \(Profile.exerciseWeeklyTarget) min/week")
                        .font(.caption)
                        .foregroundColor(AppColors.subtleText)
                    Spacer()
                    Text("\(max(0, Profile.exerciseWeeklyTarget - store.weekExerciseMinutes)) min left")
                        .font(.caption)
                        .foregroundColor(store.weekExerciseMinutes >= Profile.exerciseWeeklyTarget ? AppColors.green : AppColors.orange)
                }

                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        RoundedRectangle(cornerRadius: 4)
                            .fill(Color.white.opacity(0.06))
                            .frame(height: 6)
                        RoundedRectangle(cornerRadius: 4)
                            .fill(
                                LinearGradient(
                                    colors: [AppColors.accent, AppColors.green],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .frame(
                                width: geo.size.width * min(Double(store.weekExerciseMinutes) / Double(Profile.exerciseWeeklyTarget), 1),
                                height: 6
                            )
                            .animation(.spring(response: 0.8), value: store.weekExerciseMinutes)
                    }
                }
                .frame(height: 6)
            }
        }
        .padding(20)
        .glassCard()
    }

    // MARK: - Today Stats
    private var todayStatsCard: some View {
        HStack(spacing: 0) {
            todayStat(
                icon: "clock.fill",
                value: "\(store.todayExerciseMinutes)",
                label: "MINUTES",
                color: AppColors.accent
            )

            Rectangle()
                .fill(Color.white.opacity(0.06))
                .frame(width: 1, height: 40)

            todayStat(
                icon: "flame.fill",
                value: "\(store.todayExerciseCalories)",
                label: "BURNED",
                color: AppColors.orange
            )

            Rectangle()
                .fill(Color.white.opacity(0.06))
                .frame(width: 1, height: 40)

            todayStat(
                icon: "figure.run",
                value: "\(store.todayExercise.count)",
                label: "WORKOUTS",
                color: AppColors.green
            )
        }
        .padding(16)
        .glassCard()
    }

    private func todayStat(icon: String, value: String, label: String, color: Color) -> some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.caption)
                .foregroundColor(color)
            Text(value)
                .font(.system(size: 20, weight: .bold, design: .rounded))
            Text(label)
                .font(.system(size: 8, weight: .semibold))
                .foregroundColor(AppColors.subtleText)
                .tracking(0.5)
        }
        .frame(maxWidth: .infinity)
    }

    // MARK: - Today Workouts
    private var todayWorkoutsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("TODAY'S WORKOUTS")
                .font(.system(size: 11, weight: .semibold))
                .foregroundColor(AppColors.subtleText)
                .tracking(1)

            ForEach(store.todayExercise) { log in
                HStack(spacing: 14) {
                    // Type icon
                    Image(systemName: log.type.icon)
                        .font(.title3)
                        .foregroundColor(log.type.color)
                        .frame(width: 44, height: 44)
                        .background(log.type.color.opacity(0.12))
                        .clipShape(RoundedRectangle(cornerRadius: 12))

                    VStack(alignment: .leading, spacing: 3) {
                        Text(log.type.rawValue)
                            .font(.subheadline.weight(.semibold))
                        HStack(spacing: 12) {
                            Label("\(log.durationMinutes) min", systemImage: "clock")
                                .font(.caption2)
                                .foregroundColor(AppColors.subtleText)
                            Label("\(log.caloriesBurned) kcal", systemImage: "flame.fill")
                                .font(.caption2)
                                .foregroundColor(AppColors.orange)
                        }
                    }

                    Spacer()

                    Text(log.inputMethod.rawValue)
                        .font(.system(size: 8, weight: .semibold))
                        .foregroundColor(AppColors.subtleText)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 3)
                        .background(Color.white.opacity(0.06))
                        .clipShape(Capsule())

                    Button(action: { store.removeExercise(log.id) }) {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.white.opacity(0.2))
                    }
                }
                .padding(14)
                .glassCard(cornerRadius: 14)
            }
        }
    }

    // MARK: - Week Activity Grid
    private var weekActivityGrid: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("THIS WEEK")
                .font(.system(size: 11, weight: .semibold))
                .foregroundColor(AppColors.subtleText)
                .tracking(1)

            HStack(spacing: 6) {
                ForEach(last7Days(), id: \.self) { day in
                    let minutes = store.exerciseMinutesForDate(day)
                    let isToday = day == todayString()
                    let intensity: Double = minutes > 0 ? min(Double(minutes) / 60.0, 1.0) : 0

                    VStack(spacing: 6) {
                        Text(weekdayShort(for: day))
                            .font(.system(size: 10, weight: .medium))
                            .foregroundColor(isToday ? .white : AppColors.subtleText)

                        RoundedRectangle(cornerRadius: 8)
                            .fill(minutes > 0
                                  ? AppColors.green.opacity(0.2 + intensity * 0.6)
                                  : Color.white.opacity(0.04))
                            .frame(height: 44)
                            .overlay(
                                VStack(spacing: 2) {
                                    if minutes > 0 {
                                        Text("\(minutes)")
                                            .font(.system(size: 12, weight: .bold, design: .rounded))
                                        Text("min")
                                            .font(.system(size: 7))
                                            .foregroundColor(AppColors.subtleText)
                                    }
                                }
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(isToday ? AppColors.accent.opacity(0.5) : Color.clear, lineWidth: 1)
                            )
                    }
                    .frame(maxWidth: .infinity)
                }
            }
        }
        .padding(16)
        .glassCard()
    }

    // MARK: - Streak Card
    private var streakCard: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(AppColors.orange.opacity(0.15))
                    .frame(width: 50, height: 50)
                Image(systemName: "flame.fill")
                    .font(.title2)
                    .foregroundColor(AppColors.orange)
            }

            VStack(alignment: .leading, spacing: 3) {
                Text("\(store.exerciseStreak) Day Streak!")
                    .font(.headline)
                Text("Keep it going — consistency beats intensity")
                    .font(.caption)
                    .foregroundColor(AppColors.subtleText)
            }

            Spacer()
        }
        .padding(16)
        .glassCard()
    }

    // MARK: - Apple Watch Sync
    private var watchSyncCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                HStack(spacing: 8) {
                    Image(systemName: "applewatch")
                        .foregroundColor(AppColors.blue)
                    Text("Apple Watch")
                        .font(.headline)
                }
                Spacer()
                Button(action: {
                    Task {
                        await store.syncAppleWatchData()
                    }
                }) {
                    HStack(spacing: 6) {
                        if store.isSyncingHealthData {
                            ProgressView()
                                .tint(.black)
                        } else {
                            Image(systemName: "arrow.triangle.2.circlepath")
                        }
                        Text(store.healthKitData.isAuthorized ? "Sync" : "Connect")
                            .font(.caption.weight(.bold))
                    }
                    .foregroundColor(.black)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(AppColors.blue)
                    .clipShape(Capsule())
                }
                .disabled(store.isSyncingHealthData)
            }

            if store.healthKitData.isAuthorized {
                // Row 1: Active Calories, Steps, Distance
                HStack(spacing: 10) {
                    watchMetric(
                        title: "ACTIVE",
                        value: "\(Int(store.healthKitData.activeCalories.rounded())) kcal",
                        color: AppColors.orange
                    )
                    watchMetric(
                        title: "STEPS",
                        value: formatSteps(store.healthKitData.steps),
                        color: AppColors.green
                    )
                    watchMetric(
                        title: "DISTANCE",
                        value: store.healthKitData.distanceKm > 0 ? "\(String(format: "%.1f", store.healthKitData.distanceKm)) km" : "--",
                        color: AppColors.accent
                    )
                }

                // Row 2: Heart Rate, HRV, Sleep, Flights
                HStack(spacing: 10) {
                    watchMetric(
                        title: "HEART",
                        value: store.healthKitData.heartRate > 0 ? "\(Int(store.healthKitData.heartRate)) bpm" : "--",
                        color: AppColors.red
                    )
                    watchMetric(
                        title: "HRV",
                        value: store.healthKitData.hrv > 0 ? "\(Int(store.healthKitData.hrv)) ms" : "--",
                        color: AppColors.purple
                    )
                    watchMetric(
                        title: "SLEEP",
                        value: store.healthKitData.sleepHours > 0 ? "\(String(format: "%.1f", store.healthKitData.sleepHours))h" : "--",
                        color: AppColors.blue
                    )
                    watchMetric(
                        title: "FLIGHTS",
                        value: store.healthKitData.flightsClimbed > 0 ? "\(store.healthKitData.flightsClimbed)" : "--",
                        color: AppColors.orange
                    )
                }
            } else {
                Text("Connect Health access once — the app will auto-sync Apple Watch data in the background.")
                    .font(.caption)
                    .foregroundColor(AppColors.subtleText)
            }

            if !store.healthSyncMessage.isEmpty {
                Text(store.healthSyncMessage)
                    .font(.caption2)
                    .foregroundColor(Color.white.opacity(0.45))
            }

            if let lastSync = store.healthKitData.lastSyncDate, store.healthKitData.isAuthorized {
                Text("Last synced: \(lastSync, style: .relative) ago")
                    .font(.system(size: 9))
                    .foregroundColor(Color.white.opacity(0.3))
            }
        }
        .padding(16)
        .glassCard()
    }

    private func formatSteps(_ steps: Int) -> String {
        if steps >= 1000 {
            let k = Double(steps) / 1000.0
            return "\(String(format: "%.1f", k))k"
        }
        return "\(steps)"
    }

    private func watchMetric(title: String, value: String, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.system(size: 8, weight: .semibold))
                .foregroundColor(AppColors.subtleText)
                .tracking(0.6)
            Text(value)
                .font(.system(size: 13, weight: .bold, design: .rounded))
                .foregroundColor(color)
                .lineLimit(1)
                .minimumScaleFactor(0.7)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(Color.white.opacity(0.05))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

// MARK: - Add Exercise Sheet
struct AddExerciseSheet: View {
    @EnvironmentObject var store: DataStore
    @Environment(\.dismiss) var dismiss

    @State private var selectedType: ExerciseType = .strength
    @State private var duration = ""
    @State private var calories = ""
    @State private var inputMethod: ExerciseInputMethod = .manual
    @FocusState private var focusedField: Field?

    private enum Field: Hashable {
        case duration
        case calories
    }

    private var estimatedCalories: Int {
        guard let dur = Int(duration), dur > 0 else { return 0 }
        return Int(Double(dur) * selectedType.caloriesPerMinute)
    }

    var body: some View {
        NavigationStack {
            ZStack {
                AppColors.background.ignoresSafeArea()

                DismissKeyboardScrollView {
                    VStack(spacing: 20) {
                        // Exercise Type Picker
                        VStack(alignment: .leading, spacing: 12) {
                            Text("WORKOUT TYPE")
                                .font(.system(size: 11, weight: .semibold))
                                .foregroundColor(AppColors.subtleText)
                                .tracking(1)

                            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 10), count: 3), spacing: 10) {
                                ForEach(ExerciseType.allCases, id: \.self) { type in
                                    Button(action: { selectedType = type }) {
                                        VStack(spacing: 6) {
                                            Image(systemName: type.icon)
                                                .font(.title3)
                                                .foregroundColor(selectedType == type ? .black : type.color)
                                            Text(type.rawValue)
                                                .font(.system(size: 10, weight: .medium))
                                                .foregroundColor(selectedType == type ? .black : .white.opacity(0.8))
                                                .lineLimit(1)
                                        }
                                        .frame(maxWidth: .infinity)
                                        .frame(height: 68)
                                        .background(
                                            selectedType == type
                                            ? AnyShapeStyle(
                                                LinearGradient(colors: [type.color, type.color.opacity(0.7)], startPoint: .top, endPoint: .bottom)
                                              )
                                            : AnyShapeStyle(Color.white.opacity(0.05))
                                        )
                                        .clipShape(RoundedRectangle(cornerRadius: 14))
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 14)
                                                .stroke(selectedType == type ? type.color.opacity(0.5) : Color.white.opacity(0.08), lineWidth: 1)
                                        )
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                        }
                        .padding(16)
                        .glassCard()

                        // Input Method Toggle
                        VStack(alignment: .leading, spacing: 12) {
                            Text("INPUT METHOD")
                                .font(.system(size: 11, weight: .semibold))
                                .foregroundColor(AppColors.subtleText)
                                .tracking(1)

                            HStack(spacing: 8) {
                                methodButton("Manual Entry", icon: "number", method: .manual)
                                methodButton("Estimate", icon: "wand.and.stars", method: .estimated)
                            }
                        }
                        .padding(16)
                        .glassCard()

                        // Duration & Calories
                        VStack(alignment: .leading, spacing: 12) {
                            Text("DETAILS")
                                .font(.system(size: 11, weight: .semibold))
                                .foregroundColor(AppColors.subtleText)
                                .tracking(1)

                            HStack(spacing: 10) {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text("Duration (min)")
                                        .font(.caption)
                                        .foregroundColor(AppColors.subtleText)
                                    TextField("45", text: $duration)
                                        .keyboardType(.numberPad)
                                        .font(.title3.weight(.semibold))
                                        .focused($focusedField, equals: .duration)
                                        .padding(14)
                                        .background(Color.white.opacity(0.06))
                                        .clipShape(RoundedRectangle(cornerRadius: 12))
                                }

                                if inputMethod == .manual {
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text("Calories Burned")
                                            .font(.caption)
                                            .foregroundColor(AppColors.subtleText)
                                        TextField("350", text: $calories)
                                            .keyboardType(.numberPad)
                                            .font(.title3.weight(.semibold))
                                            .focused($focusedField, equals: .calories)
                                            .padding(14)
                                            .background(Color.white.opacity(0.06))
                                            .clipShape(RoundedRectangle(cornerRadius: 12))
                                    }
                                } else {
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text("Est. Calories")
                                            .font(.caption)
                                            .foregroundColor(AppColors.subtleText)
                                        HStack {
                                            Text("\(estimatedCalories)")
                                                .font(.title3.weight(.semibold))
                                                .foregroundColor(AppColors.orange)
                                            Text("kcal")
                                                .font(.caption)
                                                .foregroundColor(AppColors.subtleText)
                                        }
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                        .padding(14)
                                        .background(AppColors.orange.opacity(0.08))
                                        .clipShape(RoundedRectangle(cornerRadius: 12))
                                    }
                                }
                            }

                            if inputMethod == .estimated && !duration.isEmpty {
                                Text("Estimate based on \(selectedType.rawValue) at ~\(Int(selectedType.caloriesPerMinute)) kcal/min for an 88kg male")
                                    .font(.caption2)
                                    .foregroundColor(AppColors.subtleText)
                            }
                        }
                        .padding(16)
                        .glassCard()

                        // Save Button
                        Button(action: saveExercise) {
                            HStack {
                                Image(systemName: "checkmark.circle.fill")
                                Text("Log Workout")
                                    .fontWeight(.bold)
                            }
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity)
                            .frame(height: 52)
                            .background(
                                LinearGradient(
                                    colors: [AppColors.accent, AppColors.green],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                        }
                        .disabled(duration.isEmpty)
                        .opacity(duration.isEmpty ? 0.5 : 1)
                    }
                    .padding()
                }
            }
            .dismissKeyboardOnTap()
            .keyboardDoneToolbar()
            .navigationTitle("Log Workout")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                        .foregroundColor(AppColors.accent)
                }
            }
        }
        .presentationDetents([.large])
    }

    private func methodButton(_ title: String, icon: String, method: ExerciseInputMethod) -> some View {
        Button(action: { inputMethod = method }) {
            HStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.caption)
                Text(title)
                    .font(.subheadline.weight(.medium))
            }
            .foregroundColor(inputMethod == method ? .black : .white.opacity(0.7))
            .frame(maxWidth: .infinity)
            .frame(height: 44)
            .background(inputMethod == method ? AppColors.accent : Color.white.opacity(0.06))
            .clipShape(RoundedRectangle(cornerRadius: 12))
        }
        .buttonStyle(.plain)
    }

    private func saveExercise() {
        guard let dur = Int(duration), dur > 0 else { return }
        let cal: Int
        if inputMethod == .manual {
            cal = Int(calories) ?? estimatedCalories
        } else {
            cal = estimatedCalories
        }

        let log = ExerciseLog(
            date: todayString(),
            type: selectedType,
            durationMinutes: dur,
            caloriesBurned: cal,
            inputMethod: inputMethod
        )
        store.addExercise(log)
        focusedField = nil
        hideKeyboard()
        dismiss()
    }
}
