import SwiftUI
import UserNotifications

@main
struct HealthTrackerApp: App {
    @StateObject private var store = DataStore()
    @Environment(\.scenePhase) private var scenePhase

    init() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { _, _ in }

        // Tab bar appearance
        let tabAppearance = UITabBarAppearance()
        tabAppearance.configureWithTransparentBackground()
        tabAppearance.backgroundColor = UIColor(red: 0.03, green: 0.03, blue: 0.05, alpha: 0.95)

        let blur = UIBlurEffect(style: .dark)
        tabAppearance.backgroundEffect = blur

        UITabBar.appearance().standardAppearance = tabAppearance
        UITabBar.appearance().scrollEdgeAppearance = tabAppearance
        UITabBar.appearance().unselectedItemTintColor = UIColor.gray.withAlphaComponent(0.5)

        // Navigation bar appearance
        let navAppearance = UINavigationBarAppearance()
        navAppearance.configureWithTransparentBackground()
        navAppearance.largeTitleTextAttributes = [
            .foregroundColor: UIColor.white,
            .font: UIFont.systemFont(ofSize: 32, weight: .bold)
        ]
        navAppearance.titleTextAttributes = [
            .foregroundColor: UIColor.white
        ]
        UINavigationBar.appearance().standardAppearance = navAppearance
        UINavigationBar.appearance().scrollEdgeAppearance = navAppearance
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .preferredColorScheme(.dark)
                .onAppear {
                    store.scheduleAllNotifications()
                    Task {
                        await store.syncAppleWatchData()
                        // Generate initial AI insight
                        await store.refreshAgentInsight()
                        // Update today's AI notifications with real data
                        await store.updateAINotificationsWithContext()
                    }
                    // Start background observers + periodic auto-sync
                    store.startAutoSync()
                }
                .onChange(of: scenePhase) { _, newPhase in
                    switch newPhase {
                    case .active:
                        // Refresh Watch data and AI insight every time user opens the app
                        Task {
                            await store.refreshConnectedHealthData()
                            await store.refreshAgentInsight()
                            await store.updateAINotificationsWithContext()
                        }
                    case .background:
                        // Keep observers alive — they'll trigger sync from background
                        break
                    default:
                        break
                    }
                }
        }
    }
}
