import SwiftUI

struct DietView: View {
    @EnvironmentObject var store: DataStore
    @State private var foodInput = ""
    @State private var showApiKeySheet = false
    @State private var tempKey = ""
    @State private var showError = false
    @State private var showFavorites = false
    @State private var showMealSuggestion = false
    @FocusState private var isFoodFieldFocused: Bool
    @FocusState private var isApiKeyFieldFocused: Bool

    var body: some View {
        NavigationStack {
            ZStack {
                AnimatedMeshBackground()

                DismissKeyboardScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        // Macro Summary
                        macroSummaryCard

                        // Food Input
                        foodInputCard

                        // Meal Suggestion Button
                        mealSuggestionButton

                        // Quick Favorites
                        if !store.favorites.isEmpty {
                            favoritesSection
                        }

                        // Today's Meals
                        todayMealsSection
                    }
                    .padding()
                }
            }
            .dismissKeyboardOnTap()
            .keyboardDoneToolbar()
            .navigationTitle("Diet Tracker")
            .navigationBarTitleDisplayMode(.large)
            .sheet(isPresented: $showApiKeySheet) {
                apiKeySheet
            }
            .sheet(isPresented: $showFavorites) {
                FavoritesListView()
                    .environmentObject(store)
            }
            .sheet(isPresented: $showMealSuggestion) {
                mealSuggestionSheet
            }
            .alert("Analysis Failed", isPresented: $showError) {
                Button("OK") {}
            } message: {
                Text("Check your Anthropic API key or try again. Get a free key at console.anthropic.com")
            }
        }
    }

    // MARK: - Macro Summary
    private var macroSummaryCard: some View {
        HStack(spacing: 8) {
            macroBox(
                label: "Calories",
                value: store.totalCalories,
                max: Profile.dailyCalories,
                unit: "kcal",
                color: store.totalCalories > Profile.dailyCalories ? AppColors.red : AppColors.accent
            )
            macroBox(
                label: "Protein",
                value: store.totalProtein,
                max: Profile.proteinTarget,
                unit: "g",
                color: AppColors.green
            )
            macroBox(
                label: "Carbs",
                value: store.totalCarbs,
                max: Profile.carbTarget,
                unit: "g",
                color: AppColors.orange
            )
            macroBox(
                label: "Fat",
                value: store.totalFat,
                max: Profile.fatTarget,
                unit: "g",
                color: AppColors.red
            )
        }
        .padding(14)
        .glassCard()
    }

    private func macroBox(label: String, value: Int, max: Int, unit: String, color: Color) -> some View {
        VStack(spacing: 5) {
            Text(label.uppercased())
                .font(.system(size: 8, weight: .semibold))
                .foregroundColor(AppColors.subtleText)
                .tracking(0.5)
            Text("\(value)")
                .font(.system(size: 20, weight: .bold, design: .rounded))
                .foregroundColor(color)
            Text("/ \(max) \(unit)")
                .font(.system(size: 8))
                .foregroundColor(Color.white.opacity(0.25))

            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 2)
                        .fill(Color.white.opacity(0.05))
                        .frame(height: 3)
                    RoundedRectangle(cornerRadius: 2)
                        .fill(
                            LinearGradient(
                                colors: [color, color.opacity(0.5)],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .frame(width: geo.size.width * min(CGFloat(value) / CGFloat(max), 1), height: 3)
                        .animation(.spring(response: 0.5), value: value)
                }
            }
            .frame(height: 3)
            .padding(.top, 2)
        }
        .frame(maxWidth: .infinity)
    }

    // MARK: - Meal Suggestion
    private var mealSuggestionButton: some View {
        Button { showMealSuggestion = true; Task { await store.suggestMeal() } } label: {
            HStack(spacing: 10) {
                Image(systemName: "sparkles")
                    .font(.system(size: 14))
                    .foregroundColor(AppColors.purple)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Suggest a meal")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(.white)
                    let remaining = Profile.dailyCalories - store.totalCalories
                    let remPro = max(Profile.proteinTarget - store.totalProtein, 0)
                    Text("\(remaining) cal, \(remPro)g protein remaining")
                        .font(.system(size: 10))
                        .foregroundColor(.gray)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundColor(AppColors.purple.opacity(0.5))
            }
            .padding(14)
            .glassCard()
        }
        .buttonStyle(.plain)
    }

    private var mealSuggestionSheet: some View {
        NavigationStack {
            ZStack {
                AppColors.background.ignoresSafeArea()
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        if store.isSuggestingMeal {
                            HStack(spacing: 10) {
                                ProgressView().tint(AppColors.purple)
                                Text("Finding meals that fit your remaining macros...")
                                    .font(.system(size: 13))
                                    .foregroundColor(.gray)
                            }
                            .padding(20)
                        } else if let suggestion = store.mealSuggestion {
                            AgentResponseView(text: suggestion)
                                .padding(16)
                        } else {
                            Text("No suggestions available. Make sure your API key is set.")
                                .font(.system(size: 13))
                                .foregroundColor(.gray)
                                .padding(20)
                        }
                    }
                }
            }
            .navigationTitle("Meal Ideas")
            .navigationBarTitleDisplayMode(.inline)
            .preferredColorScheme(.dark)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Done") { showMealSuggestion = false }
                }
                ToolbarItem(placement: .primaryAction) {
                    Button {
                        Task { await store.suggestMeal() }
                    } label: {
                        Image(systemName: "arrow.clockwise")
                    }
                }
            }
        }
    }

    // MARK: - Food Input
    private var foodInputCard: some View {
        VStack(spacing: 10) {
            HStack(spacing: 8) {
                HStack(spacing: 8) {
                    Image(systemName: "sparkles")
                        .font(.caption)
                        .foregroundColor(AppColors.accent.opacity(0.5))
                    TextField("2 roti, paneer bhurji, dal fry...", text: $foodInput)
                        .textFieldStyle(.plain)
                        .submitLabel(.done)
                        .focused($isFoodFieldFocused)
                        .onSubmit { addFood() }
                }
                .padding(14)
                .background(Color.white.opacity(0.06))
                .clipShape(RoundedRectangle(cornerRadius: 14))

                Button(action: addFood) {
                    if store.isAnalyzing {
                        ProgressView()
                            .tint(.black)
                            .frame(width: 52, height: 48)
                    } else {
                        Image(systemName: "arrow.up.circle.fill")
                            .font(.title2)
                            .frame(width: 52, height: 48)
                    }
                }
                .background(
                    LinearGradient(
                        colors: [AppColors.accent, AppColors.green],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .foregroundColor(.black)
                .clipShape(RoundedRectangle(cornerRadius: 14))
                .disabled(store.isAnalyzing)
            }

            HStack {
                Text("AI-powered Indian food analysis")
                    .font(.system(size: 10))
                    .foregroundColor(Color.white.opacity(0.2))
                Spacer()
                Button(action: { tempKey = store.apiKey; showApiKeySheet = true }) {
                    HStack(spacing: 4) {
                        Image(systemName: store.apiKey.isEmpty ? "key" : "checkmark.circle.fill")
                            .font(.system(size: 9))
                        Text(store.apiKey.isEmpty ? "Set API Key" : "Key set")
                            .font(.system(size: 10, weight: .medium))
                    }
                    .foregroundColor(store.apiKey.isEmpty ? AppColors.orange : AppColors.green)
                }
            }
        }
        .padding(14)
        .glassCard()
    }

    // MARK: - Favorites Section
    private var favoritesSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("FAVORITES")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundColor(AppColors.subtleText)
                    .tracking(1)
                Spacer()
                Button(action: { showFavorites = true }) {
                    Text("See All")
                        .font(.caption2.weight(.medium))
                        .foregroundColor(AppColors.accent)
                }
            }

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(store.favorites.sorted(by: { $0.useCount > $1.useCount }).prefix(6)) { fav in
                        Button(action: { store.addMealFromFavorite(fav) }) {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(fav.name)
                                    .font(.caption.weight(.medium))
                                    .foregroundColor(.white)
                                    .lineLimit(1)
                                HStack(spacing: 6) {
                                    Text("\(fav.calories) kcal")
                                        .font(.system(size: 9))
                                        .foregroundColor(AppColors.accent)
                                    Text("P:\(fav.protein)g")
                                        .font(.system(size: 9))
                                        .foregroundColor(AppColors.green)
                                }
                            }
                            .padding(.horizontal, 12)
                            .padding(.vertical, 10)
                            .glassCard(cornerRadius: 12)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }

    // MARK: - Today's Meals
    private var todayMealsSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("TODAY'S MEALS")
                .font(.system(size: 11, weight: .semibold))
                .foregroundColor(AppColors.subtleText)
                .tracking(1)

            if store.todayMeals.isEmpty {
                VStack(spacing: 10) {
                    Image(systemName: "fork.knife")
                        .font(.system(size: 32))
                        .foregroundColor(Color.white.opacity(0.1))
                    Text("No meals logged yet")
                        .font(.caption)
                        .foregroundColor(Color.white.opacity(0.2))
                }
                .frame(maxWidth: .infinity)
                .padding(30)
                .glassCard()
            } else {
                ForEach(store.todayMeals) { meal in
                    mealRow(meal)
                }
            }
        }
    }

    private func mealRow(_ meal: Meal) -> some View {
        HStack(spacing: 12) {
            // Calorie indicator
            ZStack {
                Circle()
                    .fill(AppColors.accent.opacity(0.12))
                    .frame(width: 40, height: 40)
                Text("\(meal.calories)")
                    .font(.system(size: 11, weight: .bold, design: .rounded))
                    .foregroundColor(AppColors.accent)
            }

            VStack(alignment: .leading, spacing: 3) {
                Text(meal.name)
                    .font(.subheadline.weight(.medium))
                if !meal.serving.isEmpty {
                    Text(meal.serving)
                        .font(.system(size: 10))
                        .foregroundColor(Color.white.opacity(0.25))
                }
                HStack(spacing: 10) {
                    macroTag("P", meal.protein, AppColors.green)
                    macroTag("C", meal.carbs, AppColors.orange)
                    macroTag("F", meal.fat, AppColors.red)
                }
                .padding(.top, 1)
            }

            Spacer()

            VStack(spacing: 6) {
                // Favorite button
                Button(action: { store.addToFavorites(meal) }) {
                    Image(systemName: store.favorites.contains(where: { $0.rawInput.lowercased() == meal.rawInput.lowercased() }) ? "heart.fill" : "heart")
                        .font(.system(size: 13))
                        .foregroundColor(store.favorites.contains(where: { $0.rawInput.lowercased() == meal.rawInput.lowercased() }) ? AppColors.red : Color.white.opacity(0.2))
                }

                Button(action: { store.removeMeal(meal.id) }) {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 13))
                        .foregroundColor(Color.white.opacity(0.15))
                }
            }
        }
        .padding(14)
        .glassCard(cornerRadius: 14)
    }

    private func macroTag(_ label: String, _ value: Int, _ color: Color) -> some View {
        HStack(spacing: 2) {
            Text(label)
                .font(.system(size: 8, weight: .bold))
                .foregroundColor(color.opacity(0.7))
            Text("\(value)g")
                .font(.system(size: 9, weight: .medium))
                .foregroundColor(color)
        }
    }

    // MARK: - Add Food
    func addFood() {
        guard !foodInput.trimmingCharacters(in: .whitespaces).isEmpty else { return }
        guard !store.apiKey.isEmpty else { showApiKeySheet = true; return }

        let text = foodInput
        foodInput = ""
        isFoodFieldFocused = false
        hideKeyboard()
        store.isAnalyzing = true

        Task {
            if let result = await store.analyzeFood(text) {
                let meal = Meal(
                    date: todayString(),
                    name: result.name,
                    calories: result.calories,
                    protein: result.protein,
                    carbs: result.carbs,
                    fat: result.fat,
                    fiber: result.fiber ?? 0,
                    serving: result.serving ?? "",
                    rawInput: text
                )
                await MainActor.run {
                    store.addMeal(meal)
                    store.isAnalyzing = false
                }
            } else {
                await MainActor.run {
                    store.isAnalyzing = false
                    showError = true
                    foodInput = text
                }
            }
        }
    }

    // MARK: - API Key Sheet
    var apiKeySheet: some View {
        NavigationStack {
            ZStack {
                AppColors.background.ignoresSafeArea()

                VStack(spacing: 20) {
                    Image(systemName: "key.fill")
                        .font(.system(size: 40))
                        .foregroundColor(AppColors.accent)
                        .padding(.top, 8)

                    Text("Enter your Anthropic API key to enable AI food analysis powered by Claude Haiku.")
                        .font(.subheadline)
                        .foregroundColor(AppColors.subtleText)
                        .multilineTextAlignment(.center)

                    TextField("Paste API key here", text: $tempKey)
                        .textFieldStyle(.plain)
                        .font(.system(.caption, design: .monospaced))
                        .focused($isApiKeyFieldFocused)
                        .padding(14)
                        .background(Color.white.opacity(0.06))
                        .clipShape(RoundedRectangle(cornerRadius: 14))

                    Button(action: {
                        store.apiKey = tempKey
                        store.saveApiKey()
                        isApiKeyFieldFocused = false
                        hideKeyboard()
                        showApiKeySheet = false
                    }) {
                        Text("Save Key")
                            .fontWeight(.bold)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(
                                LinearGradient(
                                    colors: [AppColors.accent, AppColors.green],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .foregroundColor(.black)
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                    }

                    Text("Get free key: console.anthropic.com > Create API Key")
                        .font(.caption2)
                        .foregroundColor(Color.white.opacity(0.2))

                    Spacer()
                }
                .padding()
            }
            .navigationTitle("Anthropic API Key")
            .navigationBarTitleDisplayMode(.inline)
            .dismissKeyboardOnTap()
            .keyboardDoneToolbar()
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { showApiKeySheet = false }
                        .foregroundColor(AppColors.accent)
                }
            }
        }
        .presentationDetents([.medium])
    }
}

// MARK: - Favorites List View
struct FavoritesListView: View {
    @EnvironmentObject var store: DataStore
    @Environment(\.dismiss) var dismiss

    var body: some View {
        NavigationStack {
            ZStack {
                AppColors.background.ignoresSafeArea()

                if store.favorites.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "heart.slash")
                            .font(.system(size: 40))
                            .foregroundColor(Color.white.opacity(0.1))
                        Text("No favorites yet")
                            .font(.subheadline)
                            .foregroundColor(AppColors.subtleText)
                        Text("Tap the heart icon on any meal to save it")
                            .font(.caption)
                            .foregroundColor(Color.white.opacity(0.2))
                    }
                } else {
                    ScrollView {
                        VStack(spacing: 8) {
                            ForEach(store.favorites.sorted(by: { $0.useCount > $1.useCount })) { fav in
                                HStack(spacing: 12) {
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(fav.name)
                                            .font(.subheadline.weight(.medium))
                                        HStack(spacing: 8) {
                                            Text("\(fav.calories) kcal")
                                                .font(.caption2)
                                                .foregroundColor(AppColors.accent)
                                            Text("P:\(fav.protein)g")
                                                .font(.caption2)
                                                .foregroundColor(AppColors.green)
                                            Text("C:\(fav.carbs)g")
                                                .font(.caption2)
                                                .foregroundColor(AppColors.orange)
                                            Text("F:\(fav.fat)g")
                                                .font(.caption2)
                                                .foregroundColor(AppColors.red)
                                        }
                                        Text("Used \(fav.useCount)x")
                                            .font(.system(size: 9))
                                            .foregroundColor(AppColors.subtleText)
                                    }

                                    Spacer()

                                    Button(action: {
                                        store.addMealFromFavorite(fav)
                                        dismiss()
                                    }) {
                                        Text("Add")
                                            .font(.caption.weight(.bold))
                                            .foregroundColor(.black)
                                            .padding(.horizontal, 16)
                                            .padding(.vertical, 8)
                                            .background(AppColors.accent)
                                            .clipShape(Capsule())
                                    }

                                    Button(action: { store.removeFavorite(fav.id) }) {
                                        Image(systemName: "trash")
                                            .font(.caption)
                                            .foregroundColor(AppColors.red.opacity(0.5))
                                    }
                                }
                                .padding(14)
                                .glassCard(cornerRadius: 14)
                            }
                        }
                        .padding()
                    }
                }
            }
            .navigationTitle("Favorites")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Done") { dismiss() }
                        .foregroundColor(AppColors.accent)
                }
            }
        }
    }
}
