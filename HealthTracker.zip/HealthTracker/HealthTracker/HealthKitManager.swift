import Foundation
import HealthKit

struct WatchWorkout: Identifiable {
    let id: String
    let date: String
    let type: ExerciseType
    let durationMinutes: Int
    let caloriesBurned: Int
    let sourceIdentifier: String
}

final class HealthKitManager {
    private let healthStore = HKHealthStore()
    private var observerQueries: [HKObserverQuery] = []
    private var isObserving = false

    var isAvailable: Bool {
        HKHealthStore.isHealthDataAvailable()
    }

    private var readTypes: Set<HKObjectType> {
        var types: Set<HKObjectType> = [HKObjectType.workoutType()]

        let quantityTypes: [HKQuantityTypeIdentifier] = [
            .stepCount,
            .heartRate,
            .restingHeartRate,
            .activeEnergyBurned,
            .oxygenSaturation,
            .distanceWalkingRunning,
            .flightsClimbed,
            .heartRateVariabilitySDNN,
        ]

        for identifier in quantityTypes {
            if let type = HKObjectType.quantityType(forIdentifier: identifier) {
                types.insert(type)
            }
        }

        if let sleepType = HKObjectType.categoryType(forIdentifier: .sleepAnalysis) {
            types.insert(sleepType)
        }

        return types
    }

    func requestAuthorization() async -> Bool {
        guard isAvailable else { return false }

        return await withCheckedContinuation { continuation in
            healthStore.requestAuthorization(toShare: Set<HKSampleType>(), read: readTypes) { success, _ in
                continuation.resume(returning: success)
            }
        }
    }

    // MARK: - Background Observer Queries

    /// Starts observer queries for key health data types.
    /// When new data arrives (e.g. from Apple Watch), the onChange callback fires.
    func startBackgroundObservers(onChange: @escaping () -> Void) {
        guard isAvailable, !isObserving else { return }
        isObserving = true

        // Types we want to auto-sync when new data arrives
        let observedQuantityTypes: [HKQuantityTypeIdentifier] = [
            .stepCount,
            .activeEnergyBurned,
            .heartRate,
            .distanceWalkingRunning,
        ]

        for identifier in observedQuantityTypes {
            guard let sampleType = HKObjectType.quantityType(forIdentifier: identifier) else { continue }

            let query = HKObserverQuery(sampleType: sampleType, predicate: nil) { [weak self] _, completionHandler, error in
                guard self != nil, error == nil else {
                    completionHandler()
                    return
                }
                onChange()
                completionHandler()
            }
            healthStore.execute(query)
            observerQueries.append(query)

            // Enable background delivery so the app wakes up when Watch writes new data
            healthStore.enableBackgroundDelivery(for: sampleType, frequency: .immediate) { _, _ in }
        }

        // Also observe workouts
        let workoutType = HKObjectType.workoutType()
        let workoutQuery = HKObserverQuery(sampleType: workoutType, predicate: nil) { [weak self] _, completionHandler, error in
            guard self != nil, error == nil else {
                completionHandler()
                return
            }
            onChange()
            completionHandler()
        }
        healthStore.execute(workoutQuery)
        observerQueries.append(workoutQuery)
        healthStore.enableBackgroundDelivery(for: workoutType, frequency: .immediate) { _, _ in }
    }

    func stopBackgroundObservers() {
        for query in observerQueries {
            healthStore.stop(query)
        }
        observerQueries.removeAll()
        isObserving = false
    }

    // MARK: - Fetch Today's Data (expanded)

    func fetchTodayHealthData() async -> HealthKitData {
        guard isAvailable else { return HealthKitData() }

        let todayStart = Calendar.current.startOfDay(for: Date())

        async let steps = fetchCumulativeSum(
            for: .stepCount,
            unit: .count(),
            startDate: todayStart
        )
        async let heartRate = fetchMostRecentQuantity(
            for: .heartRate,
            unit: HKUnit.count().unitDivided(by: .minute()),
            lookbackDays: 1
        )
        async let restingHeartRate = fetchMostRecentQuantity(
            for: .restingHeartRate,
            unit: HKUnit.count().unitDivided(by: .minute()),
            lookbackDays: 7
        )
        async let activeCalories = fetchCumulativeSum(
            for: .activeEnergyBurned,
            unit: .kilocalorie(),
            startDate: todayStart
        )
        async let oxygenSaturation = fetchMostRecentQuantity(
            for: .oxygenSaturation,
            unit: .percent(),
            lookbackDays: 7
        )
        async let distance = fetchCumulativeSum(
            for: .distanceWalkingRunning,
            unit: .meterUnit(with: .kilo),
            startDate: todayStart
        )
        async let flights = fetchCumulativeSum(
            for: .flightsClimbed,
            unit: .count(),
            startDate: todayStart
        )
        async let hrv = fetchMostRecentQuantity(
            for: .heartRateVariabilitySDNN,
            unit: .secondUnit(with: .milli),
            lookbackDays: 7
        )
        async let sleepHours = fetchLastNightSleepHours()

        let stepValue = await steps
        let heartRateValue = await heartRate
        let restingHeartRateValue = await restingHeartRate
        let activeCalorieValue = await activeCalories
        let oxygenSaturationValue = await oxygenSaturation
        let distanceValue = await distance
        let flightsValue = await flights
        let hrvValue = await hrv
        let sleepValue = await sleepHours

        return HealthKitData(
            steps: Int(stepValue.rounded()),
            heartRate: heartRateValue,
            restingHeartRate: restingHeartRateValue,
            activeCalories: activeCalorieValue,
            sleepHours: sleepValue,
            oxygenSaturation: oxygenSaturationValue * 100,
            distanceKm: (distanceValue * 100).rounded() / 100,
            flightsClimbed: Int(flightsValue.rounded()),
            hrv: (hrvValue * 10).rounded() / 10,
            isAuthorized: true,
            lastSyncDate: Date()
        )
    }

    func fetchTodayWorkouts() async -> [WatchWorkout] {
        guard isAvailable else { return [] }

        let startOfDay = Calendar.current.startOfDay(for: Date())
        let predicate = HKQuery.predicateForSamples(
            withStart: startOfDay,
            end: Date(),
            options: .strictStartDate
        )
        let sortDescriptor = NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: true)

        let workouts: [HKWorkout] = await withCheckedContinuation { continuation in
            let query = HKSampleQuery(
                sampleType: HKObjectType.workoutType(),
                predicate: predicate,
                limit: HKObjectQueryNoLimit,
                sortDescriptors: [sortDescriptor]
            ) { _, samples, _ in
                let results = (samples as? [HKWorkout]) ?? []
                continuation.resume(returning: results)
            }
            healthStore.execute(query)
        }

        return workouts.map { workout in
            WatchWorkout(
                id: workout.uuid.uuidString,
                date: dateString(for: workout.startDate),
                type: mapWorkoutType(workout.workoutActivityType),
                durationMinutes: max(Int((workout.duration / 60.0).rounded(.up)), 1),
                caloriesBurned: workoutCalories(workout),
                sourceIdentifier: workout.uuid.uuidString
            )
        }
    }

    // MARK: - Query Helpers

    private func fetchCumulativeSum(
        for identifier: HKQuantityTypeIdentifier,
        unit: HKUnit,
        startDate: Date
    ) async -> Double {
        guard let quantityType = HKObjectType.quantityType(forIdentifier: identifier) else { return 0 }

        let predicate = HKQuery.predicateForSamples(
            withStart: startDate,
            end: Date(),
            options: .strictStartDate
        )

        return await withCheckedContinuation { continuation in
            let query = HKStatisticsQuery(
                quantityType: quantityType,
                quantitySamplePredicate: predicate,
                options: .cumulativeSum
            ) { _, statistics, _ in
                let value = statistics?.sumQuantity()?.doubleValue(for: unit) ?? 0
                continuation.resume(returning: value)
            }
            healthStore.execute(query)
        }
    }

    private func fetchMostRecentQuantity(
        for identifier: HKQuantityTypeIdentifier,
        unit: HKUnit,
        lookbackDays: Int
    ) async -> Double {
        guard let quantityType = HKObjectType.quantityType(forIdentifier: identifier) else { return 0 }

        let startDate = Calendar.current.date(byAdding: .day, value: -lookbackDays, to: Date()) ?? Date.distantPast
        let predicate = HKQuery.predicateForSamples(
            withStart: startDate,
            end: Date(),
            options: .strictEndDate
        )
        let sortDescriptor = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)

        return await withCheckedContinuation { continuation in
            let query = HKSampleQuery(
                sampleType: quantityType,
                predicate: predicate,
                limit: 1,
                sortDescriptors: [sortDescriptor]
            ) { _, samples, _ in
                let sample = samples?.first as? HKQuantitySample
                let value = sample?.quantity.doubleValue(for: unit) ?? 0
                continuation.resume(returning: value)
            }
            healthStore.execute(query)
        }
    }

    private func fetchLastNightSleepHours() async -> Double {
        guard let sleepType = HKObjectType.categoryType(forIdentifier: .sleepAnalysis) else { return 0 }

        let now = Date()
        let calendar = Calendar.current
        let todayStart = calendar.startOfDay(for: now)
        let lookbackStart = calendar.date(byAdding: .hour, value: -12, to: todayStart) ?? todayStart
        let predicate = HKQuery.predicateForSamples(
            withStart: lookbackStart,
            end: now,
            options: .strictStartDate
        )

        let samples: [HKCategorySample] = await withCheckedContinuation { continuation in
            let query = HKSampleQuery(
                sampleType: sleepType,
                predicate: predicate,
                limit: HKObjectQueryNoLimit,
                sortDescriptors: nil
            ) { _, results, _ in
                let values = (results as? [HKCategorySample]) ?? []
                continuation.resume(returning: values)
            }
            healthStore.execute(query)
        }

        let totalSeconds = samples.reduce(0.0) { partial, sample in
            guard isAsleep(sample.value) else { return partial }
            return partial + sample.endDate.timeIntervalSince(sample.startDate)
        }

        return totalSeconds / 3600
    }

    private func isAsleep(_ value: Int) -> Bool {
        let asleepValues = [1, 3, 4, 5]
        return asleepValues.contains(value)
    }

    private func workoutCalories(_ workout: HKWorkout) -> Int {
        guard let energyType = HKQuantityType.quantityType(forIdentifier: .activeEnergyBurned) else {
            return 0
        }

        let calories = workout
            .statistics(for: energyType)?
            .sumQuantity()?
            .doubleValue(for: .kilocalorie()) ?? 0

        return Int(calories.rounded())
    }

    private func mapWorkoutType(_ workoutType: HKWorkoutActivityType) -> ExerciseType {
        switch workoutType {
        case .walking, .hiking:
            return .walking
        case .running:
            return .running
        case .cycling:
            return .cycling
        case .swimming:
            return .swimming
        case .yoga:
            return .yoga
        case .traditionalStrengthTraining, .functionalStrengthTraining, .coreTraining:
            return .strength
        case .highIntensityIntervalTraining:
            return .hiit
        case .basketball, .tennis, .soccer:
            return .sports
        case .mixedCardio, .elliptical, .rowing, .stairClimbing:
            return .cardio
        default:
            return .other
        }
    }
}
