import SwiftUI

struct HealthMetricsView: View {
    @EnvironmentObject var store: DataStore

    var body: some View {
        NavigationStack {
            ZStack {
                AnimatedMeshBackground()

                ScrollView {
                    VStack(alignment: .leading, spacing: 18) {
                        // Wellness Score Hero
                        wellnessHeroCard

                        // Body Composition
                        sectionHeader("Body Composition", icon: "figure.arms.open")
                        bodyCompositionGrid

                        // Nutrition Intelligence
                        sectionHeader("Nutrition Intelligence", icon: "leaf.fill")
                        nutritionGrid

                        // Macro Breakdown
                        macroBreakdownCard

                        // Sleep Insights
                        sectionHeader("Sleep Insights", icon: "bed.double.fill")
                        sleepInsightsCard

                        // Fasting
                        sectionHeader("Fasting", icon: "timer")
                        fastingQuickCard

                        // Cardiovascular & Recovery
                        sectionHeader("Cardio & Recovery", icon: "heart.text.clipboard.fill")
                        cardioRecoveryGrid

                        // Activity & Movement
                        sectionHeader("Activity & Movement", icon: "figure.run")
                        activityGrid

                        // Weight Trajectory
                        sectionHeader("Weight Trajectory", icon: "chart.line.uptrend.xyaxis")
                        weightTrajectoryCard

                        Spacer(minLength: 30)
                    }
                    .padding()
                }
            }
            .navigationTitle("Health Metrics")
        }
    }

    // MARK: - Section Header
    private func sectionHeader(_ title: String, icon: String) -> some View {
        HStack(spacing: 8) {
            Image(systemName: icon)
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(AppColors.accent)
            Text(title)
                .font(.system(size: 16, weight: .bold))
                .foregroundColor(.white)
        }
        .padding(.top, 6)
    }

    // MARK: - Wellness Hero Card
    private var wellnessHeroCard: some View {
        VStack(spacing: 16) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Wellness Score")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(.gray)
                    Text(store.wellnessLabel)
                        .font(.system(size: 20, weight: .bold))
                        .foregroundColor(store.wellnessColor)
                }
                Spacer()
                // Circular gauge
                ZStack {
                    Circle()
                        .stroke(Color.white.opacity(0.08), lineWidth: 10)
                        .frame(width: 90, height: 90)
                    Circle()
                        .trim(from: 0, to: CGFloat(store.wellnessScore) / 100)
                        .stroke(
                            AngularGradient(
                                colors: [store.wellnessColor.opacity(0.6), store.wellnessColor],
                                center: .center
                            ),
                            style: StrokeStyle(lineWidth: 10, lineCap: .round)
                        )
                        .frame(width: 90, height: 90)
                        .rotationEffect(.degrees(-90))
                    VStack(spacing: 0) {
                        Text("\(store.wellnessScore)")
                            .font(.system(size: 28, weight: .heavy, design: .rounded))
                            .foregroundColor(.white)
                        Text("/100")
                            .font(.system(size: 10, weight: .medium))
                            .foregroundColor(.gray)
                    }
                }
            }

            // Mini breakdown
            HStack(spacing: 0) {
                miniScoreItem("Nutrition", value: nutritionSubScore, color: AppColors.green)
                miniScoreItem("Activity", value: activitySubScore, color: AppColors.orange)
                miniScoreItem("Recovery", value: recoverySubScore, color: AppColors.blue)
                miniScoreItem("Compliance", value: complianceSubScore, color: AppColors.purple)
            }
        }
        .padding(18)
        .glassCard()
    }

    private var nutritionSubScore: Int {
        var s = 0.0
        let calVar = abs(Double(store.totalCalories - Profile.dailyCalories)) / Double(max(Profile.dailyCalories, 1))
        s += max(1 - calVar, 0) * 40
        s += min(Double(store.totalProtein) / Double(max(Profile.proteinTarget, 1)), 1) * 35
        s += min(store.waterLiters / max(Profile.waterTarget, 0.1), 1) * 25
        return min(Int(s.rounded()), 100)
    }

    private var activitySubScore: Int {
        var s = 0.0
        s += min(Double(store.todayExerciseMinutes) / 30.0, 1) * 60
        if store.healthKitData.isAuthorized && store.healthKitData.steps > 0 {
            s += min(Double(store.healthKitData.steps) / 10000.0, 1) * 40
        } else {
            s += min(Double(store.todayExerciseMinutes) / 45.0, 1) * 40
        }
        return min(Int(s.rounded()), 100)
    }

    private var recoverySubScore: Int {
        store.recoveryScore
    }

    private var complianceSubScore: Int {
        Int(store.supplementComplianceToday().rounded())
    }

    private func miniScoreItem(_ label: String, value: Int, color: Color) -> some View {
        VStack(spacing: 6) {
            ZStack {
                Circle()
                    .stroke(Color.white.opacity(0.06), lineWidth: 3)
                    .frame(width: 36, height: 36)
                Circle()
                    .trim(from: 0, to: CGFloat(value) / 100)
                    .stroke(color, style: StrokeStyle(lineWidth: 3, lineCap: .round))
                    .frame(width: 36, height: 36)
                    .rotationEffect(.degrees(-90))
                Text("\(value)")
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
            }
            Text(label)
                .font(.system(size: 9, weight: .medium))
                .foregroundColor(.gray)
        }
        .frame(maxWidth: .infinity)
    }

    // MARK: - Body Composition Grid
    private var bodyCompositionGrid: some View {
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
            MetricGaugeCard(
                title: "BMI",
                value: String(format: "%.1f", store.currentBMI),
                subtitle: store.bmiCategory,
                progress: min(store.currentBMI / 40, 1),
                color: store.bmiColor,
                icon: "scalemass"
            )

            MetricGaugeCard(
                title: "Body Fat",
                value: String(format: "%.1f%%", store.estimatedBodyFat),
                subtitle: store.bodyFatCategory,
                progress: min(store.estimatedBodyFat / 35, 1),
                color: store.estimatedBodyFat < 20 ? AppColors.green : AppColors.orange,
                icon: "figure.stand"
            )

            MetricGaugeCard(
                title: "Lean Mass",
                value: String(format: "%.1f", store.leanBodyMass),
                subtitle: "kg",
                progress: store.leanBodyMass / store.currentWeight,
                color: AppColors.accent,
                icon: "bolt.fill"
            )

            MetricGaugeCard(
                title: "BMR",
                value: "\(Int(store.bmr.rounded()))",
                subtitle: "kcal/day",
                progress: min(store.bmr / 2200, 1),
                color: AppColors.purple,
                icon: "flame"
            )
        }
    }

    // MARK: - Nutrition Grid
    private var nutritionGrid: some View {
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
            MetricGaugeCard(
                title: "TDEE",
                value: "\(Int(store.tdee.rounded()))",
                subtitle: "kcal/day",
                progress: min(store.tdee / 3000, 1),
                color: AppColors.orange,
                icon: "flame.fill"
            )

            MetricGaugeCard(
                title: "Caloric Balance",
                value: "\(store.caloricBalance > 0 ? "+" : "")\(store.caloricBalance)",
                subtitle: store.caloricBalance < 0 ? "Deficit" : "Surplus",
                progress: min(abs(Double(store.caloricBalance)) / 1000, 1),
                color: store.caloricBalance < 0 ? AppColors.green : AppColors.red,
                icon: "chart.bar"
            )

            MetricGaugeCard(
                title: "Net Calories",
                value: "\(store.netCalories)",
                subtitle: "eaten - burned",
                progress: min(Double(max(store.netCalories, 0)) / Double(max(Profile.dailyCalories, 1)), 1),
                color: AppColors.blue,
                icon: "minus.forwardslash.plus"
            )

            MetricGaugeCard(
                title: "Protein/kg",
                value: String(format: "%.2f", store.proteinPerKg),
                subtitle: store.proteinPerKg >= 1.6 ? "Optimal" : "Below 1.6g/kg",
                progress: min(store.proteinPerKg / 2.0, 1),
                color: store.proteinPerKg >= 1.6 ? AppColors.green : AppColors.orange,
                icon: "atom"
            )

            MetricGaugeCard(
                title: "Fiber",
                value: "\(store.totalFiber)g",
                subtitle: store.totalFiber >= 25 ? "Good" : "Target 25g+",
                progress: min(Double(store.totalFiber) / 30.0, 1),
                color: store.totalFiber >= 25 ? AppColors.green : AppColors.orange,
                icon: "leaf"
            )

            MetricGaugeCard(
                title: "Hydration",
                value: String(format: "%.0f%%", store.hydrationEfficiency),
                subtitle: String(format: "%.1fL / %.1fL", store.waterLiters, Profile.waterTarget),
                progress: store.hydrationEfficiency / 100,
                color: store.hydrationEfficiency >= 80 ? AppColors.blue : AppColors.orange,
                icon: "drop.fill"
            )
        }
    }

    // MARK: - Macro Breakdown Card
    private var macroBreakdownCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Macro Distribution")
                .font(.system(size: 14, weight: .bold))
                .foregroundColor(.white)

            if store.totalCalories > 0 {
                // Stacked bar
                GeometryReader { geo in
                    HStack(spacing: 2) {
                        RoundedRectangle(cornerRadius: 4)
                            .fill(AppColors.accent)
                            .frame(width: max(geo.size.width * store.macroRatioProtein / 100, 4))
                        RoundedRectangle(cornerRadius: 4)
                            .fill(AppColors.orange)
                            .frame(width: max(geo.size.width * store.macroRatioCarbs / 100, 4))
                        RoundedRectangle(cornerRadius: 4)
                            .fill(AppColors.red)
                            .frame(width: max(geo.size.width * store.macroRatioFat / 100, 4))
                    }
                }
                .frame(height: 14)
                .clipShape(RoundedRectangle(cornerRadius: 7))

                HStack(spacing: 16) {
                    macroLegendItem("Protein", pct: store.macroRatioProtein, grams: store.totalProtein, color: AppColors.accent)
                    macroLegendItem("Carbs", pct: store.macroRatioCarbs, grams: store.totalCarbs, color: AppColors.orange)
                    macroLegendItem("Fat", pct: store.macroRatioFat, grams: store.totalFat, color: AppColors.red)
                }

                // Ideal range hint
                Text("Ideal cut ratio: 30% protein, 40% carbs, 30% fat")
                    .font(.system(size: 10, weight: .medium))
                    .foregroundColor(.gray)
            } else {
                Text("Log meals to see macro distribution")
                    .font(.system(size: 12))
                    .foregroundColor(.gray)
            }
        }
        .padding(16)
        .glassCard()
    }

    private func macroLegendItem(_ label: String, pct: Double, grams: Int, color: Color) -> some View {
        HStack(spacing: 6) {
            Circle()
                .fill(color)
                .frame(width: 8, height: 8)
            VStack(alignment: .leading, spacing: 1) {
                Text("\(label) \(String(format: "%.0f", pct))%")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundColor(.white)
                Text("\(grams)g")
                    .font(.system(size: 10))
                    .foregroundColor(.gray)
            }
        }
    }

    // MARK: - Sleep Insights Card
    private var sleepInsightsCard: some View {
        let (avgHours, consistency) = store.sleepTrendLast7()

        return VStack(alignment: .leading, spacing: 14) {
            // Sleep bar chart (last 7 days)
            if !store.sleepLogs.isEmpty {
                HStack(alignment: .bottom, spacing: 6) {
                    ForEach(last7Days(), id: \.self) { day in
                        let log = store.sleepLogs.first { $0.date == day }
                        let hours = log?.hours ?? (day == todayString() && store.healthKitData.sleepHours > 0 ? store.healthKitData.sleepHours : 0)
                        VStack(spacing: 4) {
                            RoundedRectangle(cornerRadius: 4)
                                .fill(hours >= Profile.sleepTarget ? AppColors.blue : (hours > 0 ? AppColors.orange : Color.white.opacity(0.05)))
                                .frame(width: 28, height: max(CGFloat(hours / 10.0) * 60, 4))

                            Text(weekdayShort(for: day))
                                .font(.system(size: 8, weight: .medium))
                                .foregroundColor(.gray)
                        }
                        .frame(maxWidth: .infinity)
                    }
                }
                .frame(height: 80)
                .padding(.bottom, 4)
            }

            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                MetricGaugeCard(
                    title: "Avg Sleep",
                    value: avgHours > 0 ? String(format: "%.1f", avgHours) : "--",
                    subtitle: "hrs / 7 days",
                    progress: avgHours > 0 ? min(avgHours / Profile.sleepTarget, 1) : 0,
                    color: avgHours >= Profile.sleepTarget ? AppColors.green : AppColors.orange,
                    icon: "moon.zzz.fill"
                )

                MetricGaugeCard(
                    title: "Consistency",
                    value: consistency > 0 ? "\(Int(consistency))%" : "--",
                    subtitle: "sleep regularity",
                    progress: consistency / 100,
                    color: consistency >= 80 ? AppColors.green : AppColors.orange,
                    icon: "clock.fill"
                )
            }
        }
        .padding(16)
        .glassCard()
    }

    // MARK: - Fasting Quick Card
    private var fastingQuickCard: some View {
        NavigationLink(destination: FastingView().environmentObject(store)) {
            HStack(spacing: 14) {
                VStack(alignment: .leading, spacing: 6) {
                    if store.currentFasting.isActive {
                        Text("Currently Fasting")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(AppColors.purple)
                        Text("\(formatDuration(store.currentFasting.elapsedHours)) / \(Int(store.currentFasting.targetHours))h")
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                    } else {
                        Text("Intermittent Fasting")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(.white)
                        Text("\(store.fastingLogs.count) fasts completed")
                            .font(.system(size: 12))
                            .foregroundColor(.gray)
                    }
                }

                Spacer()

                VStack(alignment: .trailing, spacing: 4) {
                    Image(systemName: "timer")
                        .font(.system(size: 24))
                        .foregroundColor(AppColors.purple)

                    if store.fastingStreak > 0 {
                        HStack(spacing: 3) {
                            Image(systemName: "flame.fill")
                                .font(.system(size: 10))
                            Text("\(store.fastingStreak)")
                                .font(.system(size: 12, weight: .bold))
                        }
                        .foregroundColor(AppColors.orange)
                    }
                }
            }
            .padding(16)
            .glassCard()
        }
        .buttonStyle(.plain)
    }

    // MARK: - Cardio & Recovery Grid
    private var cardioRecoveryGrid: some View {
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
            MetricGaugeCard(
                title: "Recovery",
                value: "\(store.recoveryScore)",
                subtitle: store.recoveryLabel,
                progress: Double(store.recoveryScore) / 100,
                color: store.recoveryColor,
                icon: "bed.double.fill"
            )

            if let vo2 = store.estimatedVO2Max {
                MetricGaugeCard(
                    title: "Est. VO2 Max",
                    value: String(format: "%.1f", vo2),
                    subtitle: store.vo2MaxCategory,
                    progress: min(vo2 / 60, 1),
                    color: vo2 >= 44 ? AppColors.green : AppColors.orange,
                    icon: "lungs.fill"
                )
            } else {
                MetricGaugeCard(
                    title: "Est. VO2 Max",
                    value: "--",
                    subtitle: "Need Watch data",
                    progress: 0,
                    color: AppColors.subtleText,
                    icon: "lungs.fill"
                )
            }

            MetricGaugeCard(
                title: "Resting HR",
                value: store.healthKitData.restingHeartRate > 0 ? "\(Int(store.healthKitData.restingHeartRate))" : "--",
                subtitle: store.healthKitData.restingHeartRate > 0 ? "bpm" : "Need Watch",
                progress: store.healthKitData.restingHeartRate > 0 ? max(1 - (store.healthKitData.restingHeartRate - 40) / 60, 0) : 0,
                color: store.healthKitData.restingHeartRate > 0 && store.healthKitData.restingHeartRate < 65 ? AppColors.green : AppColors.orange,
                icon: "heart.fill"
            )

            MetricGaugeCard(
                title: "HRV",
                value: store.healthKitData.hrv > 0 ? "\(Int(store.healthKitData.hrv))" : "--",
                subtitle: store.healthKitData.hrv > 0 ? "ms" : "Need Watch",
                progress: store.healthKitData.hrv > 0 ? min(store.healthKitData.hrv / 80, 1) : 0,
                color: store.healthKitData.hrv >= 40 ? AppColors.green : AppColors.orange,
                icon: "waveform.path.ecg"
            )

            MetricGaugeCard(
                title: "SpO2",
                value: store.healthKitData.oxygenSaturation > 0 ? "\(Int(store.healthKitData.oxygenSaturation))%" : "--",
                subtitle: store.healthKitData.oxygenSaturation >= 95 ? "Normal" : "Need Watch",
                progress: store.healthKitData.oxygenSaturation > 0 ? store.healthKitData.oxygenSaturation / 100 : 0,
                color: store.healthKitData.oxygenSaturation >= 95 ? AppColors.green : AppColors.orange,
                icon: "drop.circle.fill"
            )

            MetricGaugeCard(
                title: "Sleep",
                value: store.healthKitData.sleepHours > 0 ? String(format: "%.1f", store.healthKitData.sleepHours) : "--",
                subtitle: store.healthKitData.sleepHours >= Profile.sleepTarget ? "On target" : "hrs",
                progress: store.healthKitData.sleepHours > 0 ? min(store.healthKitData.sleepHours / Profile.sleepTarget, 1) : 0,
                color: store.healthKitData.sleepHours >= Profile.sleepTarget ? AppColors.green : AppColors.orange,
                icon: "moon.zzz.fill"
            )
        }
    }

    // MARK: - Activity Grid
    private var activityGrid: some View {
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
            MetricGaugeCard(
                title: "Steps",
                value: store.healthKitData.steps > 0 ? formatStepsMetric(store.healthKitData.steps) : "\(store.todayExerciseMinutes)m",
                subtitle: store.healthKitData.steps > 0 ? "steps today" : "exercise",
                progress: store.healthKitData.steps > 0 ? min(Double(store.healthKitData.steps) / 10000, 1) : min(Double(store.todayExerciseMinutes) / 30, 1),
                color: AppColors.green,
                icon: "figure.walk"
            )

            MetricGaugeCard(
                title: "Active Burn",
                value: "\(store.todayExerciseCalories)",
                subtitle: "kcal",
                progress: min(Double(store.todayExerciseCalories) / 500, 1),
                color: AppColors.red,
                icon: "flame.fill"
            )

            MetricGaugeCard(
                title: "Distance",
                value: store.healthKitData.distanceKm > 0 ? String(format: "%.1f", store.healthKitData.distanceKm) : "--",
                subtitle: "km",
                progress: min(store.healthKitData.distanceKm / 8, 1),
                color: AppColors.blue,
                icon: "map.fill"
            )

            MetricGaugeCard(
                title: "Exercise Streak",
                value: "\(store.exerciseStreak)",
                subtitle: "days",
                progress: min(Double(store.exerciseStreak) / 7, 1),
                color: store.exerciseStreak >= 3 ? AppColors.green : AppColors.orange,
                icon: "trophy.fill"
            )
        }
    }

    // MARK: - Weight Trajectory Card
    private var weightTrajectoryCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Current")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundColor(.gray)
                    Text(String(format: "%.1f kg", store.currentWeight))
                        .font(.system(size: 22, weight: .heavy, design: .rounded))
                        .foregroundColor(.white)
                }
                Spacer()
                Image(systemName: "arrow.right")
                    .foregroundColor(AppColors.accent)
                Spacer()
                VStack(alignment: .trailing, spacing: 4) {
                    Text("Target")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundColor(.gray)
                    Text(String(format: "%.1f kg", Profile.targetWeight))
                        .font(.system(size: 22, weight: .heavy, design: .rounded))
                        .foregroundColor(AppColors.accent)
                }
            }

            // Progress bar
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 6)
                        .fill(Color.white.opacity(0.06))
                    RoundedRectangle(cornerRadius: 6)
                        .fill(
                            LinearGradient(
                                colors: [AppColors.accent.opacity(0.6), AppColors.accent],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .frame(width: geo.size.width * weightProgress)
                }
            }
            .frame(height: 10)

            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Lost")
                        .font(.system(size: 10, weight: .medium))
                        .foregroundColor(.gray)
                    Text(String(format: "%.1f kg", store.weightLost))
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(store.weightLost > 0 ? AppColors.green : AppColors.red)
                }

                Spacer()

                VStack(spacing: 2) {
                    Text("Velocity")
                        .font(.system(size: 10, weight: .medium))
                        .foregroundColor(.gray)
                    Text(String(format: "%+.1f kg/wk", store.weeklyWeightVelocity))
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(store.weeklyWeightVelocity < 0 ? AppColors.green : AppColors.red)
                }

                Spacer()

                VStack(alignment: .trailing, spacing: 2) {
                    Text("ETA")
                        .font(.system(size: 10, weight: .medium))
                        .foregroundColor(.gray)
                    Text(store.estimatedGoalDate ?? "N/A")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(AppColors.accent)
                }
            }

            if let days = store.daysToGoal, days > 0 {
                Text("~\(days) days remaining at current pace")
                    .font(.system(size: 10, weight: .medium))
                    .foregroundColor(.gray)
            }
        }
        .padding(18)
        .glassCard()
    }

    private var weightProgress: CGFloat {
        let total = Profile.startWeight - Profile.targetWeight
        guard total > 0 else { return 0 }
        return min(CGFloat(store.weightLost / total), 1)
    }

    // MARK: - Helpers
    private func formatStepsMetric(_ steps: Int) -> String {
        if steps >= 1000 {
            return String(format: "%.1fk", Double(steps) / 1000)
        }
        return "\(steps)"
    }
}

// MARK: - Metric Gauge Card Component
struct MetricGaugeCard: View {
    let title: String
    let value: String
    let subtitle: String
    let progress: Double
    let color: Color
    let icon: String

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(systemName: icon)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(color)
                Text(title)
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundColor(.gray)
                Spacer()
            }

            Text(value)
                .font(.system(size: 22, weight: .heavy, design: .rounded))
                .foregroundColor(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.7)

            // Mini progress bar
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 3)
                        .fill(Color.white.opacity(0.06))
                    RoundedRectangle(cornerRadius: 3)
                        .fill(color)
                        .frame(width: max(geo.size.width * min(max(progress, 0), 1), 2))
                }
            }
            .frame(height: 4)

            Text(subtitle)
                .font(.system(size: 10, weight: .medium))
                .foregroundColor(color.opacity(0.8))
                .lineLimit(1)
        }
        .padding(14)
        .glassCard(cornerRadius: 16)
    }
}
