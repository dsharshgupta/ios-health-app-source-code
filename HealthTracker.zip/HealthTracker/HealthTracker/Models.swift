import Foundation
import SwiftUI

// MARK: - Profile
struct Profile {
    static let name = "Harsh"
    static let age = 25
    static let heightCm: Double = 170
    static let startWeight: Double = 88
    static let targetWeight: Double = 73
    static let dailyCalories = 1750
    static let proteinTarget = 120
    static let carbTarget = 180
    static let fatTarget = 55
    static let waterTarget: Double = 3.5
    static let exerciseWeeklyTarget = 150
    static let sleepTarget: Double = 7.5 // hours

    static var bmi: Double {
        startWeight / ((heightCm / 100) * (heightCm / 100))
    }
}

// MARK: - Meal
struct Meal: Identifiable, Codable {
    let id: String
    let date: String
    let name: String
    let calories: Int
    let protein: Int
    let carbs: Int
    let fat: Int
    let fiber: Int
    let serving: String
    let rawInput: String

    init(date: String, name: String, calories: Int, protein: Int, carbs: Int, fat: Int, fiber: Int = 0, serving: String = "", rawInput: String = "") {
        self.id = UUID().uuidString
        self.date = date
        self.name = name
        self.calories = calories
        self.protein = protein
        self.carbs = carbs
        self.fat = fat
        self.fiber = fiber
        self.serving = serving
        self.rawInput = rawInput
    }
}

// MARK: - Weight Log
struct WeightLog: Identifiable, Codable {
    let id: String
    var date: String
    var kg: Double

    init(date: String, kg: Double) {
        self.id = UUID().uuidString
        self.date = date
        self.kg = kg
    }
}

// MARK: - Supplement
struct Supplement: Identifiable {
    let id: Int
    let name: String
    let time: String
    let icon: String
    var isDone: Bool = false
}

// MARK: - Water Log
struct WaterLog: Identifiable, Codable {
    let id: String
    let date: String
    var glasses: Int

    var liters: Double { Double(glasses) * 0.25 }

    init(date: String, glasses: Int) {
        self.id = UUID().uuidString
        self.date = date
        self.glasses = glasses
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.id = (try? container.decode(String.self, forKey: .id)) ?? UUID().uuidString
        self.date = try container.decode(String.self, forKey: .date)
        self.glasses = try container.decode(Int.self, forKey: .glasses)
    }
}

// MARK: - Exercise Log
struct ExerciseLog: Identifiable, Codable {
    let id: String
    let date: String
    let type: ExerciseType
    let durationMinutes: Int
    let caloriesBurned: Int
    let inputMethod: ExerciseInputMethod
    let sourceIdentifier: String?

    init(
        date: String,
        type: ExerciseType,
        durationMinutes: Int,
        caloriesBurned: Int,
        inputMethod: ExerciseInputMethod = .manual,
        sourceIdentifier: String? = nil
    ) {
        self.id = UUID().uuidString
        self.date = date
        self.type = type
        self.durationMinutes = durationMinutes
        self.caloriesBurned = caloriesBurned
        self.inputMethod = inputMethod
        self.sourceIdentifier = sourceIdentifier
    }
}

enum ExerciseType: String, Codable, CaseIterable {
    case cardio = "Cardio"
    case strength = "Strength Training"
    case yoga = "Yoga"
    case walking = "Walking"
    case running = "Running"
    case cycling = "Cycling"
    case swimming = "Swimming"
    case sports = "Sports"
    case hiit = "HIIT"
    case other = "Other"

    var icon: String {
        switch self {
        case .cardio: return "heart.circle.fill"
        case .strength: return "dumbbell.fill"
        case .yoga: return "figure.yoga"
        case .walking: return "figure.walk"
        case .running: return "figure.run"
        case .cycling: return "bicycle"
        case .swimming: return "figure.pool.swim"
        case .sports: return "sportscourt.fill"
        case .hiit: return "bolt.heart.fill"
        case .other: return "figure.mixed.cardio"
        }
    }

    var caloriesPerMinute: Double {
        switch self {
        case .cardio: return 8
        case .strength: return 6
        case .yoga: return 3.5
        case .walking: return 4
        case .running: return 11
        case .cycling: return 7.5
        case .swimming: return 9
        case .sports: return 7
        case .hiit: return 12
        case .other: return 5
        }
    }

    var color: Color {
        switch self {
        case .cardio: return Color(red: 1, green: 0.34, blue: 0.34)
        case .strength: return Color(red: 0.24, green: 0.84, blue: 0.78)
        case .yoga: return Color(red: 0.7, green: 0.5, blue: 1)
        case .walking: return Color(red: 0.36, green: 0.79, blue: 0.49)
        case .running: return Color(red: 0.94, green: 0.63, blue: 0.29)
        case .cycling: return Color(red: 0.3, green: 0.7, blue: 1)
        case .swimming: return Color(red: 0.2, green: 0.6, blue: 0.9)
        case .sports: return Color(red: 1, green: 0.8, blue: 0.2)
        case .hiit: return Color(red: 1, green: 0.4, blue: 0.6)
        case .other: return Color.gray
        }
    }
}

enum ExerciseInputMethod: String, Codable {
    case manual = "Manual"
    case estimated = "Estimated"
    case appleWatch = "Apple Watch"
}

// MARK: - Food Favorite
struct FoodFavorite: Identifiable, Codable {
    let id: String
    let name: String
    let rawInput: String
    let calories: Int
    let protein: Int
    let carbs: Int
    let fat: Int
    let fiber: Int
    let serving: String
    var useCount: Int

    init(from meal: Meal) {
        self.id = UUID().uuidString
        self.name = meal.name
        self.rawInput = meal.rawInput
        self.calories = meal.calories
        self.protein = meal.protein
        self.carbs = meal.carbs
        self.fat = meal.fat
        self.fiber = meal.fiber
        self.serving = meal.serving
        self.useCount = 1
    }
}

// MARK: - Sleep Log
struct SleepLog: Identifiable, Codable {
    let id: String
    let date: String
    let bedtime: Date
    let wakeTime: Date
    var hours: Double {
        wakeTime.timeIntervalSince(bedtime) / 3600
    }
    let source: String // "manual" or "apple_watch"
    var quality: Int? // 1-5 subjective quality rating

    init(date: String, bedtime: Date, wakeTime: Date, source: String = "manual", quality: Int? = nil) {
        self.id = UUID().uuidString
        self.date = date
        self.bedtime = bedtime
        self.wakeTime = wakeTime
        self.source = source
        self.quality = quality
    }
}

// MARK: - HealthKit Data (from Apple Watch)
struct HealthKitData: Codable {
    var steps: Int = 0
    var heartRate: Double = 0
    var restingHeartRate: Double = 0
    var activeCalories: Double = 0
    var sleepHours: Double = 0
    var oxygenSaturation: Double = 0
    var distanceKm: Double = 0
    var flightsClimbed: Int = 0
    var hrv: Double = 0 // Heart Rate Variability (ms)
    var isAuthorized: Bool = false
    var lastSyncDate: Date? = nil
}

// MARK: - Fasting State
struct FastingSession: Identifiable, Codable {
    let id: String
    var startTime: Date?
    var endTime: Date?
    var targetHours: Double = 16

    var isActive: Bool { startTime != nil && endTime == nil }

    var elapsedHours: Double {
        guard let start = startTime else { return 0 }
        let end = endTime ?? Date()
        return end.timeIntervalSince(start) / 3600
    }

    var progress: Double {
        min(elapsedHours / targetHours, 1.0)
    }

    var isComplete: Bool { elapsedHours >= targetHours }

    init(id: String = UUID().uuidString, startTime: Date? = nil, endTime: Date? = nil, targetHours: Double = 16) {
        self.id = id
        self.startTime = startTime
        self.endTime = endTime
        self.targetHours = targetHours
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.id = (try? container.decode(String.self, forKey: .id)) ?? UUID().uuidString
        self.startTime = try? container.decode(Date.self, forKey: .startTime)
        self.endTime = try? container.decode(Date.self, forKey: .endTime)
        self.targetHours = (try? container.decode(Double.self, forKey: .targetHours)) ?? 16
    }
}

// MARK: - Fasting Log (Completed Fasts)
struct FastingLog: Identifiable, Codable {
    let id: String
    let startTime: Date
    let endTime: Date
    let targetHours: Double
    var actualHours: Double { endTime.timeIntervalSince(startTime) / 3600 }
    var completed: Bool { actualHours >= targetHours }

    init(from session: FastingSession) {
        self.id = UUID().uuidString
        self.startTime = session.startTime ?? Date()
        self.endTime = session.endTime ?? Date()
        self.targetHours = session.targetHours
    }
}

// MARK: - Conversation Message (Agent Memory)
struct ConversationMessage: Identifiable, Codable {
    let id: String
    let role: String // "user" or "assistant"
    let content: String
    let timestamp: Date

    init(role: String, content: String) {
        self.id = UUID().uuidString
        self.role = role
        self.content = content
        self.timestamp = Date()
    }
}

// MARK: - Mood Entry
struct MoodEntry: Identifiable, Codable {
    let id: String
    let date: String
    let mood: Int // 1-5
    let energy: Int // 1-5
    let notes: String
    let timestamp: Date

    init(date: String, mood: Int, energy: Int, notes: String = "") {
        self.id = UUID().uuidString
        self.date = date
        self.mood = mood
        self.energy = energy
        self.notes = notes
        self.timestamp = Date()
    }

    var moodEmoji: String {
        switch mood {
        case 1: return "😞"
        case 2: return "😐"
        case 3: return "🙂"
        case 4: return "😊"
        case 5: return "🤩"
        default: return "🙂"
        }
    }

    var energyEmoji: String {
        switch energy {
        case 1: return "🪫"
        case 2: return "😴"
        case 3: return "⚡"
        case 4: return "🔋"
        case 5: return "⚡⚡"
        default: return "⚡"
        }
    }
}

// MARK: - Challenge
struct Challenge: Identifiable, Codable {
    let id: String
    let title: String
    let description: String
    let type: ChallengeType
    let targetValue: Double
    var currentValue: Double
    let startDate: String
    let endDate: String
    var isComplete: Bool { currentValue >= targetValue }

    init(title: String, description: String, type: ChallengeType, targetValue: Double, startDate: String, endDate: String) {
        self.id = UUID().uuidString
        self.title = title
        self.description = description
        self.type = type
        self.targetValue = targetValue
        self.currentValue = 0
        self.startDate = startDate
        self.endDate = endDate
    }
}

enum ChallengeType: String, Codable, CaseIterable {
    case protein = "Protein"
    case calories = "Calories"
    case water = "Water"
    case exercise = "Exercise"
    case steps = "Steps"
    case logging = "Logging"

    var icon: String {
        switch self {
        case .protein: return "fish.fill"
        case .calories: return "flame.fill"
        case .water: return "drop.fill"
        case .exercise: return "figure.run"
        case .steps: return "figure.walk"
        case .logging: return "checkmark.circle.fill"
        }
    }

    var color: Color {
        switch self {
        case .protein: return AppColors.accent
        case .calories: return AppColors.orange
        case .water: return AppColors.blue
        case .exercise: return AppColors.green
        case .steps: return AppColors.purple
        case .logging: return AppColors.indigo
        }
    }
}

// MARK: - Streak
struct Streak: Identifiable, Codable {
    let id: String
    let type: StreakType
    var currentCount: Int
    var longestCount: Int
    var lastDate: String

    init(type: StreakType) {
        self.id = UUID().uuidString
        self.type = type
        self.currentCount = 0
        self.longestCount = 0
        self.lastDate = ""
    }
}

enum StreakType: String, Codable, CaseIterable {
    case exercise = "Exercise"
    case water = "Water"
    case protein = "Protein"
    case logging = "Logging"
    case fasting = "Fasting"

    var icon: String {
        switch self {
        case .exercise: return "flame.fill"
        case .water: return "drop.fill"
        case .protein: return "fish.fill"
        case .logging: return "pencil.circle.fill"
        case .fasting: return "timer"
        }
    }

    var color: Color {
        switch self {
        case .exercise: return AppColors.orange
        case .water: return AppColors.blue
        case .protein: return AppColors.accent
        case .logging: return AppColors.green
        case .fasting: return AppColors.purple
        }
    }
}

// MARK: - Weekly Digest
struct WeeklyDigest: Identifiable, Codable {
    let id: String
    let weekStartDate: String
    let summary: String
    let wins: [String]
    let improvements: [String]
    let nextWeekGoal: String
    let generatedAt: Date

    init(weekStartDate: String, summary: String, wins: [String], improvements: [String], nextWeekGoal: String) {
        self.id = UUID().uuidString
        self.weekStartDate = weekStartDate
        self.summary = summary
        self.wins = wins
        self.improvements = improvements
        self.nextWeekGoal = nextWeekGoal
        self.generatedAt = Date()
    }
}

// MARK: - Editable Lab Value
struct EditableLabValue: Identifiable, Codable {
    let id: String
    var name: String
    var value: String
    var unit: String
    var referenceRange: String
    var status: String
    var statusColor: String
    var dateRecorded: String

    init(name: String, value: String, unit: String = "", referenceRange: String = "", status: String, statusColor: String, dateRecorded: String = "2026-04") {
        self.id = UUID().uuidString
        self.name = name
        self.value = value
        self.unit = unit
        self.referenceRange = referenceRange
        self.status = status
        self.statusColor = statusColor
        self.dateRecorded = dateRecorded
    }

    init(from legacy: LabValue) {
        self.id = UUID().uuidString
        self.name = legacy.name
        self.value = legacy.value
        self.unit = ""
        self.referenceRange = ""
        self.status = legacy.status
        self.statusColor = legacy.statusColor
        self.dateRecorded = "2026-04"
    }
}

// MARK: - Custom Supplement
struct CustomSupplement: Identifiable, Codable {
    let id: String
    var name: String
    var time: String
    var icon: String
    var isDaily: Bool
    var specificDay: String?
    var isDone: Bool

    init(name: String, time: String, icon: String, isDaily: Bool = true, specificDay: String? = nil) {
        self.id = UUID().uuidString
        self.name = name
        self.time = time
        self.icon = icon
        self.isDaily = isDaily
        self.specificDay = specificDay
        self.isDone = false
    }

    init(from legacy: Supplement) {
        self.id = UUID().uuidString
        self.name = legacy.name
        self.time = legacy.time
        self.icon = legacy.icon
        self.isDaily = true
        self.specificDay = nil
        self.isDone = legacy.isDone
    }
}

// MARK: - Daily Score
struct DailyScore {
    let calorieScore: Int      // 0-25
    let proteinScore: Int      // 0-25
    let exerciseScore: Int     // 0-20
    let waterScore: Int        // 0-15
    let supplementScore: Int   // 0-15
    var total: Int { calorieScore + proteinScore + exerciseScore + waterScore + supplementScore }

    var grade: String {
        switch total {
        case 90...100: return "A+"
        case 80..<90: return "A"
        case 70..<80: return "B"
        case 60..<70: return "C"
        case 50..<60: return "D"
        default: return "F"
        }
    }

    var gradeColor: Color {
        switch total {
        case 80...100: return AppColors.green
        case 60..<80: return AppColors.orange
        default: return AppColors.red
        }
    }
}

// MARK: - Schedule Items
struct ScheduleItem {
    static let dailySupplements: [Supplement] = [
        Supplement(id: 1, name: "Black Coffee", time: "09:00 AM", icon: "cup.and.saucer.fill"),
        Supplement(id: 2, name: "Gym Workout", time: "09:30 AM", icon: "dumbbell.fill"),
        Supplement(id: 3, name: "Whey Protein Shake", time: "10:30 AM", icon: "mug.fill"),
        Supplement(id: 4, name: "Nurokind-OD B12 1500mcg", time: "11:00 AM", icon: "pill.fill"),
        Supplement(id: 5, name: "Fish Oil 1000mg", time: "02:00 PM", icon: "fish.fill"),
        Supplement(id: 6, name: "Fish Oil 1000mg", time: "08:30 PM", icon: "fish.fill"),
    ]

    static let weeklyD3 = (name: "Uprise-D3 60K", day: "Sunday", icon: "sun.max.fill")
}

// MARK: - Lab Value
struct LabValue: Identifiable {
    let id = UUID()
    let name: String
    let value: String
    let status: String
    let statusColor: String
}

let labValues: [LabValue] = [
    LabValue(name: "B12", value: "160", status: "Low", statusColor: "red"),
    LabValue(name: "Vitamin D", value: "17.6", status: "Deficient", statusColor: "red"),
    LabValue(name: "HDL", value: "39", status: "Low", statusColor: "orange"),
    LabValue(name: "LDL", value: "129", status: "High", statusColor: "orange"),
    LabValue(name: "HbA1c", value: "4.5%", status: "Normal", statusColor: "green"),
    LabValue(name: "SGPT", value: "45", status: "Borderline", statusColor: "orange"),
    LabValue(name: "Creatinine", value: "0.86", status: "Normal", statusColor: "green"),
    LabValue(name: "TSH", value: "1.75", status: "Normal", statusColor: "green"),
]

// MARK: - Prediction
struct WeightPrediction: Identifiable {
    let id = UUID()
    let month: String
    let kg: Double
}

// MARK: - AI Food Analysis Response
struct GeminiFood: Codable {
    let name: String
    let calories: Int
    let protein: Int
    let carbs: Int
    let fat: Int
    let fiber: Int?
    let serving: String?

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        name = try container.decode(String.self, forKey: .name)

        // Accept both Int and Double from API (Claude sometimes returns decimals)
        if let intVal = try? container.decode(Int.self, forKey: .calories) {
            calories = intVal
        } else {
            calories = Int(try container.decode(Double.self, forKey: .calories))
        }
        if let intVal = try? container.decode(Int.self, forKey: .protein) {
            protein = intVal
        } else {
            protein = Int(try container.decode(Double.self, forKey: .protein))
        }
        if let intVal = try? container.decode(Int.self, forKey: .carbs) {
            carbs = intVal
        } else {
            carbs = Int(try container.decode(Double.self, forKey: .carbs))
        }
        if let intVal = try? container.decode(Int.self, forKey: .fat) {
            fat = intVal
        } else {
            fat = Int(try container.decode(Double.self, forKey: .fat))
        }
        if let intVal = try? container.decodeIfPresent(Int.self, forKey: .fiber) {
            fiber = intVal
        } else if let doubleVal = try? container.decodeIfPresent(Double.self, forKey: .fiber) {
            fiber = Int(doubleVal)
        } else {
            fiber = nil
        }
        serving = try container.decodeIfPresent(String.self, forKey: .serving)
    }
}

// MARK: - Report Data
struct WeeklyReport {
    let weekLabel: String
    let avgCalories: Int
    let avgProtein: Int
    let proteinCompliancePct: Double
    let supplementCompliancePct: Double
    let exerciseMinutes: Int
    let weightChange: Double
    let totalWorkouts: Int
}

// MARK: - Design System
struct AppColors {
    static let accent = Color(red: 0.24, green: 0.84, blue: 0.78)
    static let green = Color(red: 0.36, green: 0.79, blue: 0.49)
    static let orange = Color(red: 0.94, green: 0.63, blue: 0.29)
    static let red = Color(red: 1, green: 0.34, blue: 0.34)
    static let purple = Color(red: 0.7, green: 0.5, blue: 1)
    static let blue = Color(red: 0.3, green: 0.7, blue: 1)
    static let indigo = Color(red: 0.35, green: 0.35, blue: 0.85)
    static let background = Color(red: 0.035, green: 0.035, blue: 0.06)
    static let cardBg = Color.white.opacity(0.05)
    static let cardBorder = Color.white.opacity(0.08)
    static let subtleText = Color.gray.opacity(0.5)
}

// MARK: - Glassmorphism Card Modifier
struct GlassCard: ViewModifier {
    var cornerRadius: CGFloat = 20

    func body(content: Content) -> some View {
        content
            .background(
                RoundedRectangle(cornerRadius: cornerRadius)
                    .fill(.ultraThinMaterial.opacity(0.4))
                    .background(
                        RoundedRectangle(cornerRadius: cornerRadius)
                            .fill(
                                LinearGradient(
                                    colors: [Color.white.opacity(0.08), Color.white.opacity(0.02)],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                    )
            )
            .overlay(
                RoundedRectangle(cornerRadius: cornerRadius)
                    .stroke(
                        LinearGradient(
                            colors: [Color.white.opacity(0.15), Color.white.opacity(0.03)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        lineWidth: 0.5
                    )
            )
            .clipShape(RoundedRectangle(cornerRadius: cornerRadius))
    }
}

extension View {
    func glassCard(cornerRadius: CGFloat = 20) -> some View {
        modifier(GlassCard(cornerRadius: cornerRadius))
    }

    func dismissKeyboardOnTap() -> some View {
        self.simultaneousGesture(
            TapGesture().onEnded {
                hideKeyboard()
            }
        )
    }

    func keyboardDoneToolbar() -> some View {
        toolbar {
            ToolbarItemGroup(placement: .keyboard) {
                Spacer()
                Button("Done") {
                    hideKeyboard()
                }
            }
        }
    }
}

// MARK: - Animated Gradient Background
struct AnimatedMeshBackground: View {
    @State private var animate = false

    var body: some View {
        ZStack {
            AppColors.background
            Circle()
                .fill(AppColors.accent.opacity(0.06))
                .frame(width: 300, height: 300)
                .blur(radius: 80)
                .offset(x: animate ? 50 : -50, y: animate ? -30 : 30)
            Circle()
                .fill(AppColors.purple.opacity(0.04))
                .frame(width: 250, height: 250)
                .blur(radius: 80)
                .offset(x: animate ? -60 : 40, y: animate ? 60 : -40)
        }
        .ignoresSafeArea()
        .onAppear {
            withAnimation(.easeInOut(duration: 8).repeatForever(autoreverses: true)) {
                animate.toggle()
            }
        }
    }
}

// MARK: - Keyboard Dismiss ScrollView
struct DismissKeyboardScrollView<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }
    var body: some View {
        ScrollView {
            content
        }
        .scrollDismissesKeyboard(.interactively)
    }
}

// MARK: - Helpers
func hideKeyboard() {
    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
}

nonisolated func todayString() -> String {
    let f = DateFormatter()
    f.dateFormat = "yyyy-MM-dd"
    return f.string(from: Date())
}

func isSunday() -> Bool {
    Calendar.current.component(.weekday, from: Date()) == 1
}

func greetingText() -> String {
    let hour = Calendar.current.component(.hour, from: Date())
    if hour < 12 { return "Good Morning" }
    if hour < 17 { return "Good Afternoon" }
    return "Good Evening"
}

func dateString(for date: Date) -> String {
    let f = DateFormatter()
    f.dateFormat = "yyyy-MM-dd"
    return f.string(from: date)
}

func weekdayShort(for dateStr: String) -> String {
    let f = DateFormatter()
    f.dateFormat = "yyyy-MM-dd"
    guard let date = f.date(from: dateStr) else { return "" }
    let display = DateFormatter()
    display.dateFormat = "EEE"
    return display.string(from: date)
}

func last7Days() -> [String] {
    (0..<7).reversed().map { i in
        dateString(for: Calendar.current.date(byAdding: .day, value: -i, to: Date())!)
    }
}

func last30Days() -> [String] {
    (0..<30).reversed().map { i in
        dateString(for: Calendar.current.date(byAdding: .day, value: -i, to: Date())!)
    }
}

func formatTime(_ date: Date) -> String {
    let f = DateFormatter()
    f.dateFormat = "h:mm a"
    return f.string(from: date)
}

func formatDuration(_ hours: Double) -> String {
    let h = Int(hours)
    let m = Int((hours - Double(h)) * 60)
    return h > 0 ? "\(h)h \(m)m" : "\(m)m"
}
