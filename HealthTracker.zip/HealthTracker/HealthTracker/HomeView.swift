import SwiftUI
import AVFoundation
import Combine

struct HomeView: View {
    @EnvironmentObject var store: DataStore
    @StateObject private var speaker = AgentSpeaker()
    @State private var showMoodCheckIn = false

    var body: some View {
        NavigationStack {
            ZStack {
                AnimatedMeshBackground()

                ScrollView {
                    VStack(alignment: .leading, spacing: 18) {
                        // Greeting
                        greetingSection
                            .padding(.top, 4)

                        // AI Health Agent
                        aiAgentCard

                        // Proactive Warnings
                        if !store.proactiveWarnings.isEmpty {
                            warningsSection
                        }

                        // Mood Check-In Prompt
                        if store.todayMood == nil {
                            moodPromptCard
                        } else {
                            todayMoodCard
                        }

                        // Daily Challenge
                        if let challenge = store.todayChallenge {
                            challengeCard(challenge)
                        }

                        // Fasting Status
                        if store.currentFasting.isActive {
                            fastingStatusCard
                        }

                        // Calorie Ring Card
                        calorieCard

                        // Quick Stats Row
                        quickStatsRow

                        // Streaks Row
                        streaksRow

                        // Daily Score
                        dailyScoreCard

                        // Focus
                        focusCard

                        // Apple Watch
                        watchVitalsCard

                        // Water Quick Card
                        waterQuickCard

                        // Schedule
                        scheduleSection
                    }
                    .padding()
                }
            }
            .navigationBarHidden(true)
            .sheet(isPresented: $showMoodCheckIn) {
                MoodCheckInView()
                    .environmentObject(store)
            }
            .task {
                // Generate daily challenge if needed
                await store.generateDailyChallenge()
            }
        }
    }

    // MARK: - AI Health Agent Card
    @State private var showAskAgent = false
    @State private var agentQuestion = ""
    @State private var isAskingAgent = false

    private var aiAgentCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            // Header
            HStack {
                HStack(spacing: 10) {
                    ZStack {
                        Circle()
                            .fill(
                                LinearGradient(
                                    colors: [AppColors.purple, AppColors.blue],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                            .frame(width: 36, height: 36)
                        Image(systemName: "brain.head.profile")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.white)
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text("AI Health Coach")
                            .font(.system(size: 15, weight: .bold))
                        if let updated = store.agentLastUpdated {
                            Text(updated, style: .relative)
                                .font(.system(size: 10))
                                .foregroundColor(AppColors.subtleText)
                                + Text(" ago")
                                .font(.system(size: 10))
                                .foregroundColor(AppColors.subtleText)
                        }
                    }
                }

                Spacer()

                // Speaker button
                if !store.agentInsight.isEmpty {
                    Button(action: {
                        if speaker.isSpeaking {
                            speaker.stop()
                        } else {
                            speaker.speak(store.agentInsight)
                        }
                    }) {
                        Image(systemName: speaker.isSpeaking ? "speaker.wave.3.fill" : "speaker.wave.2")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(speaker.isSpeaking ? AppColors.accent : AppColors.purple)
                            .frame(width: 32, height: 32)
                            .background(speaker.isSpeaking ? AppColors.accent.opacity(0.15) : AppColors.purple.opacity(0.1))
                            .clipShape(Circle())
                    }
                }

                // Refresh button
                Button(action: {
                    speaker.stop()
                    Task { await store.refreshAgentInsight() }
                }) {
                    if store.isAgentThinking {
                        ProgressView()
                            .tint(AppColors.purple)
                            .frame(width: 32, height: 32)
                    } else {
                        Image(systemName: "arrow.clockwise")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundColor(AppColors.purple)
                            .frame(width: 32, height: 32)
                            .background(AppColors.purple.opacity(0.1))
                            .clipShape(Circle())
                    }
                }
                .disabled(store.isAgentThinking)
            }

            // AI Insight — formatted
            if store.isAgentThinking && store.agentInsight.isEmpty {
                HStack(spacing: 10) {
                    ProgressView()
                        .tint(AppColors.purple)
                    Text("Analyzing your day...")
                        .font(.system(size: 13))
                        .foregroundColor(AppColors.subtleText)
                }
                .padding(.vertical, 8)
            } else if !store.agentInsight.isEmpty {
                AgentResponseView(text: store.agentInsight)
            }

            // Action buttons row
            HStack(spacing: 10) {
                Button(action: { withAnimation(.spring(response: 0.3)) { showAskAgent.toggle() } }) {
                    HStack(spacing: 6) {
                        Image(systemName: showAskAgent ? "xmark" : "questionmark.bubble")
                            .font(.system(size: 11, weight: .semibold))
                        Text(showAskAgent ? "Close" : "Ask a question")
                            .font(.system(size: 12, weight: .semibold))
                    }
                    .foregroundColor(AppColors.purple)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 9)
                    .background(AppColors.purple.opacity(0.1))
                    .clipShape(Capsule())
                }

                Spacer()
            }

            // Expandable Q&A with conversation history
            if showAskAgent {
                VStack(spacing: 12) {
                    // Conversation thread
                    let recentMessages = store.conversationHistory.suffix(10)
                    if !recentMessages.isEmpty {
                        ScrollView {
                            VStack(spacing: 8) {
                                ForEach(Array(recentMessages)) { msg in
                                    HStack {
                                        if msg.role == "user" {
                                            Spacer()
                                            Text(msg.content)
                                                .font(.system(size: 12, weight: .medium))
                                                .foregroundColor(.white)
                                                .padding(10)
                                                .background(AppColors.purple.opacity(0.2))
                                                .clipShape(RoundedRectangle(cornerRadius: 12))
                                        } else {
                                            VStack(alignment: .leading, spacing: 4) {
                                                HStack(spacing: 4) {
                                                    Image(systemName: "sparkles")
                                                        .font(.system(size: 8))
                                                        .foregroundColor(AppColors.purple)
                                                    Text("AI")
                                                        .font(.system(size: 8, weight: .bold))
                                                        .foregroundColor(AppColors.purple)
                                                }
                                                AgentResponseView(text: msg.content)
                                            }
                                            .padding(10)
                                            .background(Color.white.opacity(0.04))
                                            .clipShape(RoundedRectangle(cornerRadius: 12))
                                            Spacer()
                                        }
                                    }
                                }
                            }
                        }
                        .frame(maxHeight: 200)

                        // Clear conversation button
                        HStack {
                            Spacer()
                            Button {
                                store.clearConversation()
                            } label: {
                                Text("Clear chat")
                                    .font(.system(size: 10, weight: .medium))
                                    .foregroundColor(.gray)
                            }
                        }
                    }

                    HStack(spacing: 8) {
                        TextField("e.g. Is paneer tikka good for dinner?", text: $agentQuestion)
                            .font(.system(size: 13))
                            .textFieldStyle(.plain)
                            .padding(12)
                            .background(Color.white.opacity(0.06))
                            .clipShape(RoundedRectangle(cornerRadius: 12))

                        Button(action: {
                            guard !agentQuestion.trimmingCharacters(in: .whitespaces).isEmpty else { return }
                            let q = agentQuestion
                            agentQuestion = ""
                            isAskingAgent = true
                            speaker.stop()
                            Task {
                                _ = await store.askAgent(q)
                                isAskingAgent = false
                            }
                        }) {
                            if isAskingAgent {
                                ProgressView()
                                    .tint(.white)
                                    .frame(width: 40, height: 40)
                            } else {
                                Image(systemName: "arrow.up.circle.fill")
                                    .font(.system(size: 28))
                                    .foregroundColor(AppColors.purple)
                            }
                        }
                        .disabled(isAskingAgent)
                    }
                }
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(Color.white.opacity(0.05))
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(
                            LinearGradient(
                                colors: [AppColors.purple.opacity(0.3), AppColors.blue.opacity(0.15)],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 1
                        )
                )
        )
        .animation(.spring(response: 0.4), value: showAskAgent)
    }

    // MARK: - Proactive Warnings
    private var warningsSection: some View {
        VStack(spacing: 8) {
            ForEach(store.proactiveWarnings, id: \.self) { warning in
                HStack(spacing: 10) {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .font(.system(size: 12))
                        .foregroundColor(AppColors.orange)

                    Text(warning)
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(AppColors.orange)

                    Spacer()
                }
                .padding(12)
                .background(AppColors.orange.opacity(0.08))
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(AppColors.orange.opacity(0.2), lineWidth: 0.5)
                )
            }
        }
    }

    // MARK: - Mood Prompt Card
    private var moodPromptCard: some View {
        Button { showMoodCheckIn = true } label: {
            HStack(spacing: 12) {
                Text("🙂")
                    .font(.system(size: 28))

                VStack(alignment: .leading, spacing: 2) {
                    Text("How are you feeling?")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(.white)
                    Text("Quick mood & energy check-in")
                        .font(.system(size: 11))
                        .foregroundColor(.gray)
                }

                Spacer()

                Image(systemName: "chevron.right")
                    .font(.system(size: 12, weight: .bold))
                    .foregroundColor(AppColors.accent)
            }
            .padding(14)
            .glassCard()
        }
        .buttonStyle(.plain)
    }

    // MARK: - Today Mood Card
    private var todayMoodCard: some View {
        HStack(spacing: 14) {
            if let mood = store.todayMood {
                Text(mood.moodEmoji)
                    .font(.system(size: 28))

                VStack(alignment: .leading, spacing: 2) {
                    Text("Mood: \(mood.mood)/5  Energy: \(mood.energy)/5")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(.white)

                    if !mood.notes.isEmpty {
                        Text(mood.notes)
                            .font(.system(size: 11))
                            .foregroundColor(.gray)
                            .lineLimit(1)
                    }
                }

                Spacer()

                Button { showMoodCheckIn = true } label: {
                    Image(systemName: "pencil.circle.fill")
                        .font(.system(size: 20))
                        .foregroundColor(AppColors.accent.opacity(0.6))
                }
            }
        }
        .padding(14)
        .glassCard()
    }

    // MARK: - Challenge Card
    private func challengeCard(_ challenge: Challenge) -> some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(AppColors.orange.opacity(0.15))
                    .frame(width: 40, height: 40)
                Image(systemName: challenge.isComplete ? "checkmark.circle.fill" : "bolt.fill")
                    .font(.system(size: 16))
                    .foregroundColor(challenge.isComplete ? AppColors.green : AppColors.orange)
            }

            VStack(alignment: .leading, spacing: 3) {
                Text("TODAY'S CHALLENGE")
                    .font(.system(size: 9, weight: .bold))
                    .tracking(1)
                    .foregroundColor(AppColors.orange)
                Text(challenge.title)
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(challenge.isComplete ? AppColors.green : .white)
            }

            Spacer()

            if challenge.isComplete {
                Text("Done!")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundColor(AppColors.green)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background(AppColors.green.opacity(0.15))
                    .clipShape(Capsule())
            }
        }
        .padding(14)
        .glassCard()
    }

    // MARK: - Fasting Status Card
    private var fastingStatusCard: some View {
        NavigationLink(destination: FastingView().environmentObject(store)) {
            TimelineView(.periodic(from: .now, by: 60)) { _ in
                HStack(spacing: 14) {
                    ZStack {
                        Circle()
                            .stroke(Color.white.opacity(0.08), lineWidth: 4)
                            .frame(width: 44, height: 44)
                        Circle()
                            .trim(from: 0, to: store.currentFasting.progress)
                            .stroke(AppColors.purple, style: StrokeStyle(lineWidth: 4, lineCap: .round))
                            .frame(width: 44, height: 44)
                            .rotationEffect(.degrees(-90))
                        Image(systemName: "timer")
                            .font(.system(size: 14))
                            .foregroundColor(AppColors.purple)
                    }

                    VStack(alignment: .leading, spacing: 3) {
                        Text(store.currentFasting.isComplete ? "FAST COMPLETE" : "FASTING")
                            .font(.system(size: 9, weight: .bold))
                            .tracking(1)
                            .foregroundColor(store.currentFasting.isComplete ? AppColors.green : AppColors.purple)

                        Text(formatDuration(store.currentFasting.elapsedHours) + " / \(Int(store.currentFasting.targetHours))h")
                            .font(.system(size: 15, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                    }

                    Spacer()

                    Image(systemName: "chevron.right")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundColor(AppColors.purple.opacity(0.5))
                }
            }
            .padding(14)
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(AppColors.purple.opacity(0.06))
                    .overlay(
                        RoundedRectangle(cornerRadius: 20)
                            .stroke(AppColors.purple.opacity(0.2), lineWidth: 0.5)
                    )
            )
            .glassCard()
        }
        .buttonStyle(.plain)
    }

    // MARK: - Streaks Row
    private var streaksRow: some View {
        let activeStreaks = store.streaks.filter { $0.currentCount > 0 }
        guard !activeStreaks.isEmpty else { return AnyView(EmptyView()) }

        return AnyView(
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach(activeStreaks) { streak in
                        HStack(spacing: 6) {
                            Image(systemName: streak.type.icon)
                                .font(.system(size: 11))
                                .foregroundColor(streak.type.color)

                            Text("\(streak.currentCount)")
                                .font(.system(size: 14, weight: .bold, design: .rounded))
                                .foregroundColor(.white)

                            Text(streak.type.rawValue)
                                .font(.system(size: 10, weight: .medium))
                                .foregroundColor(.gray)
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(streak.type.color.opacity(0.1))
                        .clipShape(Capsule())
                        .overlay(
                            Capsule()
                                .stroke(streak.type.color.opacity(0.2), lineWidth: 0.5)
                        )
                    }
                }
            }
        )
    }

    // MARK: - Greeting
    private var greetingSection: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(greetingText())
                .font(.subheadline)
                .foregroundColor(AppColors.subtleText)
            HStack(spacing: 8) {
                Text(Profile.name)
                    .font(.system(size: 32, weight: .bold, design: .rounded))
                if store.exerciseStreak > 0 {
                    HStack(spacing: 3) {
                        Image(systemName: "flame.fill")
                            .font(.caption)
                            .foregroundColor(AppColors.orange)
                        Text("\(store.exerciseStreak)")
                            .font(.caption.weight(.bold))
                            .foregroundColor(AppColors.orange)
                    }
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(AppColors.orange.opacity(0.12))
                    .clipShape(Capsule())
                }
            }
        }
    }

    // MARK: - Calorie Card
    private var calorieCard: some View {
        HStack(spacing: 20) {
            // Ring
            ZStack {
                // Glow
                Circle()
                    .fill(
                        store.totalCalories > Profile.dailyCalories
                        ? AppColors.red.opacity(0.08)
                        : AppColors.accent.opacity(0.08)
                    )
                    .frame(width: 115, height: 115)
                    .blur(radius: 10)

                Circle()
                    .stroke(Color.white.opacity(0.05), lineWidth: 10)
                    .frame(width: 110, height: 110)

                Circle()
                    .trim(from: 0, to: min(Double(store.totalCalories) / Double(Profile.dailyCalories), 1.15))
                    .stroke(
                        AngularGradient(
                            colors: store.totalCalories > Profile.dailyCalories
                                ? [AppColors.red, AppColors.orange, AppColors.red]
                                : [AppColors.accent, AppColors.green, AppColors.accent],
                            center: .center,
                            startAngle: .degrees(-90),
                            endAngle: .degrees(270)
                        ),
                        style: StrokeStyle(lineWidth: 10, lineCap: .round)
                    )
                    .frame(width: 110, height: 110)
                    .rotationEffect(.degrees(-90))
                    .animation(.spring(response: 0.8, dampingFraction: 0.7), value: store.totalCalories)

                VStack(spacing: 0) {
                    Text("\(store.totalCalories)")
                        .font(.system(size: 26, weight: .bold, design: .rounded))
                    Text("/ \(Profile.dailyCalories)")
                        .font(.system(size: 10))
                        .foregroundColor(AppColors.subtleText)
                }
            }

            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("REMAINING")
                            .font(.system(size: 9, weight: .semibold))
                            .foregroundColor(AppColors.subtleText)
                            .tracking(0.5)
                        HStack(alignment: .firstTextBaseline, spacing: 2) {
                            Text(store.remainingCalories >= 0 ? "\(store.remainingCalories)" : "+\(abs(store.remainingCalories))")
                                .font(.system(size: 22, weight: .bold, design: .rounded))
                                .foregroundColor(store.remainingCalories >= 0 ? AppColors.accent : AppColors.red)
                            Text("kcal")
                                .font(.system(size: 10))
                                .foregroundColor(AppColors.subtleText)
                        }
                    }
                    Spacer()
                    VStack(alignment: .trailing, spacing: 2) {
                        Text("PROTEIN")
                            .font(.system(size: 9, weight: .semibold))
                            .foregroundColor(AppColors.subtleText)
                            .tracking(0.5)
                        HStack(alignment: .firstTextBaseline, spacing: 2) {
                            Text("\(store.totalProtein)")
                                .font(.system(size: 22, weight: .bold, design: .rounded))
                                .foregroundColor(store.totalProtein >= Profile.proteinTarget ? AppColors.green : AppColors.orange)
                            Text("/\(Profile.proteinTarget)g")
                                .font(.system(size: 10))
                                .foregroundColor(AppColors.subtleText)
                        }
                    }
                }

                // Smart hint
                if store.remainingCalories < 0 {
                    smartHint(
                        icon: "exclamationmark.triangle.fill",
                        text: "Over by \(abs(store.remainingCalories)) kcal — walk 30 min extra",
                        color: AppColors.red
                    )
                } else if store.remainingCalories > 0 && store.remainingCalories < 500 && store.totalProtein < Profile.proteinTarget {
                    smartHint(
                        icon: "lightbulb.fill",
                        text: "Room for a protein shake to hit your goal",
                        color: AppColors.accent
                    )
                }
            }
        }
        .padding(18)
        .glassCard()
    }

    private func smartHint(icon: String, text: String, color: Color) -> some View {
        HStack(spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 10))
            Text(text)
                .font(.caption2)
        }
        .foregroundColor(color)
        .padding(8)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(color.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 8))
    }

    // MARK: - Quick Stats
    private var quickStatsRow: some View {
        HStack(spacing: 10) {
            // Weight
            quickStatCard(
                icon: "scalemass.fill",
                value: String(format: "%.1f", store.currentWeight),
                unit: "kg",
                label: "WEIGHT",
                color: AppColors.accent,
                secondaryValue: store.weightLost > 0 ? String(format: "-%.1f", store.weightLost) : nil,
                secondaryColor: AppColors.green
            )

            // Exercise today
            quickStatCard(
                icon: "flame.fill",
                value: "\(store.todayExerciseCalories)",
                unit: "kcal",
                label: "BURNED",
                color: AppColors.orange,
                secondaryValue: store.todayExerciseMinutes > 0 ? "\(store.todayExerciseMinutes) min" : nil,
                secondaryColor: AppColors.subtleText
            )

            // Water
            quickStatCard(
                icon: "drop.fill",
                value: "\(String(format: "%.1f", store.waterLiters))",
                unit: "L",
                label: "WATER",
                color: AppColors.blue,
                secondaryValue: "\(store.waterGlasses) glasses",
                secondaryColor: AppColors.subtleText
            )
        }
    }

    private func quickStatCard(icon: String, value: String, unit: String, label: String, color: Color, secondaryValue: String?, secondaryColor: Color?) -> some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.caption)
                .foregroundColor(color)

            HStack(alignment: .firstTextBaseline, spacing: 1) {
                Text(value)
                    .font(.system(size: 18, weight: .bold, design: .rounded))
                Text(unit)
                    .font(.system(size: 8))
                    .foregroundColor(AppColors.subtleText)
            }

            Text(label)
                .font(.system(size: 7, weight: .semibold))
                .foregroundColor(AppColors.subtleText)
                .tracking(0.5)

            if let sec = secondaryValue {
                Text(sec)
                    .font(.system(size: 9, weight: .medium))
                    .foregroundColor(secondaryColor ?? .gray)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .glassCard(cornerRadius: 14)
    }

    // MARK: - Daily Score
    private var dailyScoreCard: some View {
        let score = store.dailyScore

        return HStack(spacing: 16) {
            VStack(spacing: 4) {
                Text("\(score.total)")
                    .font(.system(size: 34, weight: .bold, design: .rounded))
                    .foregroundColor(score.gradeColor)
                Text(score.grade)
                    .font(.headline.weight(.bold))
                    .foregroundColor(score.gradeColor)
                Text("Harsh's day")
                    .font(.caption2)
                    .foregroundColor(AppColors.subtleText)
            }
            .frame(width: 78)

            VStack(spacing: 10) {
                scoreRow(title: "Calories", value: score.calorieScore, max: 25, color: AppColors.accent)
                scoreRow(title: "Protein", value: score.proteinScore, max: 25, color: AppColors.green)
                scoreRow(title: "Exercise", value: score.exerciseScore, max: 20, color: AppColors.orange)
                scoreRow(title: "Water", value: score.waterScore, max: 15, color: AppColors.blue)
                scoreRow(title: "Supps", value: score.supplementScore, max: 15, color: AppColors.purple)
            }
        }
        .padding(18)
        .glassCard()
    }

    private func scoreRow(title: String, value: Int, max: Int, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(title.uppercased())
                    .font(.system(size: 8, weight: .semibold))
                    .foregroundColor(AppColors.subtleText)
                    .tracking(0.6)
                Spacer()
                Text("\(value)/\(max)")
                    .font(.system(size: 9, weight: .medium, design: .rounded))
                    .foregroundColor(color)
            }

            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 3)
                        .fill(Color.white.opacity(0.05))
                        .frame(height: 5)
                    RoundedRectangle(cornerRadius: 3)
                        .fill(color)
                        .frame(width: geo.size.width * CGFloat(Double(value) / Double(max)), height: 5)
                }
            }
            .frame(height: 5)
        }
    }

    // MARK: - Focus Card
    private var focusCard: some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(store.watchRecoveryColor.opacity(0.18))
                    .frame(width: 46, height: 46)
                Image(systemName: "target")
                    .font(.title3)
                    .foregroundColor(store.watchRecoveryColor)
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(store.dailyFocusTitle)
                    .font(.headline)
                Text(store.dailyFocusMessage)
                    .font(.caption)
                    .foregroundColor(AppColors.subtleText)
            }

            Spacer()
        }
        .padding(16)
        .glassCard()
    }

    // MARK: - Apple Watch
    private var watchVitalsCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                HStack(spacing: 8) {
                    Image(systemName: "applewatch")
                        .foregroundColor(AppColors.blue)
                    Text("Apple Watch & Vitals")
                        .font(.headline)
                }

                Spacer()

                Button(action: {
                    Task {
                        await store.syncAppleWatchData()
                    }
                }) {
                    HStack(spacing: 6) {
                        if store.isSyncingHealthData {
                            ProgressView()
                                .tint(.black)
                        } else {
                            Image(systemName: store.healthKitData.isAuthorized ? "arrow.clockwise" : "link")
                        }
                        Text(store.healthKitData.isAuthorized ? "Sync" : "Connect")
                            .font(.caption.weight(.bold))
                    }
                    .foregroundColor(.black)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(AppColors.blue)
                    .clipShape(Capsule())
                }
                .disabled(store.isSyncingHealthData)
            }

            if store.healthKitData.isAuthorized {
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 8), count: 3), spacing: 8) {
                    watchMetricCard(
                        icon: "figure.walk",
                        title: "Steps",
                        value: "\(store.healthKitData.steps)",
                        color: AppColors.green
                    )
                    watchMetricCard(
                        icon: "heart.fill",
                        title: "Heart",
                        value: store.healthKitData.heartRate > 0 ? "\(Int(store.healthKitData.heartRate.rounded())) bpm" : "--",
                        color: AppColors.red
                    )
                    watchMetricCard(
                        icon: "bed.double.fill",
                        title: "Sleep",
                        value: store.healthKitData.sleepHours > 0 ? "\(String(format: "%.1f", store.healthKitData.sleepHours))h" : "--",
                        color: AppColors.blue
                    )
                    watchMetricCard(
                        icon: "flame.fill",
                        title: "Active",
                        value: "\(Int(store.healthKitData.activeCalories.rounded())) kcal",
                        color: AppColors.orange
                    )
                    watchMetricCard(
                        icon: "map.fill",
                        title: "Distance",
                        value: store.healthKitData.distanceKm > 0 ? "\(String(format: "%.1f", store.healthKitData.distanceKm)) km" : "--",
                        color: AppColors.accent
                    )
                    watchMetricCard(
                        icon: "waveform.path.ecg",
                        title: "Resting",
                        value: store.healthKitData.restingHeartRate > 0 ? "\(Int(store.healthKitData.restingHeartRate.rounded())) bpm" : "--",
                        color: AppColors.accent
                    )
                    watchMetricCard(
                        icon: "waveform.path.ecg.rectangle",
                        title: "HRV",
                        value: store.healthKitData.hrv > 0 ? "\(Int(store.healthKitData.hrv)) ms" : "--",
                        color: AppColors.purple
                    )
                    watchMetricCard(
                        icon: "lungs.fill",
                        title: "SpO₂",
                        value: store.healthKitData.oxygenSaturation > 0 ? "\(Int(store.healthKitData.oxygenSaturation.rounded()))%" : "--",
                        color: AppColors.indigo
                    )
                    watchMetricCard(
                        icon: "arrow.up.right",
                        title: "Flights",
                        value: store.healthKitData.flightsClimbed > 0 ? "\(store.healthKitData.flightsClimbed)" : "--",
                        color: AppColors.green
                    )
                }

                HStack {
                    Text(store.healthKitData.lastSyncDate.map { "Last sync: \(formatTime($0))" } ?? "Not synced yet")
                        .font(.caption2)
                        .foregroundColor(AppColors.subtleText)
                    Spacer()
                    HStack(spacing: 4) {
                        Circle()
                            .fill(AppColors.green)
                            .frame(width: 6, height: 6)
                        Text("Auto-sync on")
                            .font(.system(size: 9, weight: .medium))
                            .foregroundColor(AppColors.subtleText)
                    }
                }
            } else {
                Text("Connect once and the app will auto-sync steps, heart rate, HRV, sleep, distance, calories, SpO₂, and Apple Watch workouts in the background.")
                    .font(.caption)
                    .foregroundColor(AppColors.subtleText)
            }

            if !store.healthSyncMessage.isEmpty {
                Text(store.healthSyncMessage)
                    .font(.caption2)
                    .foregroundColor(Color.white.opacity(0.45))
            }
        }
        .padding(16)
        .glassCard()
    }

    private func watchMetricCard(icon: String, title: String, value: String, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Image(systemName: icon)
                .font(.caption)
                .foregroundColor(color)
            Text(title.uppercased())
                .font(.system(size: 8, weight: .semibold))
                .foregroundColor(AppColors.subtleText)
                .tracking(0.6)
            Text(value)
                .font(.system(size: 13, weight: .bold, design: .rounded))
                .foregroundColor(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.7)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(12)
        .background(Color.white.opacity(0.05))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }

    // MARK: - Water Quick Card
    private var waterQuickCard: some View {
        HStack(spacing: 14) {
            // Mini progress ring
            ZStack {
                Circle()
                    .stroke(Color.white.opacity(0.06), lineWidth: 5)
                    .frame(width: 44, height: 44)
                Circle()
                    .trim(from: 0, to: store.waterProgress)
                    .stroke(AppColors.blue, style: StrokeStyle(lineWidth: 5, lineCap: .round))
                    .frame(width: 44, height: 44)
                    .rotationEffect(.degrees(-90))
                    .animation(.spring(response: 0.5), value: store.waterGlasses)
                Image(systemName: "drop.fill")
                    .font(.system(size: 12))
                    .foregroundColor(AppColors.blue)
            }

            VStack(alignment: .leading, spacing: 3) {
                Text("\(String(format: "%.1f", store.waterLiters))L of \(String(format: "%.1f", Profile.waterTarget))L")
                    .font(.subheadline.weight(.semibold))
                let glassesLeft = max(0, Int(ceil((Profile.waterTarget - store.waterLiters) / 0.25)))
                Text(glassesLeft > 0 ? "\(glassesLeft) glasses to go" : "Goal reached!")
                    .font(.caption2)
                    .foregroundColor(glassesLeft > 0 ? AppColors.subtleText : AppColors.green)
            }

            Spacer()

            Button(action: {
                withAnimation(.spring(response: 0.3)) {
                    store.addWaterGlass()
                }
            }) {
                Image(systemName: "plus")
                    .font(.subheadline.weight(.bold))
                    .foregroundColor(.black)
                    .frame(width: 36, height: 36)
                    .background(AppColors.blue)
                    .clipShape(Circle())
            }
        }
        .padding(14)
        .glassCard()
    }

    // MARK: - Schedule
    private var scheduleSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Today's Schedule")
                    .font(.headline)
                Spacer()
                Text("\(store.doneCount)/\(store.supplements.count)")
                    .font(.caption.weight(.semibold))
                    .foregroundColor(AppColors.accent)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(AppColors.accent.opacity(0.12))
                    .clipShape(Capsule())
            }

            VStack(spacing: 2) {
                ForEach(store.supplements) { supp in
                    Button(action: {
                        withAnimation(.spring(response: 0.3)) {
                            store.toggleSupplement(supp.id)
                        }
                    }) {
                        HStack(spacing: 12) {
                            // Checkbox
                            ZStack {
                                Circle()
                                    .stroke(supp.isDone ? AppColors.accent : Color.white.opacity(0.15), lineWidth: 2)
                                    .frame(width: 24, height: 24)
                                if supp.isDone {
                                    Circle()
                                        .fill(AppColors.accent)
                                        .frame(width: 24, height: 24)
                                    Image(systemName: "checkmark")
                                        .font(.system(size: 10, weight: .bold))
                                        .foregroundColor(.black)
                                }
                            }

                            // Icon
                            Image(systemName: supp.icon)
                                .font(.body)
                                .foregroundColor(supp.isDone ? AppColors.subtleText : AppColors.accent)
                                .frame(width: 28)

                            VStack(alignment: .leading, spacing: 2) {
                                Text(supp.name)
                                    .font(.subheadline)
                                    .foregroundColor(supp.isDone ? AppColors.subtleText : .white)
                                    .strikethrough(supp.isDone, color: AppColors.subtleText)
                                Text(supp.time)
                                    .font(.system(size: 10))
                                    .foregroundColor(Color.white.opacity(0.2))
                            }

                            Spacer()
                        }
                        .padding(.vertical, 10)
                        .padding(.horizontal, 14)
                    }
                    .buttonStyle(.plain)

                    if supp.id != store.supplements.last?.id {
                        Divider().opacity(0.06).padding(.leading, 50)
                    }
                }

                // Sunday D3
                if isSunday() {
                    HStack(spacing: 12) {
                        Image(systemName: "sun.max.fill")
                            .font(.title3)
                            .foregroundColor(.yellow)
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Uprise-D3 60K")
                                .font(.subheadline.weight(.semibold))
                                .foregroundColor(.yellow)
                            Text("Weekly dose — take with lunch!")
                                .font(.caption2)
                                .foregroundColor(AppColors.subtleText)
                        }
                        Spacer()
                    }
                    .padding(12)
                    .background(Color.yellow.opacity(0.06))
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .padding(.horizontal, 4)
                    .padding(.top, 4)
                }
            }
            .padding(4)
            .glassCard()
        }
    }
}

// MARK: - Agent Response Formatted View

struct AgentResponseView: View {
    let text: String

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            ForEach(Array(formattedParts.enumerated()), id: \.offset) { _, part in
                if part.isBold {
                    Text(part.text)
                        .font(.system(size: 13, weight: .bold))
                        .foregroundColor(Color.white.opacity(0.95))
                } else if part.isEmoji {
                    Text(part.text)
                        .font(.system(size: 14))
                } else {
                    Text(part.text)
                        .font(.system(size: 13, weight: .medium))
                        .foregroundColor(Color.white.opacity(0.82))
                }
            }
        }
        .lineSpacing(4)
        .fixedSize(horizontal: false, vertical: true)
    }

    private struct TextPart {
        let text: String
        let isBold: Bool
        let isEmoji: Bool
    }

    private var formattedParts: [TextPart] {
        // Split by sentences for readable chunks, handle **bold** markers
        let cleaned = text
            .replacingOccurrences(of: "**", with: "")
            .replacingOccurrences(of: "__", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)

        // Split into sentences
        let sentences = cleaned.components(separatedBy: ". ")
        var parts: [TextPart] = []

        for (i, sentence) in sentences.enumerated() {
            let trimmed = sentence.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !trimmed.isEmpty else { continue }

            let fullSentence = i < sentences.count - 1 && !trimmed.hasSuffix(".")
                ? trimmed + "."
                : trimmed

            // First sentence gets bold treatment
            if i == 0 {
                parts.append(TextPart(text: fullSentence, isBold: true, isEmoji: false))
            } else {
                parts.append(TextPart(text: fullSentence, isBold: false, isEmoji: false))
            }
        }

        return parts
    }
}

// MARK: - Text-to-Speech Agent Speaker

class AgentSpeaker: NSObject, ObservableObject, AVSpeechSynthesizerDelegate {
    @Published var isSpeaking = false
    private let synthesizer = AVSpeechSynthesizer()

    override init() {
        super.init()
        synthesizer.delegate = self
    }

    func speak(_ text: String) {
        stop()

        // Clean up text for natural speech
        let cleaned = text
            .replacingOccurrences(of: "**", with: "")
            .replacingOccurrences(of: "__", with: "")
            .replacingOccurrences(of: "#", with: "")
            .replacingOccurrences(of: "- ", with: "")
            .replacingOccurrences(of: "•", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)

        let utterance = AVSpeechUtterance(string: cleaned)
        utterance.voice = AVSpeechSynthesisVoice(language: "en-IN") // Indian English accent
        utterance.rate = AVSpeechUtteranceDefaultSpeechRate * 0.95
        utterance.pitchMultiplier = 1.05
        utterance.volume = 1.0

        // Activate audio session
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .spokenAudio, options: .duckOthers)
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {}

        isSpeaking = true
        synthesizer.speak(utterance)
    }

    func stop() {
        if synthesizer.isSpeaking {
            synthesizer.stopSpeaking(at: .immediate)
        }
        isSpeaking = false
    }

    // AVSpeechSynthesizerDelegate
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        DispatchQueue.main.async {
            self.isSpeaking = false
        }
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) {
        DispatchQueue.main.async {
            self.isSpeaking = false
        }
    }
}
