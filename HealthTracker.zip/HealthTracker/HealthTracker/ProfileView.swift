import SwiftUI

struct ProfileView: View {
    @EnvironmentObject var store: DataStore
    @State private var showAddLab = false
    @State private var newLabName = ""
    @State private var newLabValue = ""
    @State private var newLabStatus = "Normal"
    @State private var showExportSheet = false

    let profileItems: [(String, String, String)] = [
        ("person.fill", "Name", Profile.name),
        ("calendar", "Age", "25 years"),
        ("ruler", "Height", "170 cm (5'7\")"),
        ("scalemass", "Start Weight", "88 kg"),
        ("chart.bar.fill", "BMI", "30.5 (Obese — Indian std)"),
        ("target", "Target", "73 kg (BMI ~25)"),
        ("flame.fill", "Daily Calories", "\(Profile.dailyCalories) kcal"),
        ("bolt.fill", "Protein Goal", "\(Profile.proteinTarget)g/day"),
    ]

    var body: some View {
        NavigationStack {
            ZStack {
                AnimatedMeshBackground()

                ScrollView {
                    VStack(alignment: .leading, spacing: 18) {
                        // Profile Header
                        profileHeader
                            .padding(.top, 8)

                        // Profile Info
                        profileInfoCard

                        // Supplements
                        supplementsCard

                        // Lab Values
                        labValuesCard

                        // Daily Schedule
                        scheduleCard

                        // Goal Adjustment Suggestion
                        if let suggestion = store.agentGoalSuggestion {
                            goalSuggestionCard(suggestion)
                        }

                        // Data Export
                        exportCard

                        // Retest reminder
                        retestReminder
                    }
                    .padding()
                }
            }
            .navigationTitle("My Profile")
            .navigationBarTitleDisplayMode(.large)
            .sheet(isPresented: $showAddLab) {
                addLabSheet
            }
            .task {
                await store.checkGoalAdjustments()
            }
        }
    }

    // MARK: - Profile Header
    private var profileHeader: some View {
        HStack(spacing: 16) {
            ZStack {
                Circle()
                    .fill(
                        LinearGradient(
                            colors: [AppColors.accent, AppColors.green],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 60, height: 60)

                Text("HG")
                    .font(.system(size: 22, weight: .bold, design: .rounded))
                    .foregroundColor(.black)
            }

            VStack(alignment: .leading, spacing: 4) {
                Text("Harsh Gupta")
                    .font(.title3.weight(.bold))
                Text("25 y/o \u{2022} 170 cm \u{2022} Gurgaon")
                    .font(.caption)
                    .foregroundColor(AppColors.subtleText)

                HStack(spacing: 6) {
                    statusBadge("Active", AppColors.green)
                    statusBadge("Weight Loss", AppColors.orange)
                    if store.healthKitData.isAuthorized {
                        statusBadge("Watch Synced", AppColors.blue)
                    }
                }
            }

            Spacer()
        }
        .padding(16)
        .glassCard()
    }

    private func statusBadge(_ text: String, _ color: Color) -> some View {
        Text(text)
            .font(.system(size: 9, weight: .semibold))
            .foregroundColor(color)
            .padding(.horizontal, 8)
            .padding(.vertical, 3)
            .background(color.opacity(0.12))
            .clipShape(Capsule())
    }

    // MARK: - Profile Info
    private var profileInfoCard: some View {
        VStack(spacing: 0) {
            ForEach(Array(profileItems.enumerated()), id: \.offset) { index, item in
                HStack(spacing: 12) {
                    Image(systemName: item.0)
                        .font(.caption)
                        .foregroundColor(AppColors.accent)
                        .frame(width: 24)
                    Text(item.1)
                        .font(.subheadline)
                        .foregroundColor(AppColors.subtleText)
                    Spacer()
                    Text(item.2)
                        .font(.subheadline.weight(.medium))
                }
                .padding(.vertical, 11)

                if index < profileItems.count - 1 {
                    Divider().opacity(0.05).padding(.leading, 36)
                }
            }
        }
        .padding(16)
        .glassCard()
    }

    // MARK: - Supplements
    private var supplementsCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Image(systemName: "pill.fill")
                    .foregroundColor(AppColors.accent)
                Text("Supplements")
                    .font(.headline)
            }

            VStack(spacing: 10) {
                suppRow("pill.fill", "Nurokind-OD 1500mcg", "Daily after breakfast", AppColors.purple)
                suppRow("sun.max.fill", "Uprise-D3 60K", "Every Sunday with lunch", .yellow)
                suppRow("fish.fill", "Fish Oil 1000mg", "Twice daily — lunch + dinner", AppColors.blue)
                suppRow("mug.fill", "Whey Protein", "Post-workout", AppColors.green)
            }
        }
        .padding(16)
        .glassCard()
    }

    private func suppRow(_ icon: String, _ name: String, _ detail: String, _ color: Color) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.body)
                .foregroundColor(color)
                .frame(width: 32, height: 32)
                .background(color.opacity(0.12))
                .clipShape(RoundedRectangle(cornerRadius: 8))

            VStack(alignment: .leading, spacing: 2) {
                Text(name)
                    .font(.subheadline.weight(.medium))
                Text(detail)
                    .font(.caption2)
                    .foregroundColor(AppColors.subtleText)
            }

            Spacer()
        }
    }

    // MARK: - Lab Values (Editable)
    private var labValuesCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Image(systemName: "cross.case.fill")
                    .foregroundColor(AppColors.red)
                Text("Lab Values")
                    .font(.headline)
                Spacer()

                Button { showAddLab = true } label: {
                    Image(systemName: "plus.circle.fill")
                        .font(.system(size: 18))
                        .foregroundColor(AppColors.accent)
                }
            }

            VStack(spacing: 0) {
                ForEach(Array(store.editableLabValues.enumerated()), id: \.element.id) { index, lab in
                    HStack {
                        Text(lab.name)
                            .font(.subheadline)
                            .foregroundColor(AppColors.subtleText)
                        Spacer()
                        Text(lab.value)
                            .font(.system(size: 14, weight: .semibold, design: .rounded))

                        Text(lab.status)
                            .font(.system(size: 9, weight: .semibold))
                            .padding(.horizontal, 8)
                            .padding(.vertical, 3)
                            .background(statusColor(lab.statusColor).opacity(0.12))
                            .foregroundColor(statusColor(lab.statusColor))
                            .clipShape(Capsule())

                        Text(lab.dateRecorded)
                            .font(.system(size: 8))
                            .foregroundColor(.gray.opacity(0.5))
                    }
                    .padding(.vertical, 9)

                    if index < store.editableLabValues.count - 1 {
                        Divider().opacity(0.05)
                    }
                }
            }
        }
        .padding(16)
        .glassCard()
    }

    // MARK: - Add Lab Sheet
    private var addLabSheet: some View {
        NavigationStack {
            ZStack {
                AppColors.background.ignoresSafeArea()
                VStack(spacing: 20) {
                    TextField("Test name (e.g. B12)", text: $newLabName)
                        .font(.system(size: 15))
                        .padding(12)
                        .background(Color.white.opacity(0.06))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .foregroundColor(.white)

                    TextField("Value (e.g. 250)", text: $newLabValue)
                        .font(.system(size: 15))
                        .padding(12)
                        .background(Color.white.opacity(0.06))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .foregroundColor(.white)

                    Picker("Status", selection: $newLabStatus) {
                        Text("Normal").tag("Normal")
                        Text("Low").tag("Low")
                        Text("High").tag("High")
                        Text("Borderline").tag("Borderline")
                        Text("Deficient").tag("Deficient")
                    }
                    .pickerStyle(.segmented)

                    Spacer()
                }
                .padding()
            }
            .navigationTitle("Add Lab Value")
            .navigationBarTitleDisplayMode(.inline)
            .preferredColorScheme(.dark)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { showAddLab = false }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        let colorName: String
                        switch newLabStatus {
                        case "Low", "Deficient": colorName = "red"
                        case "High", "Borderline": colorName = "orange"
                        default: colorName = "green"
                        }
                        let lab = EditableLabValue(
                            name: newLabName,
                            value: newLabValue,
                            status: newLabStatus,
                            statusColor: colorName,
                            dateRecorded: dateString(for: Date()).prefix(7).description
                        )
                        store.editableLabValues.append(lab)
                        store.saveLabValues()
                        newLabName = ""
                        newLabValue = ""
                        newLabStatus = "Normal"
                        showAddLab = false
                    }
                    .disabled(newLabName.isEmpty || newLabValue.isEmpty)
                }
            }
        }
    }

    // MARK: - Goal Suggestion
    private func goalSuggestionCard(_ suggestion: String) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                Image(systemName: "lightbulb.fill")
                    .foregroundColor(AppColors.orange)
                Text("Goal Adjustment Suggestion")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(AppColors.orange)
            }
            AgentResponseView(text: suggestion)
        }
        .padding(16)
        .background(AppColors.orange.opacity(0.05))
        .glassCard()
    }

    // MARK: - Export
    private var exportCard: some View {
        Button {
            showExportSheet = true
        } label: {
            HStack(spacing: 12) {
                Image(systemName: "square.and.arrow.up")
                    .foregroundColor(AppColors.blue)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Export Health Data")
                        .font(.subheadline.weight(.semibold))
                        .foregroundColor(.white)
                    Text("Download all your data as JSON")
                        .font(.caption2)
                        .foregroundColor(AppColors.subtleText)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundColor(.gray)
            }
            .padding(14)
            .glassCard()
        }
        .buttonStyle(.plain)
        .sheet(isPresented: $showExportSheet) {
            if let url = exportData() {
                ShareSheet(activityItems: [url])
            }
        }
    }

    private func exportData() -> URL? {
        let data: [String: Any] = [
            "meals": store.meals.count,
            "weightLogs": store.weightLogs.count,
            "exerciseLogs": store.exerciseLogs.count,
            "waterHistory": store.waterHistory.count,
            "moodEntries": store.moodEntries.count,
            "fastingLogs": store.fastingLogs.count,
            "exportDate": todayString()
        ]

        guard let jsonData = try? JSONSerialization.data(withJSONObject: data, options: .prettyPrinted) else { return nil }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("HealthTracker_Export_\(todayString()).json")
        try? jsonData.write(to: url)
        return url
    }

    // MARK: - Schedule
    private var scheduleCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Image(systemName: "clock.fill")
                    .foregroundColor(AppColors.accent)
                Text("Daily Schedule")
                    .font(.headline)
            }

            VStack(alignment: .leading, spacing: 8) {
                scheduleRow("09:00 AM", "Black coffee", "cup.and.saucer.fill")
                scheduleRow("09:30 AM", "Gym workout", "dumbbell.fill")
                scheduleRow("10:30 AM", "Whey Protein shake", "mug.fill")
                scheduleRow("11:00 AM", "Breakfast + B12 tablet", "pill.fill")
                scheduleRow("02:00 PM", "Lunch + Fish Oil", "fish.fill")
                scheduleRow("08:30 PM", "Dinner + Fish Oil", "fish.fill")
                scheduleRow("Sunday", "Uprise-D3 60K with lunch", "sun.max.fill")
            }
        }
        .padding(16)
        .glassCard()
    }

    private func scheduleRow(_ time: String, _ activity: String, _ icon: String) -> some View {
        HStack(spacing: 10) {
            Text(time)
                .font(.system(size: 11, weight: .semibold, design: .monospaced))
                .foregroundColor(AppColors.accent)
                .frame(width: 80, alignment: .leading)
            Image(systemName: icon)
                .font(.system(size: 10))
                .foregroundColor(Color.white.opacity(0.3))
            Text(activity)
                .font(.subheadline)
                .foregroundColor(.white.opacity(0.8))
        }
    }

    // MARK: - Retest Reminder
    private var retestReminder: some View {
        HStack(spacing: 12) {
            Image(systemName: "calendar.badge.clock")
                .font(.title3)
                .foregroundColor(AppColors.orange)
            VStack(alignment: .leading, spacing: 2) {
                Text("Retest: July 2026")
                    .font(.subheadline.weight(.semibold))
                Text("B12, D3, Lipid, LFT, CRP, Fasting Insulin, HOMA-IR")
                    .font(.caption2)
                    .foregroundColor(AppColors.subtleText)
            }
            Spacer()
        }
        .padding(14)
        .glassCard()
    }

    func statusColor(_ name: String) -> Color {
        switch name {
        case "red": return AppColors.red
        case "orange": return AppColors.orange
        case "green": return AppColors.green
        default: return .gray
        }
    }
}

// MARK: - Share Sheet
struct ShareSheet: UIViewControllerRepresentable {
    let activityItems: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
