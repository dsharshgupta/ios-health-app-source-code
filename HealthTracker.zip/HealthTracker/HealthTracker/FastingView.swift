import SwiftUI

struct FastingView: View {
    @EnvironmentObject var store: DataStore
    @State private var selectedTarget: Double = 16

    private let presets: [Double] = [12, 14, 16, 18, 20]

    var body: some View {
        NavigationStack {
            ZStack {
                AnimatedMeshBackground()

                ScrollView {
                    VStack(spacing: 20) {
                        // MARK: - Timer Ring
                        fastingTimerCard

                        // MARK: - Controls
                        if store.currentFasting.isActive {
                            activeControls
                        } else {
                            startControls
                        }

                        // MARK: - Stats
                        statsRow

                        // MARK: - History
                        historySection
                    }
                    .padding()
                }
            }
            .navigationTitle("Fasting")
            .navigationBarTitleDisplayMode(.large)
            .preferredColorScheme(.dark)
        }
    }

    // MARK: - Timer Ring Card
    private var fastingTimerCard: some View {
        VStack(spacing: 16) {
            if store.currentFasting.isActive {
                TimelineView(.periodic(from: .now, by: 60)) { _ in
                    ZStack {
                        // Background ring
                        Circle()
                            .stroke(Color.white.opacity(0.08), lineWidth: 14)
                            .frame(width: 220, height: 220)

                        // Progress ring
                        Circle()
                            .trim(from: 0, to: store.currentFasting.progress)
                            .stroke(
                                AngularGradient(
                                    colors: [AppColors.purple, AppColors.accent, AppColors.purple],
                                    center: .center
                                ),
                                style: StrokeStyle(lineWidth: 14, lineCap: .round)
                            )
                            .frame(width: 220, height: 220)
                            .rotationEffect(.degrees(-90))
                            .animation(.easeInOut(duration: 1), value: store.currentFasting.progress)

                        VStack(spacing: 6) {
                            Text(store.currentFasting.isComplete ? "COMPLETE" : "FASTING")
                                .font(.system(size: 11, weight: .bold, design: .rounded))
                                .tracking(2)
                                .foregroundColor(store.currentFasting.isComplete ? AppColors.green : AppColors.purple)

                            Text(formatDuration(store.currentFasting.elapsedHours))
                                .font(.system(size: 38, weight: .bold, design: .rounded))
                                .foregroundColor(.white)

                            Text("of \(Int(store.currentFasting.targetHours))h target")
                                .font(.system(size: 13, weight: .medium))
                                .foregroundColor(.gray)

                            if !store.currentFasting.isComplete {
                                let remaining = max(store.currentFasting.targetHours - store.currentFasting.elapsedHours, 0)
                                Text("\(formatDuration(remaining)) remaining")
                                    .font(.system(size: 12, weight: .semibold))
                                    .foregroundColor(AppColors.accent)
                            }
                        }
                    }
                }
            } else {
                ZStack {
                    Circle()
                        .stroke(Color.white.opacity(0.08), lineWidth: 14)
                        .frame(width: 220, height: 220)

                    VStack(spacing: 6) {
                        Image(systemName: "timer")
                            .font(.system(size: 36))
                            .foregroundColor(AppColors.purple.opacity(0.5))

                        Text("Ready to fast")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.gray)
                    }
                }
            }
        }
        .padding(.vertical, 20)
        .frame(maxWidth: .infinity)
        .glassCard()
    }

    // MARK: - Start Controls
    private var startControls: some View {
        VStack(spacing: 16) {
            Text("SELECT DURATION")
                .font(.system(size: 11, weight: .bold, design: .rounded))
                .tracking(2)
                .foregroundColor(.gray)

            HStack(spacing: 10) {
                ForEach(presets, id: \.self) { hours in
                    Button {
                        selectedTarget = hours
                    } label: {
                        Text("\(Int(hours))h")
                            .font(.system(size: 15, weight: .bold, design: .rounded))
                            .foregroundColor(selectedTarget == hours ? .white : .gray)
                            .frame(width: 52, height: 40)
                            .background(
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(selectedTarget == hours ? AppColors.purple : Color.white.opacity(0.06))
                            )
                    }
                }
            }

            Button {
                store.startFast(targetHours: selectedTarget)
            } label: {
                HStack {
                    Image(systemName: "play.fill")
                    Text("Start Fast")
                        .fontWeight(.bold)
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background(
                    LinearGradient(colors: [AppColors.purple, AppColors.indigo], startPoint: .leading, endPoint: .trailing)
                )
                .clipShape(RoundedRectangle(cornerRadius: 14))
            }
        }
        .padding()
        .glassCard()
    }

    // MARK: - Active Controls
    private var activeControls: some View {
        HStack(spacing: 12) {
            Button {
                store.endFast()
            } label: {
                HStack {
                    Image(systemName: store.currentFasting.isComplete ? "checkmark.circle.fill" : "stop.fill")
                    Text(store.currentFasting.isComplete ? "Complete" : "End Fast")
                        .fontWeight(.bold)
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background(store.currentFasting.isComplete ? AppColors.green : AppColors.orange)
                .clipShape(RoundedRectangle(cornerRadius: 14))
            }

            Button {
                store.cancelFast()
            } label: {
                HStack {
                    Image(systemName: "xmark")
                    Text("Cancel")
                        .fontWeight(.bold)
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background(Color.white.opacity(0.08))
                .clipShape(RoundedRectangle(cornerRadius: 14))
            }
        }
        .padding(.horizontal)
    }

    // MARK: - Stats Row
    private var statsRow: some View {
        HStack(spacing: 12) {
            statCard(title: "STREAK", value: "\(store.fastingStreak)", unit: "days", icon: "flame.fill", color: AppColors.orange)
            statCard(title: "TOTAL FASTS", value: "\(store.fastingLogs.count)", unit: "completed", icon: "checkmark.circle.fill", color: AppColors.green)
            statCard(
                title: "AVG DURATION",
                value: store.fastingLogs.isEmpty ? "—" : String(format: "%.1f", store.fastingLogs.reduce(0.0) { $0 + $1.actualHours } / Double(store.fastingLogs.count)),
                unit: "hours",
                icon: "clock.fill",
                color: AppColors.purple
            )
        }
    }

    private func statCard(title: String, value: String, unit: String, icon: String, color: Color) -> some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .font(.system(size: 16))
                .foregroundColor(color)

            Text(value)
                .font(.system(size: 22, weight: .bold, design: .rounded))
                .foregroundColor(.white)

            Text(title)
                .font(.system(size: 8, weight: .bold))
                .tracking(1)
                .foregroundColor(.gray)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 14)
        .glassCard()
    }

    // MARK: - History Section
    private var historySection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("RECENT FASTS")
                .font(.system(size: 11, weight: .bold, design: .rounded))
                .tracking(2)
                .foregroundColor(.gray)

            if store.fastingLogs.isEmpty {
                Text("No completed fasts yet. Start your first fast above!")
                    .font(.system(size: 14))
                    .foregroundColor(.gray.opacity(0.6))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 20)
            } else {
                ForEach(store.fastingLogs.sorted(by: { $0.endTime > $1.endTime }).prefix(10)) { log in
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(formatDate(log.startTime))
                                .font(.system(size: 14, weight: .semibold))
                                .foregroundColor(.white)

                            Text("\(formatTime(log.startTime)) → \(formatTime(log.endTime))")
                                .font(.system(size: 12))
                                .foregroundColor(.gray)
                        }

                        Spacer()

                        VStack(alignment: .trailing, spacing: 4) {
                            Text(String(format: "%.1fh", log.actualHours))
                                .font(.system(size: 16, weight: .bold, design: .rounded))
                                .foregroundColor(log.completed ? AppColors.green : AppColors.orange)

                            Text(log.completed ? "Completed" : "Ended early")
                                .font(.system(size: 10, weight: .semibold))
                                .foregroundColor(log.completed ? AppColors.green.opacity(0.7) : AppColors.orange.opacity(0.7))
                        }
                    }
                    .padding()
                    .glassCard()
                }
            }
        }
    }

    private func formatDate(_ date: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "MMM d, yyyy"
        return f.string(from: date)
    }
}
