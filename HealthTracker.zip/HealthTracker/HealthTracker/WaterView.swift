import SwiftUI

struct WaterView: View {
    @EnvironmentObject var store: DataStore
    @State private var animateWave = false
    @State private var showCelebration = false

    var body: some View {
        NavigationStack {
            ZStack {
                AnimatedMeshBackground()

                ScrollView {
                    VStack(spacing: 20) {
                        // Water Ring Card
                        waterRingCard
                            .padding(.top, 8)

                        // Quick Add Section
                        quickAddSection

                        // Glass Grid
                        glassGridCard

                        // Today's Stats
                        statsCard

                        // Tips
                        tipsCard
                    }
                    .padding()
                }
            }
            .navigationTitle("Hydration")
            .navigationBarTitleDisplayMode(.large)
        }
    }

    // MARK: - Water Ring Card
    private var waterRingCard: some View {
        VStack(spacing: 16) {
            ZStack {
                // Background ring
                Circle()
                    .stroke(Color.white.opacity(0.06), lineWidth: 14)
                    .frame(width: 180, height: 180)

                // Water fill ring
                Circle()
                    .trim(from: 0, to: store.waterProgress)
                    .stroke(
                        AngularGradient(
                            colors: [AppColors.blue, AppColors.accent, AppColors.blue],
                            center: .center,
                            startAngle: .degrees(-90),
                            endAngle: .degrees(270)
                        ),
                        style: StrokeStyle(lineWidth: 14, lineCap: .round)
                    )
                    .frame(width: 180, height: 180)
                    .rotationEffect(.degrees(-90))
                    .animation(.spring(response: 0.8, dampingFraction: 0.7), value: store.waterGlasses)

                // Inner glow
                Circle()
                    .fill(AppColors.blue.opacity(0.08))
                    .frame(width: 155, height: 155)
                    .blur(radius: 8)

                // Center content
                VStack(spacing: 4) {
                    Image(systemName: "drop.fill")
                        .font(.title2)
                        .foregroundColor(AppColors.blue)
                        .symbolEffect(.bounce, value: store.waterGlasses)

                    Text("\(String(format: "%.1f", store.waterLiters))L")
                        .font(.system(size: 36, weight: .bold, design: .rounded))
                        .foregroundColor(.white)

                    Text("of \(String(format: "%.1f", Profile.waterTarget))L")
                        .font(.caption)
                        .foregroundColor(AppColors.subtleText)
                }
            }

            // Status text
            if store.waterLiters >= Profile.waterTarget {
                HStack(spacing: 6) {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundColor(AppColors.green)
                    Text("Goal reached! Great hydration today")
                        .font(.subheadline)
                        .foregroundColor(AppColors.green)
                }
                .transition(.scale.combined(with: .opacity))
            } else {
                let remaining = Profile.waterTarget - store.waterLiters
                let glassesLeft = Int(ceil(remaining / 0.25))
                Text("\(glassesLeft) more glass\(glassesLeft == 1 ? "" : "es") to go")
                    .font(.subheadline)
                    .foregroundColor(AppColors.subtleText)
            }
        }
        .padding(24)
        .glassCard()
    }

    // MARK: - Quick Add Section
    private var quickAddSection: some View {
        HStack(spacing: 12) {
            // Remove glass
            Button(action: {
                withAnimation(.spring(response: 0.3)) {
                    store.removeWaterGlass()
                }
            }) {
                Image(systemName: "minus")
                    .font(.title3.weight(.semibold))
                    .foregroundColor(.white)
                    .frame(width: 56, height: 56)
                    .glassCard(cornerRadius: 16)
            }
            .disabled(store.waterGlasses == 0)
            .opacity(store.waterGlasses == 0 ? 0.4 : 1)

            // Add glass button
            Button(action: {
                withAnimation(.spring(response: 0.3)) {
                    store.addWaterGlass()
                    if store.waterLiters >= Profile.waterTarget && !showCelebration {
                        showCelebration = true
                    }
                }
            }) {
                HStack(spacing: 10) {
                    Image(systemName: "plus.circle.fill")
                        .font(.title2)
                    VStack(alignment: .leading, spacing: 1) {
                        Text("Add Glass")
                            .font(.headline)
                        Text("250 ml")
                            .font(.caption)
                            .opacity(0.7)
                    }
                }
                .foregroundColor(.black)
                .frame(maxWidth: .infinity)
                .frame(height: 56)
                .background(
                    LinearGradient(
                        colors: [AppColors.blue, AppColors.accent],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .clipShape(RoundedRectangle(cornerRadius: 16))
            }

            // Remove glass
            Button(action: {
                withAnimation(.spring(response: 0.3)) {
                    // Add 500ml (2 glasses)
                    store.addWaterGlass()
                    store.addWaterGlass()
                }
            }) {
                VStack(spacing: 2) {
                    Image(systemName: "drop.fill")
                        .font(.body)
                    Text("500")
                        .font(.system(size: 10, weight: .semibold))
                }
                .foregroundColor(AppColors.blue)
                .frame(width: 56, height: 56)
                .glassCard(cornerRadius: 16)
            }
        }
    }

    // MARK: - Glass Grid
    private var glassGridCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("GLASSES TODAY")
                .font(.system(size: 11, weight: .semibold))
                .foregroundColor(AppColors.subtleText)
                .tracking(1)

            let targetGlasses = Int(Profile.waterTarget / 0.25) // 14 glasses
            let columns = Array(repeating: GridItem(.flexible(), spacing: 8), count: 7)

            LazyVGrid(columns: columns, spacing: 8) {
                ForEach(1...targetGlasses, id: \.self) { glass in
                    let isFilled = glass <= store.waterGlasses

                    ZStack {
                        RoundedRectangle(cornerRadius: 10)
                            .fill(isFilled ? AppColors.blue.opacity(0.2) : Color.white.opacity(0.03))
                            .frame(height: 40)

                        Image(systemName: isFilled ? "drop.fill" : "drop")
                            .font(.system(size: 14))
                            .foregroundColor(isFilled ? AppColors.blue : Color.white.opacity(0.15))
                    }
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(isFilled ? AppColors.blue.opacity(0.3) : Color.clear, lineWidth: 1)
                    )
                    .animation(.spring(response: 0.4).delay(Double(glass) * 0.02), value: store.waterGlasses)
                }
            }

            if store.waterGlasses > targetGlasses {
                Text("+\(store.waterGlasses - targetGlasses) extra glasses — staying well hydrated!")
                    .font(.caption)
                    .foregroundColor(AppColors.green)
            }
        }
        .padding(16)
        .glassCard()
    }

    // MARK: - Stats
    private var statsCard: some View {
        HStack(spacing: 0) {
            statItem(
                icon: "drop.fill",
                value: "\(store.waterGlasses)",
                label: "GLASSES",
                color: AppColors.blue
            )

            divider

            statItem(
                icon: "gauge.open.with.lines.needle.33percent",
                value: "\(Int(store.waterProgress * 100))%",
                label: "PROGRESS",
                color: AppColors.accent
            )

            divider

            statItem(
                icon: "arrow.up.right",
                value: "\(String(format: "%.1f", store.waterLiters))L",
                label: "TOTAL",
                color: AppColors.green
            )
        }
        .padding(16)
        .glassCard()
    }

    private var divider: some View {
        Rectangle()
            .fill(Color.white.opacity(0.06))
            .frame(width: 1, height: 40)
    }

    private func statItem(icon: String, value: String, label: String, color: Color) -> some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.caption)
                .foregroundColor(color)
            Text(value)
                .font(.system(size: 18, weight: .bold, design: .rounded))
            Text(label)
                .font(.system(size: 8, weight: .semibold))
                .foregroundColor(AppColors.subtleText)
                .tracking(0.5)
        }
        .frame(maxWidth: .infinity)
    }

    // MARK: - Tips
    private var tipsCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                Image(systemName: "lightbulb.fill")
                    .foregroundColor(AppColors.orange)
                Text("Hydration Tip")
                    .font(.subheadline.weight(.semibold))
            }

            let tips = [
                "High protein diet (120g/day) needs extra water for kidney function. Keep sipping!",
                "Drink a glass 30 min before meals — it helps with portion control and weight loss.",
                "Post-workout, drink at least 500ml to replenish fluids lost during exercise.",
                "Dehydration can mimic hunger signals. Feeling snacky? Try water first.",
            ]
            let tipIndex = Calendar.current.component(.hour, from: Date()) % tips.count
            Text(tips[tipIndex])
                .font(.caption)
                .foregroundColor(.white.opacity(0.7))
                .lineSpacing(3)
        }
        .padding(16)
        .glassCard()
    }
}
