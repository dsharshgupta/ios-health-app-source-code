import SwiftUI

struct WeightView: View {
    @EnvironmentObject var store: DataStore

    @State private var weightInput = ""
    @State private var editingLog: WeightLog?
    @FocusState private var isWeightFieldFocused: Bool

    var progressPercent: Double {
        let total = Profile.startWeight - Profile.targetWeight
        guard total > 0 else { return 0 }
        return max(0, min(store.weightLost / total, 1))
    }

    var body: some View {
        NavigationStack {
            ZStack {
                AnimatedMeshBackground()

                DismissKeyboardScrollView {
                    VStack(alignment: .leading, spacing: 18) {
                        progressCard
                            .padding(.top, 8)

                        logWeightCard

                        predictionSection

                        if !store.weightLogs.isEmpty {
                            historySection
                        }
                    }
                    .padding()
                }
            }
            .dismissKeyboardOnTap()
            .keyboardDoneToolbar()
            .navigationTitle("Weight Journey")
            .navigationBarTitleDisplayMode(.large)
            .sheet(item: $editingLog) { log in
                EditWeightLogSheet(log: log)
                    .environmentObject(store)
            }
        }
    }

    // MARK: - Progress Card
    private var progressCard: some View {
        VStack(spacing: 16) {
            HStack {
                Text("\(Int(Profile.startWeight)) kg")
                    .font(.system(size: 10, weight: .medium))
                    .foregroundColor(AppColors.subtleText)
                Spacer()
                Text("\(Int(Profile.targetWeight)) kg")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundColor(AppColors.accent)
            }

            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 5)
                        .fill(Color.white.opacity(0.05))
                        .frame(height: 10)

                    RoundedRectangle(cornerRadius: 5)
                        .fill(
                            LinearGradient(
                                colors: [AppColors.accent, AppColors.green],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .frame(width: geo.size.width * progressPercent, height: 10)
                        .animation(.spring(response: 0.8), value: store.weightLost)
                        .shadow(color: AppColors.accent.opacity(0.4), radius: 6, y: 2)
                }
            }
            .frame(height: 10)

            HStack(spacing: 0) {
                weightStat(
                    value: String(format: "%.1f", store.currentWeight),
                    label: "CURRENT",
                    color: .white
                )
                statDivider
                weightStat(
                    value: store.weightLost > 0 ? String(format: "%.1f", store.weightLost) : "0",
                    label: "LOST",
                    color: store.weightLost > 0 ? AppColors.green : AppColors.subtleText
                )
                statDivider
                weightStat(
                    value: String(format: "%.1f", max(store.currentWeight - Profile.targetWeight, 0)),
                    label: "TO GO",
                    color: AppColors.orange
                )
                statDivider
                weightStat(
                    value: "\(Int(progressPercent * 100))%",
                    label: "DONE",
                    color: AppColors.accent
                )
            }

            HStack(spacing: 10) {
                insightPill(
                    title: "7D AVG",
                    value: "\(String(format: "%.1f", store.averageWeightLast7)) kg",
                    color: AppColors.blue
                )
                insightPill(
                    title: "7D CHANGE",
                    value: store.weightChangeLast7 == 0
                        ? "Stable"
                        : "\(store.weightChangeLast7 > 0 ? "+" : "")\(String(format: "%.1f", store.weightChangeLast7)) kg",
                    color: store.weightChangeLast7 <= 0 ? AppColors.green : AppColors.red
                )
            }
        }
        .padding(18)
        .glassCard()
    }

    private var statDivider: some View {
        Rectangle()
            .fill(Color.white.opacity(0.06))
            .frame(width: 1, height: 36)
    }

    private func weightStat(value: String, label: String, color: Color) -> some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.system(size: 18, weight: .bold, design: .rounded))
                .foregroundColor(color)
            Text(label)
                .font(.system(size: 8, weight: .semibold))
                .foregroundColor(AppColors.subtleText)
                .tracking(0.5)
        }
        .frame(maxWidth: .infinity)
    }

    private func insightPill(title: String, value: String, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.system(size: 8, weight: .semibold))
                .foregroundColor(AppColors.subtleText)
                .tracking(0.6)
            Text(value)
                .font(.system(size: 13, weight: .bold, design: .rounded))
                .foregroundColor(color)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(Color.white.opacity(0.05))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }

    // MARK: - Log Weight
    private var logWeightCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                HStack(spacing: 8) {
                    Image(systemName: "scalemass")
                        .font(.caption)
                        .foregroundColor(AppColors.accent.opacity(0.5))
                    TextField("Today's weight (kg)", text: $weightInput)
                        .keyboardType(.decimalPad)
                        .textFieldStyle(.plain)
                        .font(.title3.weight(.medium))
                        .focused($isWeightFieldFocused)
                }
                .padding(14)
                .background(Color.white.opacity(0.06))
                .clipShape(RoundedRectangle(cornerRadius: 14))

                Button(action: saveTodayWeight) {
                    Text(store.todayWeightLog == nil ? "Log" : "Update")
                        .fontWeight(.bold)
                        .padding(.horizontal, 22)
                        .padding(.vertical, 14)
                }
                .background(
                    LinearGradient(
                        colors: [AppColors.accent, AppColors.green],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .foregroundColor(.black)
                .clipShape(RoundedRectangle(cornerRadius: 14))
            }

            if let todayLog = store.todayWeightLog {
                Text("Today's entry is \(String(format: "%.1f", todayLog.kg)) kg. Logging again updates it instead of creating duplicates.")
                    .font(.system(size: 10))
                    .foregroundColor(Color.white.opacity(0.25))
            }
        }
        .padding(14)
        .glassCard()
    }

    private func saveTodayWeight() {
        guard let kg = Double(weightInput), kg > 40, kg < 200 else { return }
        store.addWeight(kg)
        weightInput = ""
        isWeightFieldFocused = false
        hideKeyboard()
    }

    // MARK: - Prediction
    private var predictionSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Image(systemName: "chart.line.uptrend.xyaxis")
                    .foregroundColor(AppColors.accent)
                Text("6-Month Prediction")
                    .font(.headline)
            }

            VStack(spacing: 0) {
                ForEach(Array(store.predictWeights().enumerated()), id: \.element.id) { index, pred in
                    let bmi = pred.kg / (1.7 * 1.7)
                    let color = bmi < 25 ? AppColors.green : (bmi < 27.5 ? AppColors.orange : AppColors.red)
                    let barPct = min(max((Profile.startWeight - pred.kg) / (Profile.startWeight - Profile.targetWeight), 0.04), 1.0)

                    HStack(spacing: 10) {
                        Text(pred.month)
                            .font(.system(size: 11, weight: .medium))
                            .foregroundColor(AppColors.subtleText)
                            .frame(width: 36, alignment: .leading)

                        GeometryReader { geo in
                            ZStack(alignment: .leading) {
                                RoundedRectangle(cornerRadius: 3)
                                    .fill(Color.white.opacity(0.04))
                                    .frame(height: 6)
                                RoundedRectangle(cornerRadius: 3)
                                    .fill(
                                        LinearGradient(
                                            colors: [color, color.opacity(0.5)],
                                            startPoint: .leading,
                                            endPoint: .trailing
                                        )
                                    )
                                    .frame(width: geo.size.width * barPct, height: 6)
                                    .animation(.spring(response: 0.5).delay(Double(index) * 0.1), value: pred.kg)
                            }
                        }
                        .frame(height: 6)

                        Text("\(String(format: "%.1f", pred.kg)) kg")
                            .font(.system(size: 13, weight: .bold, design: .rounded))
                            .foregroundColor(color)
                            .frame(width: 60, alignment: .trailing)
                    }
                    .padding(.vertical, 10)

                    if index < 5 {
                        Divider().opacity(0.05)
                    }
                }

                Text("Based on \(store.weightLogs.count < 2 ? "a steady 500 kcal/day deficit" : "\(store.weightLogs.count) logged entries")")
                    .font(.system(size: 9))
                    .foregroundColor(Color.white.opacity(0.2))
                    .frame(maxWidth: .infinity)
                    .padding(.top, 8)
            }
            .padding(16)
            .glassCard()
        }
    }

    // MARK: - History
    private var historySection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("HISTORY")
                .font(.system(size: 11, weight: .semibold))
                .foregroundColor(AppColors.subtleText)
                .tracking(1)

            ForEach(Array(store.sortedWeightLogs.reversed().prefix(15))) { log in
                HStack(spacing: 12) {
                    VStack(alignment: .leading, spacing: 5) {
                        HStack(spacing: 8) {
                            Text(formatLogDate(log.date))
                                .font(.subheadline)
                                .foregroundColor(AppColors.subtleText)
                            if log.date == todayString() {
                                Text("TODAY")
                                    .font(.system(size: 8, weight: .semibold))
                                    .foregroundColor(AppColors.accent)
                                    .padding(.horizontal, 6)
                                    .padding(.vertical, 3)
                                    .background(AppColors.accent.opacity(0.12))
                                    .clipShape(Capsule())
                            }
                        }
                        Text("\(String(format: "%.1f", log.kg)) kg")
                            .font(.system(size: 17, weight: .bold, design: .rounded))
                    }

                    Spacer()

                    HStack(spacing: 10) {
                        Button(action: { editingLog = log }) {
                            Image(systemName: "pencil")
                                .foregroundColor(AppColors.accent)
                                .frame(width: 32, height: 32)
                                .background(AppColors.accent.opacity(0.1))
                                .clipShape(Circle())
                        }
                        .buttonStyle(.plain)

                        Button(action: { store.removeWeight(log.id) }) {
                            Image(systemName: "trash")
                                .foregroundColor(AppColors.red)
                                .frame(width: 32, height: 32)
                                .background(AppColors.red.opacity(0.1))
                                .clipShape(Circle())
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(14)
                .glassCard(cornerRadius: 12)
            }
        }
    }

    private func formatLogDate(_ dateStr: String) -> String {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd"
        guard let date = f.date(from: dateStr) else { return dateStr }
        let display = DateFormatter()
        display.dateFormat = "d MMM, EEE"
        return display.string(from: date)
    }
}

struct EditWeightLogSheet: View {
    @EnvironmentObject var store: DataStore
    @Environment(\.dismiss) private var dismiss

    let log: WeightLog

    @State private var selectedDate: Date
    @State private var weightText: String
    @FocusState private var isWeightFocused: Bool

    init(log: WeightLog) {
        self.log = log

        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        let parsedDate = formatter.date(from: log.date) ?? Date()

        _selectedDate = State(initialValue: parsedDate)
        _weightText = State(initialValue: String(format: "%.1f", log.kg))
    }

    private var isValidWeight: Bool {
        guard let kg = Double(weightText) else { return false }
        return kg > 40 && kg < 200
    }

    var body: some View {
        NavigationStack {
            ZStack {
                AppColors.background.ignoresSafeArea()

                VStack(spacing: 18) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Date")
                            .font(.caption)
                            .foregroundColor(AppColors.subtleText)
                        DatePicker(
                            "Date",
                            selection: $selectedDate,
                            displayedComponents: [.date]
                        )
                        .labelsHidden()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(14)
                        .background(Color.white.opacity(0.06))
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                    }

                    VStack(alignment: .leading, spacing: 8) {
                        Text("Weight")
                            .font(.caption)
                            .foregroundColor(AppColors.subtleText)
                        TextField("78.4", text: $weightText)
                            .keyboardType(.decimalPad)
                            .font(.title3.weight(.semibold))
                            .padding(14)
                            .background(Color.white.opacity(0.06))
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                            .focused($isWeightFocused)
                    }

                    Button(action: saveChanges) {
                        Text("Save Changes")
                            .fontWeight(.bold)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(
                                LinearGradient(
                                    colors: [AppColors.accent, AppColors.green],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .foregroundColor(.black)
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                    }
                    .disabled(!isValidWeight)
                    .opacity(isValidWeight ? 1 : 0.5)

                    Spacer()
                }
                .padding()
            }
            .dismissKeyboardOnTap()
            .keyboardDoneToolbar()
            .navigationTitle("Edit Weight")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                    .foregroundColor(AppColors.accent)
                }
            }
        }
        .presentationDetents([.medium])
    }

    private func saveChanges() {
        guard let kg = Double(weightText), kg > 40, kg < 200 else { return }
        store.updateWeight(id: log.id, kg: kg, date: dateString(for: selectedDate))
        isWeightFocused = false
        dismiss()
    }
}
