import SwiftUI

struct ReportsView: View {
    @EnvironmentObject var store: DataStore
    @State private var selectedPeriod = 0 // 0 = 7 days, 1 = 30 days

    private var days: [String] {
        selectedPeriod == 0 ? last7Days() : last30Days()
    }

    var body: some View {
        NavigationStack {
            ZStack {
                AnimatedMeshBackground()

                ScrollView {
                    VStack(spacing: 20) {
                        // Weekly AI Digest
                        weeklyDigestCard

                        // Period Picker
                        periodPicker
                            .padding(.top, 8)

                        // Summary Cards
                        summaryRow

                        // Calorie Chart
                        calorieChartCard

                        // Protein Compliance
                        proteinComplianceCard

                        // Exercise Chart
                        exerciseChartCard

                        // Weight Trend
                        if store.weightLogs.count >= 2 {
                            weightTrendCard
                        }

                        // Supplement Compliance
                        supplementCard
                    }
                    .padding()
                }
            }
            .navigationTitle("Reports")
            .navigationBarTitleDisplayMode(.large)
        }
    }

    // MARK: - Weekly AI Digest
    private var weeklyDigestCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                HStack(spacing: 8) {
                    Image(systemName: "doc.text.magnifyingglass")
                        .foregroundColor(AppColors.purple)
                    Text("Weekly AI Summary")
                        .font(.headline)
                }
                Spacer()
                Button {
                    Task { await store.refreshWeeklyDigest() }
                } label: {
                    if store.isGeneratingDigest {
                        ProgressView().tint(AppColors.purple)
                    } else {
                        Image(systemName: "arrow.clockwise")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(AppColors.purple)
                    }
                }
                .disabled(store.isGeneratingDigest)
            }

            if let digest = store.weeklyDigests.last {
                AgentResponseView(text: digest.summary)

                if !digest.wins.isEmpty {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("WINS")
                            .font(.system(size: 9, weight: .bold))
                            .tracking(1)
                            .foregroundColor(AppColors.green)
                        ForEach(digest.wins, id: \.self) { win in
                            HStack(spacing: 6) {
                                Image(systemName: "checkmark.circle.fill")
                                    .font(.system(size: 10))
                                    .foregroundColor(AppColors.green)
                                Text(win)
                                    .font(.system(size: 12))
                                    .foregroundColor(.white.opacity(0.8))
                            }
                        }
                    }
                }

                if !digest.improvements.isEmpty {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("TO IMPROVE")
                            .font(.system(size: 9, weight: .bold))
                            .tracking(1)
                            .foregroundColor(AppColors.orange)
                        ForEach(digest.improvements, id: \.self) { item in
                            HStack(spacing: 6) {
                                Image(systemName: "arrow.up.circle.fill")
                                    .font(.system(size: 10))
                                    .foregroundColor(AppColors.orange)
                                Text(item)
                                    .font(.system(size: 12))
                                    .foregroundColor(.white.opacity(0.8))
                            }
                        }
                    }
                }

                if !digest.nextWeekGoal.isEmpty {
                    HStack(spacing: 8) {
                        Image(systemName: "target")
                            .font(.system(size: 12))
                            .foregroundColor(AppColors.accent)
                        Text("Next week: \(digest.nextWeekGoal)")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(AppColors.accent)
                    }
                    .padding(10)
                    .background(AppColors.accent.opacity(0.08))
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                }
            } else {
                Text("No weekly digest yet. Tap refresh to generate one based on your 7-day data.")
                    .font(.system(size: 12))
                    .foregroundColor(.gray)
            }
        }
        .padding(16)
        .glassCard()
    }

    // MARK: - Period Picker
    private var periodPicker: some View {
        HStack(spacing: 4) {
            periodButton("7 Days", index: 0)
            periodButton("30 Days", index: 1)
        }
        .padding(4)
        .glassCard(cornerRadius: 14)
    }

    private func periodButton(_ title: String, index: Int) -> some View {
        Button(action: { withAnimation(.spring(response: 0.3)) { selectedPeriod = index } }) {
            Text(title)
                .font(.subheadline.weight(.semibold))
                .foregroundColor(selectedPeriod == index ? .black : .white.opacity(0.6))
                .frame(maxWidth: .infinity)
                .frame(height: 38)
                .background(selectedPeriod == index ? AppColors.accent : Color.clear)
                .clipShape(RoundedRectangle(cornerRadius: 10))
        }
        .buttonStyle(.plain)
    }

    // MARK: - Summary Row
    private var summaryRow: some View {
        HStack(spacing: 10) {
            summaryCard(
                icon: "flame.fill",
                title: "Avg Cal",
                value: "\(avgCalories)",
                subtitle: "/\(Profile.dailyCalories)",
                color: avgCalories > Profile.dailyCalories ? AppColors.red : AppColors.accent
            )
            summaryCard(
                icon: "bolt.fill",
                title: "Avg Protein",
                value: "\(avgProtein)g",
                subtitle: "/\(Profile.proteinTarget)g",
                color: avgProtein >= Profile.proteinTarget ? AppColors.green : AppColors.orange
            )
            summaryCard(
                icon: "figure.run",
                title: "Exercise",
                value: "\(totalExerciseMin)",
                subtitle: "min",
                color: AppColors.blue
            )
        }
    }

    private var avgCalories: Int {
        let active = days.filter { store.caloriesForDate($0) > 0 }
        guard !active.isEmpty else { return 0 }
        return active.reduce(0) { $0 + store.caloriesForDate($1) } / active.count
    }

    private var avgProtein: Int {
        let active = days.filter { store.caloriesForDate($0) > 0 }
        guard !active.isEmpty else { return 0 }
        return active.reduce(0) { $0 + store.proteinForDate($1) } / active.count
    }

    private var totalExerciseMin: Int {
        days.reduce(0) { $0 + store.exerciseMinutesForDate($1) }
    }

    private func summaryCard(icon: String, title: String, value: String, subtitle: String, color: Color) -> some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.caption)
                .foregroundColor(color)

            Text(value)
                .font(.system(size: 18, weight: .bold, design: .rounded))

            Text(subtitle)
                .font(.system(size: 9))
                .foregroundColor(AppColors.subtleText)

            Text(title.uppercased())
                .font(.system(size: 7, weight: .semibold))
                .foregroundColor(AppColors.subtleText)
                .tracking(0.5)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 14)
        .glassCard(cornerRadius: 14)
    }

    // MARK: - Calorie Chart
    private var calorieChartCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("CALORIES")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundColor(AppColors.subtleText)
                    .tracking(1)
                Spacer()
                HStack(spacing: 4) {
                    Circle().fill(AppColors.accent).frame(width: 6, height: 6)
                    Text("Under")
                        .font(.system(size: 9))
                        .foregroundColor(AppColors.subtleText)
                    Circle().fill(AppColors.red).frame(width: 6, height: 6)
                        .padding(.leading, 4)
                    Text("Over")
                        .font(.system(size: 9))
                        .foregroundColor(AppColors.subtleText)
                }
            }

            chartBars(
                data: days.map { (weekdayShort(for: $0), store.caloriesForDate($0)) },
                maxValue: Double(Profile.dailyCalories) * 1.3,
                targetLine: Double(Profile.dailyCalories),
                colorForValue: { $0 > Profile.dailyCalories ? AppColors.red : AppColors.accent }
            )
        }
        .padding(16)
        .glassCard()
    }

    // MARK: - Protein Compliance
    private var proteinComplianceCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("PROTEIN")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundColor(AppColors.subtleText)
                    .tracking(1)
                Spacer()

                let compliance = proteinCompliancePct
                Text("\(Int(compliance))% compliant")
                    .font(.caption2.weight(.semibold))
                    .foregroundColor(compliance >= 70 ? AppColors.green : AppColors.orange)
            }

            chartBars(
                data: days.map { (weekdayShort(for: $0), store.proteinForDate($0)) },
                maxValue: Double(Profile.proteinTarget) * 1.5,
                targetLine: Double(Profile.proteinTarget),
                colorForValue: { $0 >= Profile.proteinTarget ? AppColors.green : AppColors.orange }
            )
        }
        .padding(16)
        .glassCard()
    }

    private var proteinCompliancePct: Double {
        let active = days.filter { store.caloriesForDate($0) > 0 }
        guard !active.isEmpty else { return 0 }
        let compliant = active.filter { store.proteinForDate($0) >= Profile.proteinTarget }.count
        return Double(compliant) / Double(active.count) * 100
    }

    // MARK: - Exercise Chart
    private var exerciseChartCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("EXERCISE")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundColor(AppColors.subtleText)
                    .tracking(1)
                Spacer()
                Text("\(totalExerciseMin) min total")
                    .font(.caption2.weight(.semibold))
                    .foregroundColor(AppColors.blue)
            }

            chartBars(
                data: days.map { (weekdayShort(for: $0), store.exerciseMinutesForDate($0)) },
                maxValue: 90,
                targetLine: nil,
                colorForValue: { _ in AppColors.blue }
            )
        }
        .padding(16)
        .glassCard()
    }

    // MARK: - Weight Trend
    private var weightTrendCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("WEIGHT TREND")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundColor(AppColors.subtleText)
                    .tracking(1)
                Spacer()

                if let first = store.sortedWeightLogs.first, let last = store.sortedWeightLogs.last {
                    let change = last.kg - first.kg
                    Text(change <= 0 ? "\(String(format: "%.1f", change)) kg" : "+\(String(format: "%.1f", change)) kg")
                        .font(.caption2.weight(.semibold))
                        .foregroundColor(change <= 0 ? AppColors.green : AppColors.red)
                }
            }

            // Simple weight chart
            let recentLogs = Array(store.sortedWeightLogs.suffix(selectedPeriod == 0 ? 7 : 30))
            if !recentLogs.isEmpty {
                let minW = recentLogs.map(\.kg).min() ?? 73
                let maxW = recentLogs.map(\.kg).max() ?? 88
                let range = max(maxW - minW, 1)

                GeometryReader { geo in
                    let spacing = recentLogs.count > 1 ? geo.size.width / CGFloat(recentLogs.count - 1) : 0

                    // Target line
                    let targetY = geo.size.height * (1 - (Profile.targetWeight - minW + 1) / (range + 2))

                    Path { path in
                        path.move(to: CGPoint(x: 0, y: targetY))
                        path.addLine(to: CGPoint(x: geo.size.width, y: targetY))
                    }
                    .stroke(AppColors.green.opacity(0.3), style: StrokeStyle(lineWidth: 1, dash: [4, 4]))

                    // Weight line
                    Path { path in
                        for (i, log) in recentLogs.enumerated() {
                            let x = CGFloat(i) * spacing
                            let y = geo.size.height * (1 - (log.kg - minW + 1) / (range + 2))
                            if i == 0 {
                                path.move(to: CGPoint(x: x, y: y))
                            } else {
                                path.addLine(to: CGPoint(x: x, y: y))
                            }
                        }
                    }
                    .stroke(
                        LinearGradient(colors: [AppColors.accent, AppColors.green], startPoint: .leading, endPoint: .trailing),
                        style: StrokeStyle(lineWidth: 2.5, lineCap: .round, lineJoin: .round)
                    )

                    // Points
                    ForEach(Array(recentLogs.enumerated()), id: \.element.id) { i, log in
                        let x = CGFloat(i) * spacing
                        let y = geo.size.height * (1 - (log.kg - minW + 1) / (range + 2))
                        Circle()
                            .fill(AppColors.accent)
                            .frame(width: 6, height: 6)
                            .position(x: x, y: y)
                    }
                }
                .frame(height: 120)
                .padding(.top, 4)

                HStack {
                    Text("\(String(format: "%.1f", recentLogs.first?.kg ?? 0)) kg")
                        .font(.system(size: 9))
                        .foregroundColor(AppColors.subtleText)
                    Spacer()
                    HStack(spacing: 4) {
                        Circle().fill(AppColors.green.opacity(0.5)).frame(width: 4, height: 4)
                        Text("Target: \(Int(Profile.targetWeight)) kg")
                            .font(.system(size: 9))
                            .foregroundColor(AppColors.subtleText)
                    }
                    Spacer()
                    Text("\(String(format: "%.1f", recentLogs.last?.kg ?? 0)) kg")
                        .font(.system(size: 9))
                        .foregroundColor(AppColors.subtleText)
                }
            }
        }
        .padding(16)
        .glassCard()
    }

    // MARK: - Supplement Compliance
    private var supplementCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("TODAY'S COMPLIANCE")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundColor(AppColors.subtleText)
                    .tracking(1)
                Spacer()
                Text("\(store.doneCount)/\(store.supplements.count)")
                    .font(.caption2.weight(.bold))
                    .foregroundColor(AppColors.accent)
            }

            let pct = store.supplementComplianceToday()
            HStack(spacing: 14) {
                ZStack {
                    Circle()
                        .stroke(Color.white.opacity(0.06), lineWidth: 6)
                        .frame(width: 56, height: 56)
                    Circle()
                        .trim(from: 0, to: pct / 100)
                        .stroke(AppColors.accent, style: StrokeStyle(lineWidth: 6, lineCap: .round))
                        .frame(width: 56, height: 56)
                        .rotationEffect(.degrees(-90))

                    Text("\(Int(pct))%")
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                }

                VStack(alignment: .leading, spacing: 3) {
                    Text("Supplements")
                        .font(.subheadline.weight(.semibold))
                    Text(pct == 100 ? "All done! Perfect compliance today." : "Don't forget your remaining supplements.")
                        .font(.caption)
                        .foregroundColor(AppColors.subtleText)
                }

                Spacer()
            }
        }
        .padding(16)
        .glassCard()
    }

    // MARK: - Reusable Bar Chart
    private func chartBars(
        data: [(String, Int)],
        maxValue: Double,
        targetLine: Double?,
        colorForValue: @escaping (Int) -> Color
    ) -> some View {
        let displayData: [(String, Int)]
        if selectedPeriod == 1 && data.count > 15 {
            // For 30 days, show every other day
            displayData = data.enumerated().compactMap { i, d in i % 2 == 0 ? d : nil }
        } else {
            displayData = data
        }

        return VStack(spacing: 0) {
            GeometryReader { geo in
                let barWidth = max((geo.size.width - CGFloat(displayData.count - 1) * 3) / CGFloat(displayData.count), 4)

                ZStack(alignment: .bottomLeading) {
                    // Target line
                    if let target = targetLine {
                        let y = geo.size.height * (1 - CGFloat(target / maxValue))
                        Path { path in
                            path.move(to: CGPoint(x: 0, y: y))
                            path.addLine(to: CGPoint(x: geo.size.width, y: y))
                        }
                        .stroke(Color.white.opacity(0.15), style: StrokeStyle(lineWidth: 1, dash: [4, 4]))
                    }

                    // Bars
                    HStack(alignment: .bottom, spacing: 3) {
                        ForEach(Array(displayData.enumerated()), id: \.offset) { _, item in
                            let height = item.1 > 0 ? max(CGFloat(Double(item.1) / maxValue) * geo.size.height, 4) : 0

                            VStack(spacing: 4) {
                                Spacer()
                                RoundedRectangle(cornerRadius: 3)
                                    .fill(
                                        LinearGradient(
                                            colors: [colorForValue(item.1), colorForValue(item.1).opacity(0.5)],
                                            startPoint: .top,
                                            endPoint: .bottom
                                        )
                                    )
                                    .frame(width: barWidth, height: height)
                                    .animation(.spring(response: 0.5), value: item.1)
                            }
                            .frame(maxWidth: .infinity)
                        }
                    }
                }
            }
            .frame(height: 100)

            // Labels
            if selectedPeriod == 0 {
                HStack(spacing: 3) {
                    ForEach(Array(displayData.enumerated()), id: \.offset) { _, item in
                        Text(item.0)
                            .font(.system(size: 8))
                            .foregroundColor(AppColors.subtleText)
                            .frame(maxWidth: .infinity)
                    }
                }
                .padding(.top, 4)
            }
        }
    }
}
