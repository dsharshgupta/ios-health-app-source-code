import Foundation
import UserNotifications

/// AI Health Agent powered by Claude Haiku 4.5
/// Knows Harsh's complete medical profile and provides proactive daily guidance
final class HealthAgent {

    static let shared = HealthAgent()

    private init() {}

    // MARK: - Anthropic API Configuration

    private let apiURL = URL(string: "https://api.anthropic.com/v1/messages")!
    private let model = "claude-haiku-4-5-20251001"

    /// The system prompt containing Harsh's complete health profile
    private let systemPrompt = """
    You are Harsh's personal AI health coach inside his HealthTracker iOS app. You know his complete medical profile:

    PROFILE: Harsh Gupta, 25yo Indian male, 170cm, current weight ~88kg (target: 73kg), BMI 30.5 (Obese Stage II by Indian standards).
    Location: Gurgaon, India. Diet: Primarily Indian vegetarian with occasional non-veg. Gym-goer (morning workouts).

    MEDICAL CONDITIONS:
    - Obesity (primary issue driving everything else)
    - Vitamin B12 deficiency (160 pg/mL, ref 211-911) → taking Nurokind-OD 1500mcg daily
    - Vitamin D deficiency (17.6 ng/mL, ref 30-100) → taking Uprise-D3 60K weekly (Sunday)
    - Low HDL cholesterol (39 mg/dL, ref ≥40) — KEY concern, needs exercise + weight loss
    - Elevated LDL (129 mg/dL, target <100) — will improve with weight loss
    - Borderline SGPT/ALT (45, likely early fatty liver) — reversible with weight loss
    - Mildly elevated CRP (3.40 mg/L) — visceral fat inflammation
    - Gilbert's syndrome (benign, ignore bilirubin fluctuations)

    GOOD NEWS: Fasting glucose 80, HbA1c 4.5% (excellent), kidneys pristine, thyroid normal. Everything is reversible at his age.

    DAILY TARGETS:
    - Calories: 1,750 kcal (500 deficit from TDEE ~2,250)
    - Protein: 120g minimum (NON-NEGOTIABLE, his BUN/urea show chronic low protein intake)
    - Water: 3.5 liters
    - Exercise: 30+ min/day, 150+ min/week
    - Sleep: 7.5 hours target

    SUPPLEMENTS: B12 after breakfast (11AM, 2hrs after coffee), Fish Oil 1000mg with lunch + dinner, D3 60K on Sundays with lunch, Whey protein post-workout.

    SCHEDULE: Wake 9AM → Coffee → Gym 9:30 → Whey 10:30 → Breakfast+B12 11AM → Lunch+FishOil 2PM → Dinner+FishOil 8:30PM

    TONE: Encouraging, direct, simple Indian English. Like a knowledgeable gym buddy, not a doctor. Celebrate wins, be honest about setbacks. Never alarming — he's 25, everything is fixable. Use short sentences. No medical jargon.

    IMPORTANT RULES:
    1. Protein is #1 priority. Always push protein.
    2. HDL 39 is stubborn — only exercise and weight loss fix it. Remind him to stay active.
    3. Never scare about diabetes — he's not diabetic. Motivate prevention.
    4. Gilbert's syndrome is benign — never flag bilirubin.
    5. High protein (120g/day) is safe for his kidneys — don't add kidney warnings.
    6. Indian food context: dal chawal is a meal, chai has sugar unless specified, roti = chapati.
    7. Coffee must be 2+ hours before B12 (already handled by schedule).
    8. Retest in July 2026 — everything should aim toward showing improvement.
    """

    // MARK: - Generate Health Insight (Legacy - kept for compatibility)

    /// Generates a personalized health insight based on current daily data
    func generateInsight(
        calories: Int,
        protein: Int,
        carbs: Int,
        fat: Int,
        waterLiters: Double,
        exerciseMinutes: Int,
        exerciseCalories: Int,
        currentWeight: Double,
        sleepHours: Double,
        steps: Int,
        supplementsDone: Int,
        supplementsTotal: Int,
        heartRate: Double,
        activeCalories: Double,
        timeOfDay: String,
        apiKey: String
    ) async -> String? {
        return await generateTrendAwareInsight(
            calories: calories, protein: protein, carbs: carbs, fat: fat,
            waterLiters: waterLiters, exerciseMinutes: exerciseMinutes,
            exerciseCalories: exerciseCalories, currentWeight: currentWeight,
            sleepHours: sleepHours, steps: steps,
            supplementsDone: supplementsDone, supplementsTotal: supplementsTotal,
            heartRate: heartRate, activeCalories: activeCalories,
            timeOfDay: timeOfDay, trendSummary: nil, apiKey: apiKey
        )
    }

    // MARK: - Trend-Aware Insight

    func generateTrendAwareInsight(
        calories: Int,
        protein: Int,
        carbs: Int,
        fat: Int,
        waterLiters: Double,
        exerciseMinutes: Int,
        exerciseCalories: Int,
        currentWeight: Double,
        sleepHours: Double,
        steps: Int,
        supplementsDone: Int,
        supplementsTotal: Int,
        heartRate: Double,
        activeCalories: Double,
        timeOfDay: String,
        trendSummary: String?,
        apiKey: String
    ) async -> String? {
        guard !apiKey.isEmpty else { return nil }

        var userMessage = """
        It's \(timeOfDay) right now. Here's my data for today:

        - Calories eaten: \(calories)/1750 kcal
        - Protein: \(protein)/120g
        - Carbs: \(carbs)g | Fat: \(fat)g
        - Water: \(String(format: "%.1f", waterLiters))/3.5L
        - Exercise: \(exerciseMinutes) min, \(exerciseCalories) kcal burned
        - Steps: \(steps)
        - Weight: \(String(format: "%.1f", currentWeight)) kg
        - Sleep last night: \(sleepHours > 0 ? String(format: "%.1f", sleepHours) + "h" : "not tracked")
        - Supplements done: \(supplementsDone)/\(supplementsTotal)
        - Heart rate: \(heartRate > 0 ? "\(Int(heartRate)) bpm" : "not available")
        - Watch active calories: \(Int(activeCalories)) kcal
        """

        if let trends = trendSummary, !trends.isEmpty {
            userMessage += "\n\n\(trends)"
        }

        userMessage += "\n\nGive me a brief, actionable health check-in for this time of day. Consider both today's data AND the weekly trends. 2-3 sentences max. Be specific about what I should do next. If a trend is concerning (e.g., consistently low protein), mention it. If something is going well, acknowledge it."

        return await callAnthropic(userMessage: userMessage, apiKey: apiKey, maxTokens: 250)
    }

    // MARK: - Generate Notification Messages

    /// Generates smart notification content based on time of day and current data
    func generateNotificationMessage(
        timeSlot: NotificationTimeSlot,
        calories: Int,
        protein: Int,
        waterLiters: Double,
        exerciseMinutes: Int,
        supplementsDone: Int,
        supplementsTotal: Int,
        currentWeight: Double,
        sleepHours: Double,
        apiKey: String
    ) async -> String? {
        guard !apiKey.isEmpty else { return nil }

        let prompt: String

        switch timeSlot {
        case .morningBriefing:
            prompt = """
            It's 9:30 AM. I just woke up and about to head to gym. Sleep was \(sleepHours > 0 ? String(format: "%.1f", sleepHours) + " hours" : "not tracked"). Current weight: \(String(format: "%.1f", currentWeight)) kg. Give me a 1-sentence motivating morning message for my workout. Keep it punchy.
            """
        case .postLunchCheck:
            prompt = """
            It's 2:30 PM. So far today: \(calories)/1750 kcal, \(protein)/120g protein, \(String(format: "%.1f", waterLiters))/3.5L water, \(exerciseMinutes) min exercise, \(supplementsDone)/\(supplementsTotal) supplements done. Give me a 1-sentence check-in about my afternoon priorities. Be specific.
            """
        case .eveningSummary:
            prompt = """
            It's 7 PM. Today so far: \(calories)/1750 kcal, \(protein)/120g protein, \(String(format: "%.1f", waterLiters))/3.5L water, \(exerciseMinutes) min exercise. Dinner coming up. Give me a 1-sentence dinner guidance — how many calories/protein I should aim for at dinner to hit my targets.
            """
        case .bedtimeWrapup:
            prompt = """
            It's 10:30 PM. Final stats today: \(calories)/1750 kcal, \(protein)/120g protein, \(String(format: "%.1f", waterLiters))/3.5L water, \(exerciseMinutes) min exercise, \(supplementsDone)/\(supplementsTotal) supplements. Give me a 1-sentence bedtime summary — was it a good day? What to focus on tomorrow? Keep it positive.
            """
        }

        return await callAnthropic(userMessage: prompt, apiKey: apiKey, maxTokens: 100)
    }

    // MARK: - Quick Health Q&A (Legacy)

    func askQuestion(_ question: String, apiKey: String) async -> String? {
        return await askQuestionWithContext(question, conversationHistory: [], currentDayData: "", apiKey: apiKey)
    }

    // MARK: - Q&A with Conversation Memory

    func askQuestionWithContext(_ question: String, conversationHistory: [ConversationMessage], currentDayData: String, apiKey: String) async -> String? {
        guard !apiKey.isEmpty else { return nil }

        var messages: [[String: String]] = []

        // Add conversation history (last 10 exchanges = 20 messages)
        let recentHistory = conversationHistory.suffix(20)
        for msg in recentHistory {
            if msg.role == "user" || msg.role == "assistant" {
                messages.append(["role": msg.role, "content": msg.content])
            }
        }

        // Build the current question with context
        var currentMessage = ""
        if !currentDayData.isEmpty {
            currentMessage += "Current data: \(currentDayData)\n\n"
        }
        currentMessage += "Health question from Harsh: \(question)\n\nAnswer in 2-3 sentences max, specific to my medical profile and goals. If the question is about food, give calorie/protein estimates for Indian portions."

        messages.append(["role": "user", "content": currentMessage])

        return await callAnthropic(messages: messages, apiKey: apiKey, maxTokens: 250)
    }

    // MARK: - Weekly Digest

    func generateWeeklyDigest(trendSummary: String, apiKey: String) async -> WeeklyDigest? {
        guard !apiKey.isEmpty else { return nil }

        let prompt = """
        Generate my weekly health digest based on these trends:

        \(trendSummary)

        Respond in this EXACT format (no extra text):
        SUMMARY: [2-3 sentence overview of the week]
        WIN1: [specific win]
        WIN2: [specific win]
        WIN3: [specific win]
        IMPROVE1: [specific area to improve]
        IMPROVE2: [specific area to improve]
        IMPROVE3: [specific area to improve]
        GOAL: [one specific, measurable goal for next week]
        """

        guard let response = await callAnthropic(userMessage: prompt, apiKey: apiKey, maxTokens: 400) else { return nil }

        // Parse the structured response
        let lines = response.components(separatedBy: "\n")
        var summary = "", wins: [String] = [], improvements: [String] = [], goal = ""

        for line in lines {
            let trimmed = line.trimmingCharacters(in: .whitespaces)
            if trimmed.hasPrefix("SUMMARY:") { summary = String(trimmed.dropFirst(8)).trimmingCharacters(in: .whitespaces) }
            else if trimmed.hasPrefix("WIN") { wins.append(String(trimmed.drop(while: { $0 != ":" }).dropFirst()).trimmingCharacters(in: .whitespaces)) }
            else if trimmed.hasPrefix("IMPROVE") { improvements.append(String(trimmed.drop(while: { $0 != ":" }).dropFirst()).trimmingCharacters(in: .whitespaces)) }
            else if trimmed.hasPrefix("GOAL:") { goal = String(trimmed.dropFirst(5)).trimmingCharacters(in: .whitespaces) }
        }

        if summary.isEmpty { summary = response }

        let weekStart = dateString(for: Calendar.current.date(byAdding: .day, value: -7, to: Date())!)
        return WeeklyDigest(weekStartDate: weekStart, summary: summary, wins: wins, improvements: improvements, nextWeekGoal: goal)
    }

    // MARK: - Goal Adjustments

    func suggestGoalAdjustments(weightTrend: Double, avgCalories: Int, avgProtein: Int, exerciseMinutes: Int, apiKey: String) async -> String? {
        guard !apiKey.isEmpty else { return nil }

        let prompt = """
        Based on my recent trends:
        - Weight trend: \(String(format: "%.2f", weightTrend)) kg/week
        - Average daily calories: \(avgCalories)/1750
        - Average daily protein: \(avgProtein)/120g
        - Weekly exercise: \(exerciseMinutes)/150 min

        Should I adjust any of my targets? Consider: if I'm losing >1kg/week it's too fast, if weight hasn't moved in 2+ weeks something needs to change, if I'm consistently over/under calories by >20% the target may not be realistic.

        Give me a 2-3 sentence specific recommendation. If everything looks fine, say so.
        """

        return await callAnthropic(userMessage: prompt, apiKey: apiKey, maxTokens: 200)
    }

    // MARK: - Meal Suggestions

    func suggestMeals(remainingCalories: Int, remainingProtein: Int, remainingCarbs: Int, remainingFat: Int, timeOfDay: String, apiKey: String) async -> String? {
        guard !apiKey.isEmpty else { return nil }

        let prompt = """
        It's \(timeOfDay). I have these macros remaining for the day:
        - Calories: \(remainingCalories) kcal
        - Protein: \(remainingProtein)g
        - Carbs: \(remainingCarbs)g
        - Fat: \(remainingFat)g

        Suggest 3 Indian meal options that fit these remaining macros. For each, give: meal name, approximate calories, protein, and a one-line description. Keep it practical — things Harsh can easily get in Gurgaon (home-cooked or ordered).
        """

        return await callAnthropic(userMessage: prompt, apiKey: apiKey, maxTokens: 350)
    }

    // MARK: - Daily Challenge

    func generateChallenge(avgCalories: Int, avgProtein: Int, exerciseMinutes: Int, waterAvg: Double, apiKey: String) async -> String? {
        guard !apiKey.isEmpty else { return nil }

        let prompt = """
        Generate ONE specific daily health challenge for me based on my recent averages:
        - Avg calories: \(avgCalories)/1750
        - Avg protein: \(avgProtein)/120g
        - Weekly exercise: \(exerciseMinutes) min
        - Water today: \(String(format: "%.1f", waterAvg))L

        The challenge should be slightly above my average to push me. Reply with ONLY the challenge in one sentence (e.g., "Hit 130g protein today" or "Walk 8000 steps today"). No explanation.
        """

        return await callAnthropic(userMessage: prompt, apiKey: apiKey, maxTokens: 60)
    }

    // MARK: - Anthropic API Call (Single Message)

    private func callAnthropic(userMessage: String, apiKey: String, maxTokens: Int) async -> String? {
        return await callAnthropic(
            messages: [["role": "user", "content": userMessage]],
            apiKey: apiKey,
            maxTokens: maxTokens
        )
    }

    // MARK: - Anthropic API Call (Multi-Message with History)

    private func callAnthropic(messages: [[String: String]], apiKey: String, maxTokens: Int) async -> String? {
        var request = URLRequest(url: apiURL)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(apiKey, forHTTPHeaderField: "x-api-key")
        request.setValue("2023-06-01", forHTTPHeaderField: "anthropic-version")

        let body: [String: Any] = [
            "model": model,
            "max_tokens": maxTokens,
            "temperature": 0.7,
            "system": systemPrompt,
            "messages": messages
        ]

        request.httpBody = try? JSONSerialization.data(withJSONObject: body)

        do {
            let (data, response) = try await URLSession.shared.data(for: request)

            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                return nil
            }

            if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let content = json["content"] as? [[String: Any]],
               let firstBlock = content.first,
               let text = firstBlock["text"] as? String {
                return text.trimmingCharacters(in: .whitespacesAndNewlines)
            }
        } catch {}

        return nil
    }
}

// MARK: - Notification Time Slots

enum NotificationTimeSlot: String, CaseIterable {
    case morningBriefing = "morning_ai"
    case postLunchCheck = "lunch_ai"
    case eveningSummary = "evening_ai"
    case bedtimeWrapup = "bedtime_ai"

    var hour: Int {
        switch self {
        case .morningBriefing: return 9
        case .postLunchCheck: return 14
        case .eveningSummary: return 19
        case .bedtimeWrapup: return 22
        }
    }

    var minute: Int {
        switch self {
        case .morningBriefing: return 30
        case .postLunchCheck: return 30
        case .eveningSummary: return 0
        case .bedtimeWrapup: return 30
        }
    }

    var title: String {
        switch self {
        case .morningBriefing: return "🌅 Morning Briefing"
        case .postLunchCheck: return "☀️ Afternoon Check"
        case .eveningSummary: return "🌆 Evening Summary"
        case .bedtimeWrapup: return "🌙 Day Wrap-up"
        }
    }
}
